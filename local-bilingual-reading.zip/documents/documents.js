"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/zod/v3/helpers/util.js
  var util, objectUtil, ZodParsedType, getParsedType;
  var init_util = __esm({
    "node_modules/zod/v3/helpers/util.js"() {
      (function(util2) {
        util2.assertEqual = (_) => {
        };
        function assertIs(_arg) {
        }
        util2.assertIs = assertIs;
        function assertNever(_x) {
          throw new Error();
        }
        util2.assertNever = assertNever;
        util2.arrayToEnum = (items) => {
          const obj = {};
          for (const item of items) {
            obj[item] = item;
          }
          return obj;
        };
        util2.getValidEnumValues = (obj) => {
          const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
          const filtered = {};
          for (const k of validKeys) {
            filtered[k] = obj[k];
          }
          return util2.objectValues(filtered);
        };
        util2.objectValues = (obj) => {
          return util2.objectKeys(obj).map(function(e) {
            return obj[e];
          });
        };
        util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
          const keys = [];
          for (const key in object) {
            if (Object.prototype.hasOwnProperty.call(object, key)) {
              keys.push(key);
            }
          }
          return keys;
        };
        util2.find = (arr, checker) => {
          for (const item of arr) {
            if (checker(item))
              return item;
          }
          return void 0;
        };
        util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
        function joinValues(array, separator = " | ") {
          return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
        }
        util2.joinValues = joinValues;
        util2.jsonStringifyReplacer = (_, value) => {
          if (typeof value === "bigint") {
            return value.toString();
          }
          return value;
        };
      })(util || (util = {}));
      (function(objectUtil2) {
        objectUtil2.mergeShapes = (first, second) => {
          return {
            ...first,
            ...second
            // second overwrites first
          };
        };
      })(objectUtil || (objectUtil = {}));
      ZodParsedType = util.arrayToEnum([
        "string",
        "nan",
        "number",
        "integer",
        "float",
        "boolean",
        "date",
        "bigint",
        "symbol",
        "function",
        "undefined",
        "null",
        "array",
        "object",
        "unknown",
        "promise",
        "void",
        "never",
        "map",
        "set"
      ]);
      getParsedType = (data) => {
        const t = typeof data;
        switch (t) {
          case "undefined":
            return ZodParsedType.undefined;
          case "string":
            return ZodParsedType.string;
          case "number":
            return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
          case "boolean":
            return ZodParsedType.boolean;
          case "function":
            return ZodParsedType.function;
          case "bigint":
            return ZodParsedType.bigint;
          case "symbol":
            return ZodParsedType.symbol;
          case "object":
            if (Array.isArray(data)) {
              return ZodParsedType.array;
            }
            if (data === null) {
              return ZodParsedType.null;
            }
            if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
              return ZodParsedType.promise;
            }
            if (typeof Map !== "undefined" && data instanceof Map) {
              return ZodParsedType.map;
            }
            if (typeof Set !== "undefined" && data instanceof Set) {
              return ZodParsedType.set;
            }
            if (typeof Date !== "undefined" && data instanceof Date) {
              return ZodParsedType.date;
            }
            return ZodParsedType.object;
          default:
            return ZodParsedType.unknown;
        }
      };
    }
  });

  // node_modules/zod/v3/ZodError.js
  var ZodIssueCode, quotelessJson, ZodError;
  var init_ZodError = __esm({
    "node_modules/zod/v3/ZodError.js"() {
      init_util();
      ZodIssueCode = util.arrayToEnum([
        "invalid_type",
        "invalid_literal",
        "custom",
        "invalid_union",
        "invalid_union_discriminator",
        "invalid_enum_value",
        "unrecognized_keys",
        "invalid_arguments",
        "invalid_return_type",
        "invalid_date",
        "invalid_string",
        "too_small",
        "too_big",
        "invalid_intersection_types",
        "not_multiple_of",
        "not_finite"
      ]);
      quotelessJson = (obj) => {
        const json = JSON.stringify(obj, null, 2);
        return json.replace(/"([^"]+)":/g, "$1:");
      };
      ZodError = class _ZodError extends Error {
        get errors() {
          return this.issues;
        }
        constructor(issues) {
          super();
          this.issues = [];
          this.addIssue = (sub) => {
            this.issues = [...this.issues, sub];
          };
          this.addIssues = (subs = []) => {
            this.issues = [...this.issues, ...subs];
          };
          const actualProto = new.target.prototype;
          if (Object.setPrototypeOf) {
            Object.setPrototypeOf(this, actualProto);
          } else {
            this.__proto__ = actualProto;
          }
          this.name = "ZodError";
          this.issues = issues;
        }
        format(_mapper) {
          const mapper = _mapper || function(issue) {
            return issue.message;
          };
          const fieldErrors = { _errors: [] };
          const processError = (error) => {
            for (const issue of error.issues) {
              if (issue.code === "invalid_union") {
                issue.unionErrors.map(processError);
              } else if (issue.code === "invalid_return_type") {
                processError(issue.returnTypeError);
              } else if (issue.code === "invalid_arguments") {
                processError(issue.argumentsError);
              } else if (issue.path.length === 0) {
                fieldErrors._errors.push(mapper(issue));
              } else {
                let curr = fieldErrors;
                let i = 0;
                while (i < issue.path.length) {
                  const el = issue.path[i];
                  const terminal = i === issue.path.length - 1;
                  if (!terminal) {
                    curr[el] = curr[el] || { _errors: [] };
                  } else {
                    curr[el] = curr[el] || { _errors: [] };
                    curr[el]._errors.push(mapper(issue));
                  }
                  curr = curr[el];
                  i++;
                }
              }
            }
          };
          processError(this);
          return fieldErrors;
        }
        static assert(value) {
          if (!(value instanceof _ZodError)) {
            throw new Error(`Not a ZodError: ${value}`);
          }
        }
        toString() {
          return this.message;
        }
        get message() {
          return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
        }
        get isEmpty() {
          return this.issues.length === 0;
        }
        flatten(mapper = (issue) => issue.message) {
          const fieldErrors = {};
          const formErrors = [];
          for (const sub of this.issues) {
            if (sub.path.length > 0) {
              const firstEl = sub.path[0];
              fieldErrors[firstEl] = fieldErrors[firstEl] || [];
              fieldErrors[firstEl].push(mapper(sub));
            } else {
              formErrors.push(mapper(sub));
            }
          }
          return { formErrors, fieldErrors };
        }
        get formErrors() {
          return this.flatten();
        }
      };
      ZodError.create = (issues) => {
        const error = new ZodError(issues);
        return error;
      };
    }
  });

  // node_modules/zod/v3/locales/en.js
  var errorMap, en_default;
  var init_en = __esm({
    "node_modules/zod/v3/locales/en.js"() {
      init_ZodError();
      init_util();
      errorMap = (issue, _ctx) => {
        let message;
        switch (issue.code) {
          case ZodIssueCode.invalid_type:
            if (issue.received === ZodParsedType.undefined) {
              message = "Required";
            } else {
              message = `Expected ${issue.expected}, received ${issue.received}`;
            }
            break;
          case ZodIssueCode.invalid_literal:
            message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
            break;
          case ZodIssueCode.unrecognized_keys:
            message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
            break;
          case ZodIssueCode.invalid_union:
            message = `Invalid input`;
            break;
          case ZodIssueCode.invalid_union_discriminator:
            message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
            break;
          case ZodIssueCode.invalid_enum_value:
            message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
            break;
          case ZodIssueCode.invalid_arguments:
            message = `Invalid function arguments`;
            break;
          case ZodIssueCode.invalid_return_type:
            message = `Invalid function return type`;
            break;
          case ZodIssueCode.invalid_date:
            message = `Invalid date`;
            break;
          case ZodIssueCode.invalid_string:
            if (typeof issue.validation === "object") {
              if ("includes" in issue.validation) {
                message = `Invalid input: must include "${issue.validation.includes}"`;
                if (typeof issue.validation.position === "number") {
                  message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
                }
              } else if ("startsWith" in issue.validation) {
                message = `Invalid input: must start with "${issue.validation.startsWith}"`;
              } else if ("endsWith" in issue.validation) {
                message = `Invalid input: must end with "${issue.validation.endsWith}"`;
              } else {
                util.assertNever(issue.validation);
              }
            } else if (issue.validation !== "regex") {
              message = `Invalid ${issue.validation}`;
            } else {
              message = "Invalid";
            }
            break;
          case ZodIssueCode.too_small:
            if (issue.type === "array")
              message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
            else if (issue.type === "string")
              message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
            else if (issue.type === "number")
              message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
            else if (issue.type === "bigint")
              message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
            else if (issue.type === "date")
              message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
            else
              message = "Invalid input";
            break;
          case ZodIssueCode.too_big:
            if (issue.type === "array")
              message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
            else if (issue.type === "string")
              message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
            else if (issue.type === "number")
              message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
            else if (issue.type === "bigint")
              message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
            else if (issue.type === "date")
              message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
            else
              message = "Invalid input";
            break;
          case ZodIssueCode.custom:
            message = `Invalid input`;
            break;
          case ZodIssueCode.invalid_intersection_types:
            message = `Intersection results could not be merged`;
            break;
          case ZodIssueCode.not_multiple_of:
            message = `Number must be a multiple of ${issue.multipleOf}`;
            break;
          case ZodIssueCode.not_finite:
            message = "Number must be finite";
            break;
          default:
            message = _ctx.defaultError;
            util.assertNever(issue);
        }
        return { message };
      };
      en_default = errorMap;
    }
  });

  // node_modules/zod/v3/errors.js
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }
  var overrideErrorMap;
  var init_errors = __esm({
    "node_modules/zod/v3/errors.js"() {
      init_en();
      overrideErrorMap = en_default;
    }
  });

  // node_modules/zod/v3/helpers/parseUtil.js
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var makeIssue, EMPTY_PATH, ParseStatus, INVALID, DIRTY, OK, isAborted, isDirty, isValid, isAsync;
  var init_parseUtil = __esm({
    "node_modules/zod/v3/helpers/parseUtil.js"() {
      init_errors();
      init_en();
      makeIssue = (params2) => {
        const { data, path, errorMaps, issueData } = params2;
        const fullPath = [...path, ...issueData.path || []];
        const fullIssue = {
          ...issueData,
          path: fullPath
        };
        if (issueData.message !== void 0) {
          return {
            ...issueData,
            path: fullPath,
            message: issueData.message
          };
        }
        let errorMessage = "";
        const maps = errorMaps.filter((m) => !!m).slice().reverse();
        for (const map of maps) {
          errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
        }
        return {
          ...issueData,
          path: fullPath,
          message: errorMessage
        };
      };
      EMPTY_PATH = [];
      ParseStatus = class _ParseStatus {
        constructor() {
          this.value = "valid";
        }
        dirty() {
          if (this.value === "valid")
            this.value = "dirty";
        }
        abort() {
          if (this.value !== "aborted")
            this.value = "aborted";
        }
        static mergeArray(status2, results) {
          const arrayValue = [];
          for (const s of results) {
            if (s.status === "aborted")
              return INVALID;
            if (s.status === "dirty")
              status2.dirty();
            arrayValue.push(s.value);
          }
          return { status: status2.value, value: arrayValue };
        }
        static async mergeObjectAsync(status2, pairs) {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value
            });
          }
          return _ParseStatus.mergeObjectSync(status2, syncPairs);
        }
        static mergeObjectSync(status2, pairs) {
          const finalObject = {};
          for (const pair of pairs) {
            const { key, value } = pair;
            if (key.status === "aborted")
              return INVALID;
            if (value.status === "aborted")
              return INVALID;
            if (key.status === "dirty")
              status2.dirty();
            if (value.status === "dirty")
              status2.dirty();
            if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
              finalObject[key.value] = value.value;
            }
          }
          return { status: status2.value, value: finalObject };
        }
      };
      INVALID = Object.freeze({
        status: "aborted"
      });
      DIRTY = (value) => ({ status: "dirty", value });
      OK = (value) => ({ status: "valid", value });
      isAborted = (x) => x.status === "aborted";
      isDirty = (x) => x.status === "dirty";
      isValid = (x) => x.status === "valid";
      isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
    }
  });

  // node_modules/zod/v3/helpers/typeAliases.js
  var init_typeAliases = __esm({
    "node_modules/zod/v3/helpers/typeAliases.js"() {
    }
  });

  // node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  var init_errorUtil = __esm({
    "node_modules/zod/v3/helpers/errorUtil.js"() {
      (function(errorUtil2) {
        errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
        errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
      })(errorUtil || (errorUtil = {}));
    }
  });

  // node_modules/zod/v3/types.js
  function processCreateParams(params2) {
    if (!params2)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params2;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params2;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  function createZodEnum(values, params2) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params2)
    });
  }
  function cleanParams(params2, data) {
    const p = typeof params2 === "function" ? params2(data) : typeof params2 === "string" ? { message: params2 } : params2;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params2 = cleanParams(_params, data);
              const _fatal = params2.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params2, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params2 = cleanParams(_params, data);
          const _fatal = params2.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params2, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var ParseInputLazyPath, handleResult, ZodType, cuidRegex, cuid2Regex, ulidRegex, uuidRegex, nanoidRegex, jwtRegex, durationRegex, emailRegex, _emojiRegex, emojiRegex, ipv4Regex, ipv4CidrRegex, ipv6Regex, ipv6CidrRegex, base64Regex, base64urlRegex, dateRegexSource, dateRegex, ZodString, ZodNumber, ZodBigInt, ZodBoolean, ZodDate, ZodSymbol, ZodUndefined, ZodNull, ZodAny, ZodUnknown, ZodNever, ZodVoid, ZodArray, ZodObject, ZodUnion, getDiscriminator, ZodDiscriminatedUnion, ZodIntersection, ZodTuple, ZodRecord, ZodMap, ZodSet, ZodFunction, ZodLazy, ZodLiteral, ZodEnum, ZodNativeEnum, ZodPromise, ZodEffects, ZodOptional, ZodNullable, ZodDefault, ZodCatch, ZodNaN, BRAND, ZodBranded, ZodPipeline, ZodReadonly, late, ZodFirstPartyTypeKind, instanceOfType, stringType, numberType, nanType, bigIntType, booleanType, dateType, symbolType, undefinedType, nullType, anyType, unknownType, neverType, voidType, arrayType, objectType, strictObjectType, unionType, discriminatedUnionType, intersectionType, tupleType, recordType, mapType, setType, functionType, lazyType, literalType, enumType, nativeEnumType, promiseType, effectsType, optionalType, nullableType, preprocessType, pipelineType, ostring, onumber, oboolean, coerce, NEVER;
  var init_types = __esm({
    "node_modules/zod/v3/types.js"() {
      init_ZodError();
      init_errors();
      init_errorUtil();
      init_parseUtil();
      init_util();
      ParseInputLazyPath = class {
        constructor(parent, value, path, key) {
          this._cachedPath = [];
          this.parent = parent;
          this.data = value;
          this._path = path;
          this._key = key;
        }
        get path() {
          if (!this._cachedPath.length) {
            if (Array.isArray(this._key)) {
              this._cachedPath.push(...this._path, ...this._key);
            } else {
              this._cachedPath.push(...this._path, this._key);
            }
          }
          return this._cachedPath;
        }
      };
      handleResult = (ctx, result) => {
        if (isValid(result)) {
          return { success: true, data: result.value };
        } else {
          if (!ctx.common.issues.length) {
            throw new Error("Validation failed but no issues detected.");
          }
          return {
            success: false,
            get error() {
              if (this._error)
                return this._error;
              const error = new ZodError(ctx.common.issues);
              this._error = error;
              return this._error;
            }
          };
        }
      };
      ZodType = class {
        get description() {
          return this._def.description;
        }
        _getType(input2) {
          return getParsedType(input2.data);
        }
        _getOrReturnCtx(input2, ctx) {
          return ctx || {
            common: input2.parent.common,
            data: input2.data,
            parsedType: getParsedType(input2.data),
            schemaErrorMap: this._def.errorMap,
            path: input2.path,
            parent: input2.parent
          };
        }
        _processInputParams(input2) {
          return {
            status: new ParseStatus(),
            ctx: {
              common: input2.parent.common,
              data: input2.data,
              parsedType: getParsedType(input2.data),
              schemaErrorMap: this._def.errorMap,
              path: input2.path,
              parent: input2.parent
            }
          };
        }
        _parseSync(input2) {
          const result = this._parse(input2);
          if (isAsync(result)) {
            throw new Error("Synchronous parse encountered promise.");
          }
          return result;
        }
        _parseAsync(input2) {
          const result = this._parse(input2);
          return Promise.resolve(result);
        }
        parse(data, params2) {
          const result = this.safeParse(data, params2);
          if (result.success)
            return result.data;
          throw result.error;
        }
        safeParse(data, params2) {
          const ctx = {
            common: {
              issues: [],
              async: params2?.async ?? false,
              contextualErrorMap: params2?.errorMap
            },
            path: params2?.path || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          const result = this._parseSync({ data, path: ctx.path, parent: ctx });
          return handleResult(ctx, result);
        }
        "~validate"(data) {
          const ctx = {
            common: {
              issues: [],
              async: !!this["~standard"].async
            },
            path: [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          if (!this["~standard"].async) {
            try {
              const result = this._parseSync({ data, path: [], parent: ctx });
              return isValid(result) ? {
                value: result.value
              } : {
                issues: ctx.common.issues
              };
            } catch (err) {
              if (err?.message?.toLowerCase()?.includes("encountered")) {
                this["~standard"].async = true;
              }
              ctx.common = {
                issues: [],
                async: true
              };
            }
          }
          return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          });
        }
        async parseAsync(data, params2) {
          const result = await this.safeParseAsync(data, params2);
          if (result.success)
            return result.data;
          throw result.error;
        }
        async safeParseAsync(data, params2) {
          const ctx = {
            common: {
              issues: [],
              contextualErrorMap: params2?.errorMap,
              async: true
            },
            path: params2?.path || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
          const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
          return handleResult(ctx, result);
        }
        refine(check, message) {
          const getIssueProperties = (val) => {
            if (typeof message === "string" || typeof message === "undefined") {
              return { message };
            } else if (typeof message === "function") {
              return message(val);
            } else {
              return message;
            }
          };
          return this._refinement((val, ctx) => {
            const result = check(val);
            const setError = () => ctx.addIssue({
              code: ZodIssueCode.custom,
              ...getIssueProperties(val)
            });
            if (typeof Promise !== "undefined" && result instanceof Promise) {
              return result.then((data) => {
                if (!data) {
                  setError();
                  return false;
                } else {
                  return true;
                }
              });
            }
            if (!result) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        refinement(check, refinementData) {
          return this._refinement((val, ctx) => {
            if (!check(val)) {
              ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
              return false;
            } else {
              return true;
            }
          });
        }
        _refinement(refinement) {
          return new ZodEffects({
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "refinement", refinement }
          });
        }
        superRefine(refinement) {
          return this._refinement(refinement);
        }
        constructor(def) {
          this.spa = this.safeParseAsync;
          this._def = def;
          this.parse = this.parse.bind(this);
          this.safeParse = this.safeParse.bind(this);
          this.parseAsync = this.parseAsync.bind(this);
          this.safeParseAsync = this.safeParseAsync.bind(this);
          this.spa = this.spa.bind(this);
          this.refine = this.refine.bind(this);
          this.refinement = this.refinement.bind(this);
          this.superRefine = this.superRefine.bind(this);
          this.optional = this.optional.bind(this);
          this.nullable = this.nullable.bind(this);
          this.nullish = this.nullish.bind(this);
          this.array = this.array.bind(this);
          this.promise = this.promise.bind(this);
          this.or = this.or.bind(this);
          this.and = this.and.bind(this);
          this.transform = this.transform.bind(this);
          this.brand = this.brand.bind(this);
          this.default = this.default.bind(this);
          this.catch = this.catch.bind(this);
          this.describe = this.describe.bind(this);
          this.pipe = this.pipe.bind(this);
          this.readonly = this.readonly.bind(this);
          this.isNullable = this.isNullable.bind(this);
          this.isOptional = this.isOptional.bind(this);
          this["~standard"] = {
            version: 1,
            vendor: "zod",
            validate: (data) => this["~validate"](data)
          };
        }
        optional() {
          return ZodOptional.create(this, this._def);
        }
        nullable() {
          return ZodNullable.create(this, this._def);
        }
        nullish() {
          return this.nullable().optional();
        }
        array() {
          return ZodArray.create(this);
        }
        promise() {
          return ZodPromise.create(this, this._def);
        }
        or(option) {
          return ZodUnion.create([this, option], this._def);
        }
        and(incoming) {
          return ZodIntersection.create(this, incoming, this._def);
        }
        transform(transform) {
          return new ZodEffects({
            ...processCreateParams(this._def),
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "transform", transform }
          });
        }
        default(def) {
          const defaultValueFunc = typeof def === "function" ? def : () => def;
          return new ZodDefault({
            ...processCreateParams(this._def),
            innerType: this,
            defaultValue: defaultValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodDefault
          });
        }
        brand() {
          return new ZodBranded({
            typeName: ZodFirstPartyTypeKind.ZodBranded,
            type: this,
            ...processCreateParams(this._def)
          });
        }
        catch(def) {
          const catchValueFunc = typeof def === "function" ? def : () => def;
          return new ZodCatch({
            ...processCreateParams(this._def),
            innerType: this,
            catchValue: catchValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodCatch
          });
        }
        describe(description) {
          const This = this.constructor;
          return new This({
            ...this._def,
            description
          });
        }
        pipe(target) {
          return ZodPipeline.create(this, target);
        }
        readonly() {
          return ZodReadonly.create(this);
        }
        isOptional() {
          return this.safeParse(void 0).success;
        }
        isNullable() {
          return this.safeParse(null).success;
        }
      };
      cuidRegex = /^c[^\s-]{8,}$/i;
      cuid2Regex = /^[0-9a-z]+$/;
      ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
      uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
      nanoidRegex = /^[a-z0-9_-]{21}$/i;
      jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
      durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
      emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
      _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
      ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
      ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
      ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
      ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
      base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
      base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
      dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
      dateRegex = new RegExp(`^${dateRegexSource}$`);
      ZodString = class _ZodString extends ZodType {
        _parse(input2) {
          if (this._def.coerce) {
            input2.data = String(input2.data);
          }
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.string) {
            const ctx2 = this._getOrReturnCtx(input2);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.string,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          const status2 = new ParseStatus();
          let ctx = void 0;
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              if (input2.data.length < check.value) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: false,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "max") {
              if (input2.data.length > check.value) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: false,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "length") {
              const tooBig = input2.data.length > check.value;
              const tooSmall = input2.data.length < check.value;
              if (tooBig || tooSmall) {
                ctx = this._getOrReturnCtx(input2, ctx);
                if (tooBig) {
                  addIssueToContext(ctx, {
                    code: ZodIssueCode.too_big,
                    maximum: check.value,
                    type: "string",
                    inclusive: true,
                    exact: true,
                    message: check.message
                  });
                } else if (tooSmall) {
                  addIssueToContext(ctx, {
                    code: ZodIssueCode.too_small,
                    minimum: check.value,
                    type: "string",
                    inclusive: true,
                    exact: true,
                    message: check.message
                  });
                }
                status2.dirty();
              }
            } else if (check.kind === "email") {
              if (!emailRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "email",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "emoji") {
              if (!emojiRegex) {
                emojiRegex = new RegExp(_emojiRegex, "u");
              }
              if (!emojiRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "emoji",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "uuid") {
              if (!uuidRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "uuid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "nanoid") {
              if (!nanoidRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "nanoid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "cuid") {
              if (!cuidRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "cuid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "cuid2") {
              if (!cuid2Regex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "cuid2",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "ulid") {
              if (!ulidRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "ulid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "url") {
              try {
                new URL(input2.data);
              } catch {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "url",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "regex") {
              check.regex.lastIndex = 0;
              const testResult = check.regex.test(input2.data);
              if (!testResult) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "regex",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "trim") {
              input2.data = input2.data.trim();
            } else if (check.kind === "includes") {
              if (!input2.data.includes(check.value, check.position)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { includes: check.value, position: check.position },
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "toLowerCase") {
              input2.data = input2.data.toLowerCase();
            } else if (check.kind === "toUpperCase") {
              input2.data = input2.data.toUpperCase();
            } else if (check.kind === "startsWith") {
              if (!input2.data.startsWith(check.value)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { startsWith: check.value },
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "endsWith") {
              if (!input2.data.endsWith(check.value)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { endsWith: check.value },
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "datetime") {
              const regex = datetimeRegex(check);
              if (!regex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "datetime",
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "date") {
              const regex = dateRegex;
              if (!regex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "date",
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "time") {
              const regex = timeRegex(check);
              if (!regex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "time",
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "duration") {
              if (!durationRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "duration",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "ip") {
              if (!isValidIP(input2.data, check.version)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "ip",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "jwt") {
              if (!isValidJWT(input2.data, check.alg)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "jwt",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "cidr") {
              if (!isValidCidr(input2.data, check.version)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "cidr",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "base64") {
              if (!base64Regex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "base64",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "base64url") {
              if (!base64urlRegex.test(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  validation: "base64url",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status2.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status2.value, value: input2.data };
        }
        _regex(regex, validation, message) {
          return this.refinement((data) => regex.test(data), {
            validation,
            code: ZodIssueCode.invalid_string,
            ...errorUtil.errToObj(message)
          });
        }
        _addCheck(check) {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        email(message) {
          return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
        }
        url(message) {
          return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
        }
        emoji(message) {
          return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
        }
        uuid(message) {
          return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
        }
        nanoid(message) {
          return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
        }
        cuid(message) {
          return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
        }
        cuid2(message) {
          return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
        }
        ulid(message) {
          return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
        }
        base64(message) {
          return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
        }
        base64url(message) {
          return this._addCheck({
            kind: "base64url",
            ...errorUtil.errToObj(message)
          });
        }
        jwt(options) {
          return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
        }
        ip(options) {
          return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
        }
        cidr(options) {
          return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
        }
        datetime(options) {
          if (typeof options === "string") {
            return this._addCheck({
              kind: "datetime",
              precision: null,
              offset: false,
              local: false,
              message: options
            });
          }
          return this._addCheck({
            kind: "datetime",
            precision: typeof options?.precision === "undefined" ? null : options?.precision,
            offset: options?.offset ?? false,
            local: options?.local ?? false,
            ...errorUtil.errToObj(options?.message)
          });
        }
        date(message) {
          return this._addCheck({ kind: "date", message });
        }
        time(options) {
          if (typeof options === "string") {
            return this._addCheck({
              kind: "time",
              precision: null,
              message: options
            });
          }
          return this._addCheck({
            kind: "time",
            precision: typeof options?.precision === "undefined" ? null : options?.precision,
            ...errorUtil.errToObj(options?.message)
          });
        }
        duration(message) {
          return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
        }
        regex(regex, message) {
          return this._addCheck({
            kind: "regex",
            regex,
            ...errorUtil.errToObj(message)
          });
        }
        includes(value, options) {
          return this._addCheck({
            kind: "includes",
            value,
            position: options?.position,
            ...errorUtil.errToObj(options?.message)
          });
        }
        startsWith(value, message) {
          return this._addCheck({
            kind: "startsWith",
            value,
            ...errorUtil.errToObj(message)
          });
        }
        endsWith(value, message) {
          return this._addCheck({
            kind: "endsWith",
            value,
            ...errorUtil.errToObj(message)
          });
        }
        min(minLength, message) {
          return this._addCheck({
            kind: "min",
            value: minLength,
            ...errorUtil.errToObj(message)
          });
        }
        max(maxLength, message) {
          return this._addCheck({
            kind: "max",
            value: maxLength,
            ...errorUtil.errToObj(message)
          });
        }
        length(len, message) {
          return this._addCheck({
            kind: "length",
            value: len,
            ...errorUtil.errToObj(message)
          });
        }
        /**
         * Equivalent to `.min(1)`
         */
        nonempty(message) {
          return this.min(1, errorUtil.errToObj(message));
        }
        trim() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "trim" }]
          });
        }
        toLowerCase() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toLowerCase" }]
          });
        }
        toUpperCase() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toUpperCase" }]
          });
        }
        get isDatetime() {
          return !!this._def.checks.find((ch) => ch.kind === "datetime");
        }
        get isDate() {
          return !!this._def.checks.find((ch) => ch.kind === "date");
        }
        get isTime() {
          return !!this._def.checks.find((ch) => ch.kind === "time");
        }
        get isDuration() {
          return !!this._def.checks.find((ch) => ch.kind === "duration");
        }
        get isEmail() {
          return !!this._def.checks.find((ch) => ch.kind === "email");
        }
        get isURL() {
          return !!this._def.checks.find((ch) => ch.kind === "url");
        }
        get isEmoji() {
          return !!this._def.checks.find((ch) => ch.kind === "emoji");
        }
        get isUUID() {
          return !!this._def.checks.find((ch) => ch.kind === "uuid");
        }
        get isNANOID() {
          return !!this._def.checks.find((ch) => ch.kind === "nanoid");
        }
        get isCUID() {
          return !!this._def.checks.find((ch) => ch.kind === "cuid");
        }
        get isCUID2() {
          return !!this._def.checks.find((ch) => ch.kind === "cuid2");
        }
        get isULID() {
          return !!this._def.checks.find((ch) => ch.kind === "ulid");
        }
        get isIP() {
          return !!this._def.checks.find((ch) => ch.kind === "ip");
        }
        get isCIDR() {
          return !!this._def.checks.find((ch) => ch.kind === "cidr");
        }
        get isBase64() {
          return !!this._def.checks.find((ch) => ch.kind === "base64");
        }
        get isBase64url() {
          return !!this._def.checks.find((ch) => ch.kind === "base64url");
        }
        get minLength() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxLength() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
      };
      ZodString.create = (params2) => {
        return new ZodString({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodString,
          coerce: params2?.coerce ?? false,
          ...processCreateParams(params2)
        });
      };
      ZodNumber = class _ZodNumber extends ZodType {
        constructor() {
          super(...arguments);
          this.min = this.gte;
          this.max = this.lte;
          this.step = this.multipleOf;
        }
        _parse(input2) {
          if (this._def.coerce) {
            input2.data = Number(input2.data);
          }
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.number) {
            const ctx2 = this._getOrReturnCtx(input2);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.number,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          let ctx = void 0;
          const status2 = new ParseStatus();
          for (const check of this._def.checks) {
            if (check.kind === "int") {
              if (!util.isInteger(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_type,
                  expected: "integer",
                  received: "float",
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "min") {
              const tooSmall = check.inclusive ? input2.data < check.value : input2.data <= check.value;
              if (tooSmall) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "number",
                  inclusive: check.inclusive,
                  exact: false,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "max") {
              const tooBig = check.inclusive ? input2.data > check.value : input2.data >= check.value;
              if (tooBig) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "number",
                  inclusive: check.inclusive,
                  exact: false,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "multipleOf") {
              if (floatSafeRemainder(input2.data, check.value) !== 0) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_multiple_of,
                  multipleOf: check.value,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "finite") {
              if (!Number.isFinite(input2.data)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_finite,
                  message: check.message
                });
                status2.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status2.value, value: input2.data };
        }
        gte(value, message) {
          return this.setLimit("min", value, true, errorUtil.toString(message));
        }
        gt(value, message) {
          return this.setLimit("min", value, false, errorUtil.toString(message));
        }
        lte(value, message) {
          return this.setLimit("max", value, true, errorUtil.toString(message));
        }
        lt(value, message) {
          return this.setLimit("max", value, false, errorUtil.toString(message));
        }
        setLimit(kind, value, inclusive, message) {
          return new _ZodNumber({
            ...this._def,
            checks: [
              ...this._def.checks,
              {
                kind,
                value,
                inclusive,
                message: errorUtil.toString(message)
              }
            ]
          });
        }
        _addCheck(check) {
          return new _ZodNumber({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        int(message) {
          return this._addCheck({
            kind: "int",
            message: errorUtil.toString(message)
          });
        }
        positive(message) {
          return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        negative(message) {
          return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        nonpositive(message) {
          return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        nonnegative(message) {
          return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        multipleOf(value, message) {
          return this._addCheck({
            kind: "multipleOf",
            value,
            message: errorUtil.toString(message)
          });
        }
        finite(message) {
          return this._addCheck({
            kind: "finite",
            message: errorUtil.toString(message)
          });
        }
        safe(message) {
          return this._addCheck({
            kind: "min",
            inclusive: true,
            value: Number.MIN_SAFE_INTEGER,
            message: errorUtil.toString(message)
          })._addCheck({
            kind: "max",
            inclusive: true,
            value: Number.MAX_SAFE_INTEGER,
            message: errorUtil.toString(message)
          });
        }
        get minValue() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxValue() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
        get isInt() {
          return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
        }
        get isFinite() {
          let max = null;
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
              return true;
            } else if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            } else if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return Number.isFinite(min) && Number.isFinite(max);
        }
      };
      ZodNumber.create = (params2) => {
        return new ZodNumber({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodNumber,
          coerce: params2?.coerce || false,
          ...processCreateParams(params2)
        });
      };
      ZodBigInt = class _ZodBigInt extends ZodType {
        constructor() {
          super(...arguments);
          this.min = this.gte;
          this.max = this.lte;
        }
        _parse(input2) {
          if (this._def.coerce) {
            try {
              input2.data = BigInt(input2.data);
            } catch {
              return this._getInvalidInput(input2);
            }
          }
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.bigint) {
            return this._getInvalidInput(input2);
          }
          let ctx = void 0;
          const status2 = new ParseStatus();
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              const tooSmall = check.inclusive ? input2.data < check.value : input2.data <= check.value;
              if (tooSmall) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  type: "bigint",
                  minimum: check.value,
                  inclusive: check.inclusive,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "max") {
              const tooBig = check.inclusive ? input2.data > check.value : input2.data >= check.value;
              if (tooBig) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  type: "bigint",
                  maximum: check.value,
                  inclusive: check.inclusive,
                  message: check.message
                });
                status2.dirty();
              }
            } else if (check.kind === "multipleOf") {
              if (input2.data % check.value !== BigInt(0)) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_multiple_of,
                  multipleOf: check.value,
                  message: check.message
                });
                status2.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status2.value, value: input2.data };
        }
        _getInvalidInput(input2) {
          const ctx = this._getOrReturnCtx(input2);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.bigint,
            received: ctx.parsedType
          });
          return INVALID;
        }
        gte(value, message) {
          return this.setLimit("min", value, true, errorUtil.toString(message));
        }
        gt(value, message) {
          return this.setLimit("min", value, false, errorUtil.toString(message));
        }
        lte(value, message) {
          return this.setLimit("max", value, true, errorUtil.toString(message));
        }
        lt(value, message) {
          return this.setLimit("max", value, false, errorUtil.toString(message));
        }
        setLimit(kind, value, inclusive, message) {
          return new _ZodBigInt({
            ...this._def,
            checks: [
              ...this._def.checks,
              {
                kind,
                value,
                inclusive,
                message: errorUtil.toString(message)
              }
            ]
          });
        }
        _addCheck(check) {
          return new _ZodBigInt({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        positive(message) {
          return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        negative(message) {
          return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        nonpositive(message) {
          return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        nonnegative(message) {
          return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        multipleOf(value, message) {
          return this._addCheck({
            kind: "multipleOf",
            value,
            message: errorUtil.toString(message)
          });
        }
        get minValue() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxValue() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
      };
      ZodBigInt.create = (params2) => {
        return new ZodBigInt({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodBigInt,
          coerce: params2?.coerce ?? false,
          ...processCreateParams(params2)
        });
      };
      ZodBoolean = class extends ZodType {
        _parse(input2) {
          if (this._def.coerce) {
            input2.data = Boolean(input2.data);
          }
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.boolean) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.boolean,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input2.data);
        }
      };
      ZodBoolean.create = (params2) => {
        return new ZodBoolean({
          typeName: ZodFirstPartyTypeKind.ZodBoolean,
          coerce: params2?.coerce || false,
          ...processCreateParams(params2)
        });
      };
      ZodDate = class _ZodDate extends ZodType {
        _parse(input2) {
          if (this._def.coerce) {
            input2.data = new Date(input2.data);
          }
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.date) {
            const ctx2 = this._getOrReturnCtx(input2);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.date,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          if (Number.isNaN(input2.data.getTime())) {
            const ctx2 = this._getOrReturnCtx(input2);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_date
            });
            return INVALID;
          }
          const status2 = new ParseStatus();
          let ctx = void 0;
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              if (input2.data.getTime() < check.value) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  message: check.message,
                  inclusive: true,
                  exact: false,
                  minimum: check.value,
                  type: "date"
                });
                status2.dirty();
              }
            } else if (check.kind === "max") {
              if (input2.data.getTime() > check.value) {
                ctx = this._getOrReturnCtx(input2, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  message: check.message,
                  inclusive: true,
                  exact: false,
                  maximum: check.value,
                  type: "date"
                });
                status2.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return {
            status: status2.value,
            value: new Date(input2.data.getTime())
          };
        }
        _addCheck(check) {
          return new _ZodDate({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        min(minDate, message) {
          return this._addCheck({
            kind: "min",
            value: minDate.getTime(),
            message: errorUtil.toString(message)
          });
        }
        max(maxDate, message) {
          return this._addCheck({
            kind: "max",
            value: maxDate.getTime(),
            message: errorUtil.toString(message)
          });
        }
        get minDate() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min != null ? new Date(min) : null;
        }
        get maxDate() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max != null ? new Date(max) : null;
        }
      };
      ZodDate.create = (params2) => {
        return new ZodDate({
          checks: [],
          coerce: params2?.coerce || false,
          typeName: ZodFirstPartyTypeKind.ZodDate,
          ...processCreateParams(params2)
        });
      };
      ZodSymbol = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.symbol) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.symbol,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input2.data);
        }
      };
      ZodSymbol.create = (params2) => {
        return new ZodSymbol({
          typeName: ZodFirstPartyTypeKind.ZodSymbol,
          ...processCreateParams(params2)
        });
      };
      ZodUndefined = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.undefined,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input2.data);
        }
      };
      ZodUndefined.create = (params2) => {
        return new ZodUndefined({
          typeName: ZodFirstPartyTypeKind.ZodUndefined,
          ...processCreateParams(params2)
        });
      };
      ZodNull = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.null) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.null,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input2.data);
        }
      };
      ZodNull.create = (params2) => {
        return new ZodNull({
          typeName: ZodFirstPartyTypeKind.ZodNull,
          ...processCreateParams(params2)
        });
      };
      ZodAny = class extends ZodType {
        constructor() {
          super(...arguments);
          this._any = true;
        }
        _parse(input2) {
          return OK(input2.data);
        }
      };
      ZodAny.create = (params2) => {
        return new ZodAny({
          typeName: ZodFirstPartyTypeKind.ZodAny,
          ...processCreateParams(params2)
        });
      };
      ZodUnknown = class extends ZodType {
        constructor() {
          super(...arguments);
          this._unknown = true;
        }
        _parse(input2) {
          return OK(input2.data);
        }
      };
      ZodUnknown.create = (params2) => {
        return new ZodUnknown({
          typeName: ZodFirstPartyTypeKind.ZodUnknown,
          ...processCreateParams(params2)
        });
      };
      ZodNever = class extends ZodType {
        _parse(input2) {
          const ctx = this._getOrReturnCtx(input2);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.never,
            received: ctx.parsedType
          });
          return INVALID;
        }
      };
      ZodNever.create = (params2) => {
        return new ZodNever({
          typeName: ZodFirstPartyTypeKind.ZodNever,
          ...processCreateParams(params2)
        });
      };
      ZodVoid = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.void,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input2.data);
        }
      };
      ZodVoid.create = (params2) => {
        return new ZodVoid({
          typeName: ZodFirstPartyTypeKind.ZodVoid,
          ...processCreateParams(params2)
        });
      };
      ZodArray = class _ZodArray extends ZodType {
        _parse(input2) {
          const { ctx, status: status2 } = this._processInputParams(input2);
          const def = this._def;
          if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.array,
              received: ctx.parsedType
            });
            return INVALID;
          }
          if (def.exactLength !== null) {
            const tooBig = ctx.data.length > def.exactLength.value;
            const tooSmall = ctx.data.length < def.exactLength.value;
            if (tooBig || tooSmall) {
              addIssueToContext(ctx, {
                code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
                minimum: tooSmall ? def.exactLength.value : void 0,
                maximum: tooBig ? def.exactLength.value : void 0,
                type: "array",
                inclusive: true,
                exact: true,
                message: def.exactLength.message
              });
              status2.dirty();
            }
          }
          if (def.minLength !== null) {
            if (ctx.data.length < def.minLength.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: def.minLength.value,
                type: "array",
                inclusive: true,
                exact: false,
                message: def.minLength.message
              });
              status2.dirty();
            }
          }
          if (def.maxLength !== null) {
            if (ctx.data.length > def.maxLength.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: def.maxLength.value,
                type: "array",
                inclusive: true,
                exact: false,
                message: def.maxLength.message
              });
              status2.dirty();
            }
          }
          if (ctx.common.async) {
            return Promise.all([...ctx.data].map((item, i) => {
              return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
            })).then((result2) => {
              return ParseStatus.mergeArray(status2, result2);
            });
          }
          const result = [...ctx.data].map((item, i) => {
            return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
          });
          return ParseStatus.mergeArray(status2, result);
        }
        get element() {
          return this._def.type;
        }
        min(minLength, message) {
          return new _ZodArray({
            ...this._def,
            minLength: { value: minLength, message: errorUtil.toString(message) }
          });
        }
        max(maxLength, message) {
          return new _ZodArray({
            ...this._def,
            maxLength: { value: maxLength, message: errorUtil.toString(message) }
          });
        }
        length(len, message) {
          return new _ZodArray({
            ...this._def,
            exactLength: { value: len, message: errorUtil.toString(message) }
          });
        }
        nonempty(message) {
          return this.min(1, message);
        }
      };
      ZodArray.create = (schema, params2) => {
        return new ZodArray({
          type: schema,
          minLength: null,
          maxLength: null,
          exactLength: null,
          typeName: ZodFirstPartyTypeKind.ZodArray,
          ...processCreateParams(params2)
        });
      };
      ZodObject = class _ZodObject extends ZodType {
        constructor() {
          super(...arguments);
          this._cached = null;
          this.nonstrict = this.passthrough;
          this.augment = this.extend;
        }
        _getCached() {
          if (this._cached !== null)
            return this._cached;
          const shape = this._def.shape();
          const keys = util.objectKeys(shape);
          this._cached = { shape, keys };
          return this._cached;
        }
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.object) {
            const ctx2 = this._getOrReturnCtx(input2);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          const { status: status2, ctx } = this._processInputParams(input2);
          const { shape, keys: shapeKeys } = this._getCached();
          const extraKeys = [];
          if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
            for (const key in ctx.data) {
              if (!shapeKeys.includes(key)) {
                extraKeys.push(key);
              }
            }
          }
          const pairs = [];
          for (const key of shapeKeys) {
            const keyValidator = shape[key];
            const value = ctx.data[key];
            pairs.push({
              key: { status: "valid", value: key },
              value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
              alwaysSet: key in ctx.data
            });
          }
          if (this._def.catchall instanceof ZodNever) {
            const unknownKeys = this._def.unknownKeys;
            if (unknownKeys === "passthrough") {
              for (const key of extraKeys) {
                pairs.push({
                  key: { status: "valid", value: key },
                  value: { status: "valid", value: ctx.data[key] }
                });
              }
            } else if (unknownKeys === "strict") {
              if (extraKeys.length > 0) {
                addIssueToContext(ctx, {
                  code: ZodIssueCode.unrecognized_keys,
                  keys: extraKeys
                });
                status2.dirty();
              }
            } else if (unknownKeys === "strip") {
            } else {
              throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
            }
          } else {
            const catchall = this._def.catchall;
            for (const key of extraKeys) {
              const value = ctx.data[key];
              pairs.push({
                key: { status: "valid", value: key },
                value: catchall._parse(
                  new ParseInputLazyPath(ctx, value, ctx.path, key)
                  //, ctx.child(key), value, getParsedType(value)
                ),
                alwaysSet: key in ctx.data
              });
            }
          }
          if (ctx.common.async) {
            return Promise.resolve().then(async () => {
              const syncPairs = [];
              for (const pair of pairs) {
                const key = await pair.key;
                const value = await pair.value;
                syncPairs.push({
                  key,
                  value,
                  alwaysSet: pair.alwaysSet
                });
              }
              return syncPairs;
            }).then((syncPairs) => {
              return ParseStatus.mergeObjectSync(status2, syncPairs);
            });
          } else {
            return ParseStatus.mergeObjectSync(status2, pairs);
          }
        }
        get shape() {
          return this._def.shape();
        }
        strict(message) {
          errorUtil.errToObj;
          return new _ZodObject({
            ...this._def,
            unknownKeys: "strict",
            ...message !== void 0 ? {
              errorMap: (issue, ctx) => {
                const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
                if (issue.code === "unrecognized_keys")
                  return {
                    message: errorUtil.errToObj(message).message ?? defaultError
                  };
                return {
                  message: defaultError
                };
              }
            } : {}
          });
        }
        strip() {
          return new _ZodObject({
            ...this._def,
            unknownKeys: "strip"
          });
        }
        passthrough() {
          return new _ZodObject({
            ...this._def,
            unknownKeys: "passthrough"
          });
        }
        // const AugmentFactory =
        //   <Def extends ZodObjectDef>(def: Def) =>
        //   <Augmentation extends ZodRawShape>(
        //     augmentation: Augmentation
        //   ): ZodObject<
        //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
        //     Def["unknownKeys"],
        //     Def["catchall"]
        //   > => {
        //     return new ZodObject({
        //       ...def,
        //       shape: () => ({
        //         ...def.shape(),
        //         ...augmentation,
        //       }),
        //     }) as any;
        //   };
        extend(augmentation) {
          return new _ZodObject({
            ...this._def,
            shape: () => ({
              ...this._def.shape(),
              ...augmentation
            })
          });
        }
        /**
         * Prior to zod@1.0.12 there was a bug in the
         * inferred type of merged objects. Please
         * upgrade if you are experiencing issues.
         */
        merge(merging) {
          const merged = new _ZodObject({
            unknownKeys: merging._def.unknownKeys,
            catchall: merging._def.catchall,
            shape: () => ({
              ...this._def.shape(),
              ...merging._def.shape()
            }),
            typeName: ZodFirstPartyTypeKind.ZodObject
          });
          return merged;
        }
        // merge<
        //   Incoming extends AnyZodObject,
        //   Augmentation extends Incoming["shape"],
        //   NewOutput extends {
        //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
        //       ? Augmentation[k]["_output"]
        //       : k extends keyof Output
        //       ? Output[k]
        //       : never;
        //   },
        //   NewInput extends {
        //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
        //       ? Augmentation[k]["_input"]
        //       : k extends keyof Input
        //       ? Input[k]
        //       : never;
        //   }
        // >(
        //   merging: Incoming
        // ): ZodObject<
        //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
        //   Incoming["_def"]["unknownKeys"],
        //   Incoming["_def"]["catchall"],
        //   NewOutput,
        //   NewInput
        // > {
        //   const merged: any = new ZodObject({
        //     unknownKeys: merging._def.unknownKeys,
        //     catchall: merging._def.catchall,
        //     shape: () =>
        //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
        //     typeName: ZodFirstPartyTypeKind.ZodObject,
        //   }) as any;
        //   return merged;
        // }
        setKey(key, schema) {
          return this.augment({ [key]: schema });
        }
        // merge<Incoming extends AnyZodObject>(
        //   merging: Incoming
        // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
        // ZodObject<
        //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
        //   Incoming["_def"]["unknownKeys"],
        //   Incoming["_def"]["catchall"]
        // > {
        //   // const mergedShape = objectUtil.mergeShapes(
        //   //   this._def.shape(),
        //   //   merging._def.shape()
        //   // );
        //   const merged: any = new ZodObject({
        //     unknownKeys: merging._def.unknownKeys,
        //     catchall: merging._def.catchall,
        //     shape: () =>
        //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
        //     typeName: ZodFirstPartyTypeKind.ZodObject,
        //   }) as any;
        //   return merged;
        // }
        catchall(index) {
          return new _ZodObject({
            ...this._def,
            catchall: index
          });
        }
        pick(mask) {
          const shape = {};
          for (const key of util.objectKeys(mask)) {
            if (mask[key] && this.shape[key]) {
              shape[key] = this.shape[key];
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => shape
          });
        }
        omit(mask) {
          const shape = {};
          for (const key of util.objectKeys(this.shape)) {
            if (!mask[key]) {
              shape[key] = this.shape[key];
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => shape
          });
        }
        /**
         * @deprecated
         */
        deepPartial() {
          return deepPartialify(this);
        }
        partial(mask) {
          const newShape = {};
          for (const key of util.objectKeys(this.shape)) {
            const fieldSchema = this.shape[key];
            if (mask && !mask[key]) {
              newShape[key] = fieldSchema;
            } else {
              newShape[key] = fieldSchema.optional();
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => newShape
          });
        }
        required(mask) {
          const newShape = {};
          for (const key of util.objectKeys(this.shape)) {
            if (mask && !mask[key]) {
              newShape[key] = this.shape[key];
            } else {
              const fieldSchema = this.shape[key];
              let newField = fieldSchema;
              while (newField instanceof ZodOptional) {
                newField = newField._def.innerType;
              }
              newShape[key] = newField;
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => newShape
          });
        }
        keyof() {
          return createZodEnum(util.objectKeys(this.shape));
        }
      };
      ZodObject.create = (shape, params2) => {
        return new ZodObject({
          shape: () => shape,
          unknownKeys: "strip",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params2)
        });
      };
      ZodObject.strictCreate = (shape, params2) => {
        return new ZodObject({
          shape: () => shape,
          unknownKeys: "strict",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params2)
        });
      };
      ZodObject.lazycreate = (shape, params2) => {
        return new ZodObject({
          shape,
          unknownKeys: "strip",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params2)
        });
      };
      ZodUnion = class extends ZodType {
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          const options = this._def.options;
          function handleResults(results) {
            for (const result of results) {
              if (result.result.status === "valid") {
                return result.result;
              }
            }
            for (const result of results) {
              if (result.result.status === "dirty") {
                ctx.common.issues.push(...result.ctx.common.issues);
                return result.result;
              }
            }
            const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union,
              unionErrors
            });
            return INVALID;
          }
          if (ctx.common.async) {
            return Promise.all(options.map(async (option) => {
              const childCtx = {
                ...ctx,
                common: {
                  ...ctx.common,
                  issues: []
                },
                parent: null
              };
              return {
                result: await option._parseAsync({
                  data: ctx.data,
                  path: ctx.path,
                  parent: childCtx
                }),
                ctx: childCtx
              };
            })).then(handleResults);
          } else {
            let dirty = void 0;
            const issues = [];
            for (const option of options) {
              const childCtx = {
                ...ctx,
                common: {
                  ...ctx.common,
                  issues: []
                },
                parent: null
              };
              const result = option._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: childCtx
              });
              if (result.status === "valid") {
                return result;
              } else if (result.status === "dirty" && !dirty) {
                dirty = { result, ctx: childCtx };
              }
              if (childCtx.common.issues.length) {
                issues.push(childCtx.common.issues);
              }
            }
            if (dirty) {
              ctx.common.issues.push(...dirty.ctx.common.issues);
              return dirty.result;
            }
            const unionErrors = issues.map((issues2) => new ZodError(issues2));
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union,
              unionErrors
            });
            return INVALID;
          }
        }
        get options() {
          return this._def.options;
        }
      };
      ZodUnion.create = (types, params2) => {
        return new ZodUnion({
          options: types,
          typeName: ZodFirstPartyTypeKind.ZodUnion,
          ...processCreateParams(params2)
        });
      };
      getDiscriminator = (type) => {
        if (type instanceof ZodLazy) {
          return getDiscriminator(type.schema);
        } else if (type instanceof ZodEffects) {
          return getDiscriminator(type.innerType());
        } else if (type instanceof ZodLiteral) {
          return [type.value];
        } else if (type instanceof ZodEnum) {
          return type.options;
        } else if (type instanceof ZodNativeEnum) {
          return util.objectValues(type.enum);
        } else if (type instanceof ZodDefault) {
          return getDiscriminator(type._def.innerType);
        } else if (type instanceof ZodUndefined) {
          return [void 0];
        } else if (type instanceof ZodNull) {
          return [null];
        } else if (type instanceof ZodOptional) {
          return [void 0, ...getDiscriminator(type.unwrap())];
        } else if (type instanceof ZodNullable) {
          return [null, ...getDiscriminator(type.unwrap())];
        } else if (type instanceof ZodBranded) {
          return getDiscriminator(type.unwrap());
        } else if (type instanceof ZodReadonly) {
          return getDiscriminator(type.unwrap());
        } else if (type instanceof ZodCatch) {
          return getDiscriminator(type._def.innerType);
        } else {
          return [];
        }
      };
      ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const discriminator = this.discriminator;
          const discriminatorValue = ctx.data[discriminator];
          const option = this.optionsMap.get(discriminatorValue);
          if (!option) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union_discriminator,
              options: Array.from(this.optionsMap.keys()),
              path: [discriminator]
            });
            return INVALID;
          }
          if (ctx.common.async) {
            return option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
          } else {
            return option._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
          }
        }
        get discriminator() {
          return this._def.discriminator;
        }
        get options() {
          return this._def.options;
        }
        get optionsMap() {
          return this._def.optionsMap;
        }
        /**
         * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
         * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
         * have a different value for each object in the union.
         * @param discriminator the name of the discriminator property
         * @param types an array of object schemas
         * @param params
         */
        static create(discriminator, options, params2) {
          const optionsMap = /* @__PURE__ */ new Map();
          for (const type of options) {
            const discriminatorValues = getDiscriminator(type.shape[discriminator]);
            if (!discriminatorValues.length) {
              throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
            }
            for (const value of discriminatorValues) {
              if (optionsMap.has(value)) {
                throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
              }
              optionsMap.set(value, type);
            }
          }
          return new _ZodDiscriminatedUnion({
            typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
            discriminator,
            options,
            optionsMap,
            ...processCreateParams(params2)
          });
        }
      };
      ZodIntersection = class extends ZodType {
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          const handleParsed = (parsedLeft, parsedRight) => {
            if (isAborted(parsedLeft) || isAborted(parsedRight)) {
              return INVALID;
            }
            const merged = mergeValues(parsedLeft.value, parsedRight.value);
            if (!merged.valid) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_intersection_types
              });
              return INVALID;
            }
            if (isDirty(parsedLeft) || isDirty(parsedRight)) {
              status2.dirty();
            }
            return { status: status2.value, value: merged.data };
          };
          if (ctx.common.async) {
            return Promise.all([
              this._def.left._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              }),
              this._def.right._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              })
            ]).then(([left, right]) => handleParsed(left, right));
          } else {
            return handleParsed(this._def.left._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }), this._def.right._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }));
          }
        }
      };
      ZodIntersection.create = (left, right, params2) => {
        return new ZodIntersection({
          left,
          right,
          typeName: ZodFirstPartyTypeKind.ZodIntersection,
          ...processCreateParams(params2)
        });
      };
      ZodTuple = class _ZodTuple extends ZodType {
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.array,
              received: ctx.parsedType
            });
            return INVALID;
          }
          if (ctx.data.length < this._def.items.length) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: this._def.items.length,
              inclusive: true,
              exact: false,
              type: "array"
            });
            return INVALID;
          }
          const rest = this._def.rest;
          if (!rest && ctx.data.length > this._def.items.length) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: this._def.items.length,
              inclusive: true,
              exact: false,
              type: "array"
            });
            status2.dirty();
          }
          const items = [...ctx.data].map((item, itemIndex) => {
            const schema = this._def.items[itemIndex] || this._def.rest;
            if (!schema)
              return null;
            return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
          }).filter((x) => !!x);
          if (ctx.common.async) {
            return Promise.all(items).then((results) => {
              return ParseStatus.mergeArray(status2, results);
            });
          } else {
            return ParseStatus.mergeArray(status2, items);
          }
        }
        get items() {
          return this._def.items;
        }
        rest(rest) {
          return new _ZodTuple({
            ...this._def,
            rest
          });
        }
      };
      ZodTuple.create = (schemas, params2) => {
        if (!Array.isArray(schemas)) {
          throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
        }
        return new ZodTuple({
          items: schemas,
          typeName: ZodFirstPartyTypeKind.ZodTuple,
          rest: null,
          ...processCreateParams(params2)
        });
      };
      ZodRecord = class _ZodRecord extends ZodType {
        get keySchema() {
          return this._def.keyType;
        }
        get valueSchema() {
          return this._def.valueType;
        }
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const pairs = [];
          const keyType = this._def.keyType;
          const valueType = this._def.valueType;
          for (const key in ctx.data) {
            pairs.push({
              key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
              value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
              alwaysSet: key in ctx.data
            });
          }
          if (ctx.common.async) {
            return ParseStatus.mergeObjectAsync(status2, pairs);
          } else {
            return ParseStatus.mergeObjectSync(status2, pairs);
          }
        }
        get element() {
          return this._def.valueType;
        }
        static create(first, second, third) {
          if (second instanceof ZodType) {
            return new _ZodRecord({
              keyType: first,
              valueType: second,
              typeName: ZodFirstPartyTypeKind.ZodRecord,
              ...processCreateParams(third)
            });
          }
          return new _ZodRecord({
            keyType: ZodString.create(),
            valueType: first,
            typeName: ZodFirstPartyTypeKind.ZodRecord,
            ...processCreateParams(second)
          });
        }
      };
      ZodMap = class extends ZodType {
        get keySchema() {
          return this._def.keyType;
        }
        get valueSchema() {
          return this._def.valueType;
        }
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.map) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.map,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const keyType = this._def.keyType;
          const valueType = this._def.valueType;
          const pairs = [...ctx.data.entries()].map(([key, value], index) => {
            return {
              key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
              value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
            };
          });
          if (ctx.common.async) {
            const finalMap = /* @__PURE__ */ new Map();
            return Promise.resolve().then(async () => {
              for (const pair of pairs) {
                const key = await pair.key;
                const value = await pair.value;
                if (key.status === "aborted" || value.status === "aborted") {
                  return INVALID;
                }
                if (key.status === "dirty" || value.status === "dirty") {
                  status2.dirty();
                }
                finalMap.set(key.value, value.value);
              }
              return { status: status2.value, value: finalMap };
            });
          } else {
            const finalMap = /* @__PURE__ */ new Map();
            for (const pair of pairs) {
              const key = pair.key;
              const value = pair.value;
              if (key.status === "aborted" || value.status === "aborted") {
                return INVALID;
              }
              if (key.status === "dirty" || value.status === "dirty") {
                status2.dirty();
              }
              finalMap.set(key.value, value.value);
            }
            return { status: status2.value, value: finalMap };
          }
        }
      };
      ZodMap.create = (keyType, valueType, params2) => {
        return new ZodMap({
          valueType,
          keyType,
          typeName: ZodFirstPartyTypeKind.ZodMap,
          ...processCreateParams(params2)
        });
      };
      ZodSet = class _ZodSet extends ZodType {
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.set) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.set,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const def = this._def;
          if (def.minSize !== null) {
            if (ctx.data.size < def.minSize.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: def.minSize.value,
                type: "set",
                inclusive: true,
                exact: false,
                message: def.minSize.message
              });
              status2.dirty();
            }
          }
          if (def.maxSize !== null) {
            if (ctx.data.size > def.maxSize.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: def.maxSize.value,
                type: "set",
                inclusive: true,
                exact: false,
                message: def.maxSize.message
              });
              status2.dirty();
            }
          }
          const valueType = this._def.valueType;
          function finalizeSet(elements2) {
            const parsedSet = /* @__PURE__ */ new Set();
            for (const element2 of elements2) {
              if (element2.status === "aborted")
                return INVALID;
              if (element2.status === "dirty")
                status2.dirty();
              parsedSet.add(element2.value);
            }
            return { status: status2.value, value: parsedSet };
          }
          const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
          if (ctx.common.async) {
            return Promise.all(elements).then((elements2) => finalizeSet(elements2));
          } else {
            return finalizeSet(elements);
          }
        }
        min(minSize, message) {
          return new _ZodSet({
            ...this._def,
            minSize: { value: minSize, message: errorUtil.toString(message) }
          });
        }
        max(maxSize, message) {
          return new _ZodSet({
            ...this._def,
            maxSize: { value: maxSize, message: errorUtil.toString(message) }
          });
        }
        size(size, message) {
          return this.min(size, message).max(size, message);
        }
        nonempty(message) {
          return this.min(1, message);
        }
      };
      ZodSet.create = (valueType, params2) => {
        return new ZodSet({
          valueType,
          minSize: null,
          maxSize: null,
          typeName: ZodFirstPartyTypeKind.ZodSet,
          ...processCreateParams(params2)
        });
      };
      ZodFunction = class _ZodFunction extends ZodType {
        constructor() {
          super(...arguments);
          this.validate = this.implement;
        }
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.function) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.function,
              received: ctx.parsedType
            });
            return INVALID;
          }
          function makeArgsIssue(args, error) {
            return makeIssue({
              data: args,
              path: ctx.path,
              errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
              issueData: {
                code: ZodIssueCode.invalid_arguments,
                argumentsError: error
              }
            });
          }
          function makeReturnsIssue(returns, error) {
            return makeIssue({
              data: returns,
              path: ctx.path,
              errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
              issueData: {
                code: ZodIssueCode.invalid_return_type,
                returnTypeError: error
              }
            });
          }
          const params2 = { errorMap: ctx.common.contextualErrorMap };
          const fn = ctx.data;
          if (this._def.returns instanceof ZodPromise) {
            const me = this;
            return OK(async function(...args) {
              const error = new ZodError([]);
              const parsedArgs = await me._def.args.parseAsync(args, params2).catch((e) => {
                error.addIssue(makeArgsIssue(args, e));
                throw error;
              });
              const result = await Reflect.apply(fn, this, parsedArgs);
              const parsedReturns = await me._def.returns._def.type.parseAsync(result, params2).catch((e) => {
                error.addIssue(makeReturnsIssue(result, e));
                throw error;
              });
              return parsedReturns;
            });
          } else {
            const me = this;
            return OK(function(...args) {
              const parsedArgs = me._def.args.safeParse(args, params2);
              if (!parsedArgs.success) {
                throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
              }
              const result = Reflect.apply(fn, this, parsedArgs.data);
              const parsedReturns = me._def.returns.safeParse(result, params2);
              if (!parsedReturns.success) {
                throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
              }
              return parsedReturns.data;
            });
          }
        }
        parameters() {
          return this._def.args;
        }
        returnType() {
          return this._def.returns;
        }
        args(...items) {
          return new _ZodFunction({
            ...this._def,
            args: ZodTuple.create(items).rest(ZodUnknown.create())
          });
        }
        returns(returnType) {
          return new _ZodFunction({
            ...this._def,
            returns: returnType
          });
        }
        implement(func) {
          const validatedFunc = this.parse(func);
          return validatedFunc;
        }
        strictImplement(func) {
          const validatedFunc = this.parse(func);
          return validatedFunc;
        }
        static create(args, returns, params2) {
          return new _ZodFunction({
            args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
            returns: returns || ZodUnknown.create(),
            typeName: ZodFirstPartyTypeKind.ZodFunction,
            ...processCreateParams(params2)
          });
        }
      };
      ZodLazy = class extends ZodType {
        get schema() {
          return this._def.getter();
        }
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          const lazySchema = this._def.getter();
          return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
        }
      };
      ZodLazy.create = (getter, params2) => {
        return new ZodLazy({
          getter,
          typeName: ZodFirstPartyTypeKind.ZodLazy,
          ...processCreateParams(params2)
        });
      };
      ZodLiteral = class extends ZodType {
        _parse(input2) {
          if (input2.data !== this._def.value) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_literal,
              expected: this._def.value
            });
            return INVALID;
          }
          return { status: "valid", value: input2.data };
        }
        get value() {
          return this._def.value;
        }
      };
      ZodLiteral.create = (value, params2) => {
        return new ZodLiteral({
          value,
          typeName: ZodFirstPartyTypeKind.ZodLiteral,
          ...processCreateParams(params2)
        });
      };
      ZodEnum = class _ZodEnum extends ZodType {
        _parse(input2) {
          if (typeof input2.data !== "string") {
            const ctx = this._getOrReturnCtx(input2);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
              expected: util.joinValues(expectedValues),
              received: ctx.parsedType,
              code: ZodIssueCode.invalid_type
            });
            return INVALID;
          }
          if (!this._cache) {
            this._cache = new Set(this._def.values);
          }
          if (!this._cache.has(input2.data)) {
            const ctx = this._getOrReturnCtx(input2);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_enum_value,
              options: expectedValues
            });
            return INVALID;
          }
          return OK(input2.data);
        }
        get options() {
          return this._def.values;
        }
        get enum() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        get Values() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        get Enum() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        extract(values, newDef = this._def) {
          return _ZodEnum.create(values, {
            ...this._def,
            ...newDef
          });
        }
        exclude(values, newDef = this._def) {
          return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
            ...this._def,
            ...newDef
          });
        }
      };
      ZodEnum.create = createZodEnum;
      ZodNativeEnum = class extends ZodType {
        _parse(input2) {
          const nativeEnumValues = util.getValidEnumValues(this._def.values);
          const ctx = this._getOrReturnCtx(input2);
          if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
            const expectedValues = util.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
              expected: util.joinValues(expectedValues),
              received: ctx.parsedType,
              code: ZodIssueCode.invalid_type
            });
            return INVALID;
          }
          if (!this._cache) {
            this._cache = new Set(util.getValidEnumValues(this._def.values));
          }
          if (!this._cache.has(input2.data)) {
            const expectedValues = util.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_enum_value,
              options: expectedValues
            });
            return INVALID;
          }
          return OK(input2.data);
        }
        get enum() {
          return this._def.values;
        }
      };
      ZodNativeEnum.create = (values, params2) => {
        return new ZodNativeEnum({
          values,
          typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
          ...processCreateParams(params2)
        });
      };
      ZodPromise = class extends ZodType {
        unwrap() {
          return this._def.type;
        }
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.promise,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
          return OK(promisified.then((data) => {
            return this._def.type.parseAsync(data, {
              path: ctx.path,
              errorMap: ctx.common.contextualErrorMap
            });
          }));
        }
      };
      ZodPromise.create = (schema, params2) => {
        return new ZodPromise({
          type: schema,
          typeName: ZodFirstPartyTypeKind.ZodPromise,
          ...processCreateParams(params2)
        });
      };
      ZodEffects = class extends ZodType {
        innerType() {
          return this._def.schema;
        }
        sourceType() {
          return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
        }
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          const effect = this._def.effect || null;
          const checkCtx = {
            addIssue: (arg) => {
              addIssueToContext(ctx, arg);
              if (arg.fatal) {
                status2.abort();
              } else {
                status2.dirty();
              }
            },
            get path() {
              return ctx.path;
            }
          };
          checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
          if (effect.type === "preprocess") {
            const processed = effect.transform(ctx.data, checkCtx);
            if (ctx.common.async) {
              return Promise.resolve(processed).then(async (processed2) => {
                if (status2.value === "aborted")
                  return INVALID;
                const result = await this._def.schema._parseAsync({
                  data: processed2,
                  path: ctx.path,
                  parent: ctx
                });
                if (result.status === "aborted")
                  return INVALID;
                if (result.status === "dirty")
                  return DIRTY(result.value);
                if (status2.value === "dirty")
                  return DIRTY(result.value);
                return result;
              });
            } else {
              if (status2.value === "aborted")
                return INVALID;
              const result = this._def.schema._parseSync({
                data: processed,
                path: ctx.path,
                parent: ctx
              });
              if (result.status === "aborted")
                return INVALID;
              if (result.status === "dirty")
                return DIRTY(result.value);
              if (status2.value === "dirty")
                return DIRTY(result.value);
              return result;
            }
          }
          if (effect.type === "refinement") {
            const executeRefinement = (acc) => {
              const result = effect.refinement(acc, checkCtx);
              if (ctx.common.async) {
                return Promise.resolve(result);
              }
              if (result instanceof Promise) {
                throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
              }
              return acc;
            };
            if (ctx.common.async === false) {
              const inner = this._def.schema._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (inner.status === "aborted")
                return INVALID;
              if (inner.status === "dirty")
                status2.dirty();
              executeRefinement(inner.value);
              return { status: status2.value, value: inner.value };
            } else {
              return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
                if (inner.status === "aborted")
                  return INVALID;
                if (inner.status === "dirty")
                  status2.dirty();
                return executeRefinement(inner.value).then(() => {
                  return { status: status2.value, value: inner.value };
                });
              });
            }
          }
          if (effect.type === "transform") {
            if (ctx.common.async === false) {
              const base = this._def.schema._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (!isValid(base))
                return INVALID;
              const result = effect.transform(base.value, checkCtx);
              if (result instanceof Promise) {
                throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
              }
              return { status: status2.value, value: result };
            } else {
              return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
                if (!isValid(base))
                  return INVALID;
                return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
                  status: status2.value,
                  value: result
                }));
              });
            }
          }
          util.assertNever(effect);
        }
      };
      ZodEffects.create = (schema, effect, params2) => {
        return new ZodEffects({
          schema,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect,
          ...processCreateParams(params2)
        });
      };
      ZodEffects.createWithPreprocess = (preprocess, schema, params2) => {
        return new ZodEffects({
          schema,
          effect: { type: "preprocess", transform: preprocess },
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          ...processCreateParams(params2)
        });
      };
      ZodOptional = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType === ZodParsedType.undefined) {
            return OK(void 0);
          }
          return this._def.innerType._parse(input2);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodOptional.create = (type, params2) => {
        return new ZodOptional({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodOptional,
          ...processCreateParams(params2)
        });
      };
      ZodNullable = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType === ZodParsedType.null) {
            return OK(null);
          }
          return this._def.innerType._parse(input2);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodNullable.create = (type, params2) => {
        return new ZodNullable({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodNullable,
          ...processCreateParams(params2)
        });
      };
      ZodDefault = class extends ZodType {
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          let data = ctx.data;
          if (ctx.parsedType === ZodParsedType.undefined) {
            data = this._def.defaultValue();
          }
          return this._def.innerType._parse({
            data,
            path: ctx.path,
            parent: ctx
          });
        }
        removeDefault() {
          return this._def.innerType;
        }
      };
      ZodDefault.create = (type, params2) => {
        return new ZodDefault({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodDefault,
          defaultValue: typeof params2.default === "function" ? params2.default : () => params2.default,
          ...processCreateParams(params2)
        });
      };
      ZodCatch = class extends ZodType {
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          const newCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            }
          };
          const result = this._def.innerType._parse({
            data: newCtx.data,
            path: newCtx.path,
            parent: {
              ...newCtx
            }
          });
          if (isAsync(result)) {
            return result.then((result2) => {
              return {
                status: "valid",
                value: result2.status === "valid" ? result2.value : this._def.catchValue({
                  get error() {
                    return new ZodError(newCtx.common.issues);
                  },
                  input: newCtx.data
                })
              };
            });
          } else {
            return {
              status: "valid",
              value: result.status === "valid" ? result.value : this._def.catchValue({
                get error() {
                  return new ZodError(newCtx.common.issues);
                },
                input: newCtx.data
              })
            };
          }
        }
        removeCatch() {
          return this._def.innerType;
        }
      };
      ZodCatch.create = (type, params2) => {
        return new ZodCatch({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodCatch,
          catchValue: typeof params2.catch === "function" ? params2.catch : () => params2.catch,
          ...processCreateParams(params2)
        });
      };
      ZodNaN = class extends ZodType {
        _parse(input2) {
          const parsedType = this._getType(input2);
          if (parsedType !== ZodParsedType.nan) {
            const ctx = this._getOrReturnCtx(input2);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.nan,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return { status: "valid", value: input2.data };
        }
      };
      ZodNaN.create = (params2) => {
        return new ZodNaN({
          typeName: ZodFirstPartyTypeKind.ZodNaN,
          ...processCreateParams(params2)
        });
      };
      BRAND = /* @__PURE__ */ Symbol("zod_brand");
      ZodBranded = class extends ZodType {
        _parse(input2) {
          const { ctx } = this._processInputParams(input2);
          const data = ctx.data;
          return this._def.type._parse({
            data,
            path: ctx.path,
            parent: ctx
          });
        }
        unwrap() {
          return this._def.type;
        }
      };
      ZodPipeline = class _ZodPipeline extends ZodType {
        _parse(input2) {
          const { status: status2, ctx } = this._processInputParams(input2);
          if (ctx.common.async) {
            const handleAsync = async () => {
              const inResult = await this._def.in._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (inResult.status === "aborted")
                return INVALID;
              if (inResult.status === "dirty") {
                status2.dirty();
                return DIRTY(inResult.value);
              } else {
                return this._def.out._parseAsync({
                  data: inResult.value,
                  path: ctx.path,
                  parent: ctx
                });
              }
            };
            return handleAsync();
          } else {
            const inResult = this._def.in._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inResult.status === "aborted")
              return INVALID;
            if (inResult.status === "dirty") {
              status2.dirty();
              return {
                status: "dirty",
                value: inResult.value
              };
            } else {
              return this._def.out._parseSync({
                data: inResult.value,
                path: ctx.path,
                parent: ctx
              });
            }
          }
        }
        static create(a, b) {
          return new _ZodPipeline({
            in: a,
            out: b,
            typeName: ZodFirstPartyTypeKind.ZodPipeline
          });
        }
      };
      ZodReadonly = class extends ZodType {
        _parse(input2) {
          const result = this._def.innerType._parse(input2);
          const freeze = (data) => {
            if (isValid(data)) {
              data.value = Object.freeze(data.value);
            }
            return data;
          };
          return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodReadonly.create = (type, params2) => {
        return new ZodReadonly({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodReadonly,
          ...processCreateParams(params2)
        });
      };
      late = {
        object: ZodObject.lazycreate
      };
      (function(ZodFirstPartyTypeKind2) {
        ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
        ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
        ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
        ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
        ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
        ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
        ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
        ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
        ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
        ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
        ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
        ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
        ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
        ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
        ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
        ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
        ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
        ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
        ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
        ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
        ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
        ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
        ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
        ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
        ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
        ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
        ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
        ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
        ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
        ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
        ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
        ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
        ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
        ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
        ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
        ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
      })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
      instanceOfType = (cls, params2 = {
        message: `Input not instance of ${cls.name}`
      }) => custom((data) => data instanceof cls, params2);
      stringType = ZodString.create;
      numberType = ZodNumber.create;
      nanType = ZodNaN.create;
      bigIntType = ZodBigInt.create;
      booleanType = ZodBoolean.create;
      dateType = ZodDate.create;
      symbolType = ZodSymbol.create;
      undefinedType = ZodUndefined.create;
      nullType = ZodNull.create;
      anyType = ZodAny.create;
      unknownType = ZodUnknown.create;
      neverType = ZodNever.create;
      voidType = ZodVoid.create;
      arrayType = ZodArray.create;
      objectType = ZodObject.create;
      strictObjectType = ZodObject.strictCreate;
      unionType = ZodUnion.create;
      discriminatedUnionType = ZodDiscriminatedUnion.create;
      intersectionType = ZodIntersection.create;
      tupleType = ZodTuple.create;
      recordType = ZodRecord.create;
      mapType = ZodMap.create;
      setType = ZodSet.create;
      functionType = ZodFunction.create;
      lazyType = ZodLazy.create;
      literalType = ZodLiteral.create;
      enumType = ZodEnum.create;
      nativeEnumType = ZodNativeEnum.create;
      promiseType = ZodPromise.create;
      effectsType = ZodEffects.create;
      optionalType = ZodOptional.create;
      nullableType = ZodNullable.create;
      preprocessType = ZodEffects.createWithPreprocess;
      pipelineType = ZodPipeline.create;
      ostring = () => stringType().optional();
      onumber = () => numberType().optional();
      oboolean = () => booleanType().optional();
      coerce = {
        string: ((arg) => ZodString.create({ ...arg, coerce: true })),
        number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
        boolean: ((arg) => ZodBoolean.create({
          ...arg,
          coerce: true
        })),
        bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
        date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
      };
      NEVER = INVALID;
    }
  });

  // node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });
  var init_external = __esm({
    "node_modules/zod/v3/external.js"() {
      init_errors();
      init_parseUtil();
      init_typeAliases();
      init_util();
      init_types();
      init_ZodError();
    }
  });

  // node_modules/zod/index.js
  var init_zod = __esm({
    "node_modules/zod/index.js"() {
      init_external();
      init_external();
    }
  });

  // src/documents/errors.ts
  var messages, DocumentLoadError;
  var init_errors2 = __esm({
    "src/documents/errors.ts"() {
      "use strict";
      messages = {
        "pdf-browser": "PDF \u6587\u5B57\u7FFB\u8B6F\u9700\u8981 Chrome 124 \u6216\u66F4\u65B0\u7248\u672C\uFF1B\u5176\u4ED6\u6587\u4EF6\u683C\u5F0F\u4ECD\u53EF\u4F7F\u7528\u3002",
        "pdf-size": "PDF \u4E0D\u80FD\u8D85\u904E 50 MB\u3002\u8ACB\u5148\u5206\u5272\u6587\u4EF6\u5F8C\u518D\u958B\u555F\u3002",
        "pdf-pages": "PDF \u8D85\u904E 500 \u9801\u3002\u8ACB\u5148\u5206\u5272\u6587\u4EF6\u5F8C\u518D\u958B\u555F\u3002",
        "pdf-empty": "PDF \u6C92\u6709\u53EF\u64F7\u53D6\u6587\u5B57\uFF0C\u53EF\u80FD\u662F\u6383\u63CF\u4EF6\u3002\u6B64\u7248\u672C\u5C1A\u672A\u63D0\u4F9B OCR\u3002",
        "pdf-password": "\u6B64 PDF \u9700\u8981\u5BC6\u78BC\u3002\u76EE\u524D\u4E0D\u652F\u63F4\u5BC6\u78BC\u6587\u4EF6\uFF0C\u8ACB\u5148\u5728\u672C\u6A5F\u89E3\u9664\u5BC6\u78BC\u5F8C\u518D\u958B\u555F\u3002",
        "pdf-invalid": "PDF \u8B80\u53D6\u5931\u6557\u3002\u8ACB\u78BA\u8A8D\u6A94\u6848\u672A\u640D\u58DE\uFF1B\u6B64\u7248\u672C\u5C1A\u672A\u9A57\u8B49\u6240\u6709 PDF \u5B57\u578B\u8207\u7DE8\u78BC\u3002"
      };
      DocumentLoadError = class extends Error {
        constructor(code) {
          super(messages[code]);
          this.code = code;
          this.name = "DocumentLoadError";
        }
        code;
      };
    }
  });

  // src/documents/zip.ts
  function crc32(bytes) {
    let crc = 4294967295;
    for (const byte of bytes) {
      crc ^= byte;
      for (let bit = 0; bit < 8; bit++)
        crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
    }
    return (crc ^ 4294967295) >>> 0;
  }
  function range(bytes, start2, size) {
    if (!Number.isSafeInteger(start2) || !Number.isSafeInteger(size) || start2 < 0 || size < 0 || start2 + size > bytes.length)
      throw new Error("ZIP \u6A94\u6848\u5DF2\u622A\u65B7\u6216\u7D50\u69CB\u4E0D\u5408\u6CD5\u3002");
  }
  function validateName(name) {
    if (!name || name.includes("\\") || name.startsWith("/") || name.includes("\0") || name.split("/").includes(".."))
      throw new Error("EPUB \u542B\u4E0D\u5B89\u5168\u7684\u6A94\u6848\u8DEF\u5F91\u3002");
  }
  async function inflate(bytes, expected) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    const reader = stream.getReader();
    const result = new Uint8Array(expected);
    let offset = 0;
    try {
      for (; ; ) {
        const item = await reader.read();
        if (item.done)
          break;
        if (offset + item.value.length > expected)
          throw new Error("EPUB \u89E3\u58D3\u7E2E\u5927\u5C0F\u8D85\u51FA\u5BA3\u544A\u7BC4\u570D\u3002");
        result.set(item.value, offset);
        offset += item.value.length;
      }
    } catch (error) {
      await reader.cancel();
      throw error;
    }
    if (offset !== expected)
      throw new Error("EPUB \u89E3\u58D3\u7E2E\u8CC7\u6599\u9577\u5EA6\u4E0D\u7B26\u3002");
    return result;
  }
  async function readZip(buffer) {
    const bytes = new Uint8Array(buffer);
    if (bytes.length > MAX_TOTAL)
      throw new Error("EPUB \u58D3\u7E2E\u6A94\u4E0D\u80FD\u8D85\u904E 100 MB\u3002");
    const view = new DataView(buffer);
    let end = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (view.getUint32(i, true) === 101010256 && i + 22 + view.getUint16(i + 20, true) === bytes.length) {
        end = i;
        break;
      }
    }
    if (end < 0)
      throw new Error("\u627E\u4E0D\u5230\u6709\u6548\u7684 ZIP \u76EE\u9304\u3002");
    if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true))
      throw new Error("\u4E0D\u652F\u63F4\u591A\u78C1\u789F ZIP\u3002");
    const count = view.getUint16(end + 10, true);
    if (count > 5e3 || count !== view.getUint16(end + 8, true))
      throw new Error("ZIP \u9805\u76EE\u904E\u591A\u6216\u4E0D\u652F\u63F4 ZIP64\u3002");
    const directorySize = view.getUint32(end + 12, true);
    let cursor = view.getUint32(end + 16, true);
    range(bytes, cursor, directorySize);
    const directoryEnd = cursor + directorySize;
    if (directoryEnd > end)
      throw new Error("ZIP \u76EE\u9304\u91CD\u758A\u3002");
    const entries = [];
    const names = /* @__PURE__ */ new Set();
    let total = 0;
    for (let i = 0; i < count; i++) {
      range(bytes, cursor, 46);
      if (view.getUint32(cursor, true) !== 33639248)
        throw new Error("ZIP \u76EE\u9304\u6A19\u8A18\u932F\u8AA4\u3002");
      const flags = view.getUint16(cursor + 8, true);
      const method = view.getUint16(cursor + 10, true);
      const crc = view.getUint32(cursor + 16, true);
      const compressed = view.getUint32(cursor + 20, true);
      const size = view.getUint32(cursor + 24, true);
      const nameSize = view.getUint16(cursor + 28, true);
      const extraSize = view.getUint16(cursor + 30, true);
      const commentSize = view.getUint16(cursor + 32, true);
      const local = view.getUint32(cursor + 42, true);
      range(bytes, cursor + 46, nameSize + extraSize + commentSize);
      const name = decoder.decode(bytes.slice(cursor + 46, cursor + 46 + nameSize));
      validateName(name);
      if (names.has(name))
        throw new Error("ZIP \u542B\u91CD\u8907\u6A94\u6848\u540D\u7A31\u3002");
      names.add(name);
      if (flags & 1)
        throw new Error("\u4E0D\u652F\u63F4\u52A0\u5BC6 EPUB\u3002");
      if (method !== 0 && method !== 8)
        throw new Error("\u4E0D\u652F\u63F4\u6B64 ZIP \u58D3\u7E2E\u683C\u5F0F\u3002");
      total += size;
      if (size > MAX_FILE || total > MAX_TOTAL)
        throw new Error("EPUB \u89E3\u58D3\u7E2E\u8CC7\u6599\u904E\u5927\u3002");
      range(bytes, local, 30);
      if (view.getUint32(local, true) !== 67324752)
        throw new Error("ZIP \u6A94\u982D\u932F\u8AA4\u3002");
      const offset = local + 30 + view.getUint16(local + 26, true) + view.getUint16(local + 28, true);
      range(bytes, offset, compressed);
      if (offset + compressed > view.getUint32(end + 16, true))
        throw new Error("ZIP \u6A94\u6848\u8CC7\u6599\u8207\u76EE\u9304\u91CD\u758A\u3002");
      const packed = bytes.slice(offset, offset + compressed);
      const data = method === 0 ? packed : await inflate(packed, size);
      if (data.length !== size || crc32(data) !== crc)
        throw new Error("EPUB \u6A94\u6848\u6821\u9A57\u5931\u6557\u3002");
      entries.push({ name, data });
      cursor += 46 + nameSize + extraSize + commentSize;
    }
    if (cursor !== directoryEnd)
      throw new Error("ZIP \u76EE\u9304\u9577\u5EA6\u4E0D\u7B26\u3002");
    return entries;
  }
  function writeZip(entries) {
    if (entries.length > 5e3)
      throw new Error("EPUB \u9805\u76EE\u904E\u591A\u3002");
    const ordered = [...entries].sort((a, b) => a.name === "mimetype" ? -1 : b.name === "mimetype" ? 1 : 0);
    const parts = [];
    const central = [];
    let offset = 0;
    const names = /* @__PURE__ */ new Set();
    for (const entry of ordered) {
      validateName(entry.name);
      if (names.has(entry.name))
        throw new Error("\u91CD\u8907 ZIP \u6A94\u540D\u3002");
      names.add(entry.name);
      const name = encoder.encode(entry.name);
      if (name.length > 65535 || entry.data.length > MAX_FILE)
        throw new Error("EPUB \u9805\u76EE\u904E\u5927\u3002");
      const local = new Uint8Array(30 + name.length);
      const l = new DataView(local.buffer);
      l.setUint32(0, 67324752, true);
      l.setUint16(4, 20, true);
      l.setUint16(6, 2048, true);
      l.setUint16(12, 33, true);
      l.setUint32(14, crc32(entry.data), true);
      l.setUint32(18, entry.data.length, true);
      l.setUint32(22, entry.data.length, true);
      l.setUint16(26, name.length, true);
      local.set(name, 30);
      const header = new Uint8Array(46 + name.length);
      const c = new DataView(header.buffer);
      c.setUint32(0, 33639248, true);
      c.setUint16(4, 20, true);
      c.setUint16(6, 20, true);
      c.setUint16(8, 2048, true);
      c.setUint16(14, 33, true);
      c.setUint32(16, crc32(entry.data), true);
      c.setUint32(20, entry.data.length, true);
      c.setUint32(24, entry.data.length, true);
      c.setUint16(28, name.length, true);
      c.setUint32(42, offset, true);
      header.set(name, 46);
      central.push(header);
      parts.push(local, entry.data);
      offset += local.length + entry.data.length;
      if (offset > MAX_TOTAL)
        throw new Error("\u8F38\u51FA EPUB \u8D85\u904E 100 MB\u3002");
    }
    const end = new Uint8Array(22);
    const e = new DataView(end.buffer);
    e.setUint32(0, 101010256, true);
    e.setUint16(8, entries.length, true);
    e.setUint16(10, entries.length, true);
    e.setUint32(12, central.reduce((sum, part) => sum + part.length, 0), true);
    e.setUint32(16, offset, true);
    const all = [...parts, ...central, end];
    const result = new Uint8Array(all.reduce((sum, part) => sum + part.length, 0));
    let at = 0;
    for (const part of all) {
      result.set(part, at);
      at += part.length;
    }
    return result;
  }
  var encoder, decoder, MAX_FILE, MAX_TOTAL;
  var init_zip = __esm({
    "src/documents/zip.ts"() {
      "use strict";
      encoder = new TextEncoder();
      decoder = new TextDecoder("utf-8", { fatal: true });
      MAX_FILE = 32 * 1024 * 1024;
      MAX_TOTAL = 100 * 1024 * 1024;
    }
  });

  // src/documents/pdf.ts
  var pdf_exports = {};
  __export(pdf_exports, {
    pdfDocument: () => pdfDocument,
    pdfTextDocument: () => pdfTextDocument,
    pdfTextLines: () => pdfTextLines
  });
  function callMethod(target, name, args = []) {
    if (typeof target !== "object" && typeof target !== "function" || target === null)
      throw new Error("PDF \u6A21\u7D44\u7269\u4EF6\u4E0D\u76F8\u5BB9\u3002");
    const method = Reflect.get(target, name);
    if (typeof method !== "function")
      throw new Error("PDF \u6A21\u7D44\u65B9\u6CD5\u4E0D\u76F8\u5BB9\u3002");
    return Reflect.apply(method, target, args);
  }
  function pdfTextLines(value) {
    const { items } = contentSchema.parse(value);
    let text = "";
    let previousY;
    for (const item of items) {
      if (!("str" in item))
        continue;
      const y = item.transform?.[5];
      if (previousY !== void 0 && y !== void 0 && Math.abs(y - previousY) > 2 && !text.endsWith("\n"))
        text += "\n";
      if (text && !text.endsWith("\n") && !/\s$/.test(text) && !/^\s/.test(item.str))
        text += " ";
      text += item.str;
      if (item.hasEOL)
        text += "\n";
      previousY = y;
    }
    return text.trim();
  }
  function pdfTextDocument(pages, title2) {
    const groups = pages.map((page2) => ({ number: page2.number, segments: splitLongText(page2.text).filter((source) => source.trim()).map((source) => ({ source, translation: null })) }));
    const segments = groups.flatMap((group) => group.segments);
    if (!segments.length)
      throw new DocumentLoadError("pdf-empty");
    return { title: title2, kind: "pdf", extension: "html", segments, export: (mode2) => {
      const rows = groups.map((group) => `<section><h2>\u7B2C ${group.number} \u9801</h2>${group.segments.map((segment) => {
        const original = `<div class="original">${escapeMarkup(segment.source)}</div>`;
        const translated = `<div class="translated">${escapeMarkup(segment.translation ?? segment.source)}</div>`;
        return `<article class="${mode2}">${mode2 === "bilingual" ? original : ""}${translated}</article>`;
      }).join("")}</section>`).join("");
      return new Blob([`<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>${escapeMarkup(title2)} \xB7 \u7FFB\u8B6F</title><style>body{max-width:1100px;margin:32px auto;padding:0 24px;font-family:system-ui,sans-serif;line-height:1.8;color:#302d35}h1{font-size:24px}h2{font-size:16px;color:#89657f}article{display:grid;gap:24px;margin-bottom:24px}article.bilingual{grid-template-columns:1fr 1fr}article div{white-space:pre-wrap;overflow-wrap:anywhere}.translated{color:#754261}section{border-top:1px solid #ddd;margin-top:28px}small{color:#777}@media print{body{margin:0;max-width:none}section{break-before:page}section:first-of-type{break-before:auto}article{break-inside:avoid}}@media(max-width:650px){article.bilingual{grid-template-columns:1fr}}</style></head><body><h1>${escapeMarkup(title2)}</h1><small>\u6587\u5B57\u64F7\u53D6\u8207\u7FFB\u8B6F\uFF0C\u4E0D\u4FDD\u7559 PDF \u539F\u59CB\u5716\u50CF\u3001\u6B04\u4F4D\u53CA\u6392\u7248\u3002\u53EF\u4F7F\u7528\u700F\u89BD\u5668\u5217\u5370\u53E6\u5B58 PDF\u3002</small>${rows}</body></html>`], { type: "text/html;charset=utf-8" });
    } };
  }
  async function extractPdfDocument(buffer, title2) {
    if (buffer.byteLength > 50 * 1024 * 1024)
      throw new DocumentLoadError("pdf-size");
    if (!("withResolvers" in Promise))
      throw new DocumentLoadError("pdf-browser");
    const base = chrome.runtime.getURL("vendor/pdfjs/");
    const imported = await import(base + "pdf.mjs");
    moduleSchema.parse(imported);
    if (typeof imported !== "object" || imported === null || !("GlobalWorkerOptions" in imported))
      throw new Error("PDF \u6A21\u7D44\u8F09\u5165\u5931\u6557\u3002");
    const workerOptions = imported.GlobalWorkerOptions;
    if (typeof workerOptions !== "function" || !("workerSrc" in workerOptions) || typeof workerOptions.workerSrc !== "string")
      throw new Error("PDF Worker \u6A21\u7D44\u4E0D\u76F8\u5BB9\u3002");
    workerOptions.workerSrc = base + "pdf.worker.mjs";
    const task = callMethod(imported, "getDocument", [{ data: new Uint8Array(buffer), isEvalSupported: false, useWasm: false, disableFontFace: true, enableXfa: false, disableAutoFetch: true, cMapUrl: base + "cmaps/", cMapPacked: true, standardFontDataUrl: base + "standard_fonts/", verbosity: 0 }]);
    try {
      const pdf = await taskSchema.parse(task).promise;
      const { numPages } = pdfMetadataSchema.parse(pdf);
      if (numPages > 500)
        throw new DocumentLoadError("pdf-pages");
      const pages = [];
      for (let number = 1; number <= numPages; number++) {
        const page2 = await callMethod(pdf, "getPage", [number]);
        try {
          pages.push({ number, text: pdfTextLines(await callMethod(page2, "getTextContent")) });
        } finally {
          callMethod(page2, "cleanup");
        }
      }
      return pdfTextDocument(pages, title2);
    } finally {
      await callMethod(task, "destroy");
    }
  }
  async function pdfDocument(buffer, title2) {
    try {
      return await extractPdfDocument(buffer, title2);
    } catch (error) {
      if (error instanceof DocumentLoadError)
        throw error;
      if (typeof error === "object" && error !== null && "name" in error && error.name === "PasswordException")
        throw new DocumentLoadError("pdf-password");
      throw new DocumentLoadError("pdf-invalid");
    }
  }
  var textItemSchema, contentSchema, pdfMetadataSchema, taskSchema, moduleSchema;
  var init_pdf = __esm({
    "src/documents/pdf.ts"() {
      "use strict";
      init_zod();
      init_errors2();
      init_formats();
      textItemSchema = external_exports.object({ str: external_exports.string(), hasEOL: external_exports.boolean().optional(), transform: external_exports.array(external_exports.number()).optional() });
      contentSchema = external_exports.object({ items: external_exports.array(external_exports.union([textItemSchema, external_exports.object({ type: external_exports.string() })])) });
      pdfMetadataSchema = external_exports.object({ numPages: external_exports.number().int().min(1) });
      taskSchema = external_exports.object({ promise: external_exports.promise(external_exports.unknown()) });
      moduleSchema = external_exports.object({ version: external_exports.literal("5.4.322") });
    }
  });

  // src/documents/formats.ts
  function escapeMarkup(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function splitLongText(text, max = 6e3) {
    if (!Number.isInteger(max) || max < 2)
      throw new Error("\u6BB5\u843D\u9577\u5EA6\u4E0D\u5408\u6CD5\u3002");
    const result = [];
    while (text.length > max) {
      let index = text.lastIndexOf(" ", max);
      if (index < max / 2)
        index = max;
      const code = text.charCodeAt(index - 1);
      if (code >= 55296 && code <= 56319)
        index--;
      result.push(text.slice(0, index));
      text = text.slice(index);
    }
    if (text)
      result.push(text);
    return result;
  }
  function rendered(segment, mode2, separator = "\n") {
    if (segment.translation === null)
      return segment.source;
    return mode2 === "bilingual" ? segment.source + separator + segment.translation : segment.translation;
  }
  function textDocument(text, title2, markdown = false) {
    const segments = [];
    const sections = [];
    let fenced = false;
    let fence = "";
    for (const block of text.split(/(\r?\n\s*\r?\n)/)) {
      if (!block.trim()) {
        sections.push({ kind: "raw", text: block });
        continue;
      }
      if (markdown) {
        const lines = block.split("\n");
        const hasFence = lines.some((line) => /^\s*(```|~~~)/.test(line));
        if (fenced || hasFence) {
          for (const line of lines) {
            const marker = /^\s*(```|~~~)/.exec(line)?.[1];
            if (marker && (!fenced || marker === fence)) {
              fenced = !fenced;
              fence = marker;
            }
          }
          sections.push({ kind: "raw", text: block });
          continue;
        }
      }
      for (const source of splitLongText(block)) {
        const segment = { source, translation: null };
        segments.push(segment);
        sections.push({ kind: "segment", segment });
      }
    }
    return { title: title2, kind: markdown ? "markdown" : "text", segments, extension: markdown ? "md" : "txt", export: (mode2) => new Blob([sections.map((section) => section.kind === "raw" ? section.text : rendered(section.segment, mode2, "\n\n")).join("")], { type: "text/plain;charset=utf-8" }) };
  }
  function subtitleDocument(text, title2, format) {
    const separator = text.includes("\r\n") ? "\r\n" : "\n";
    const blocks = text.replace(/^\uFEFF/, "").split(/\r?\n\r?\n/);
    const segments = [];
    const items = blocks.map((block) => {
      const lines = block.split(/\r?\n/);
      const timestamp = lines.findIndex((line) => /^(?:\d{2}:)?\d{2}:\d{2}[.,]\d{3}\s+-->\s+(?:\d{2}:)?\d{2}:\d{2}[.,]\d{3}/.test(line));
      if (timestamp < 0 || timestamp === lines.length - 1 || /^(NOTE|STYLE|REGION)(\s|$)/.test(lines[0] ?? ""))
        return { prefix: block, segment: null };
      const source = lines.slice(timestamp + 1).join("\n");
      if (source.length > 12e3)
        throw new Error("\u5B57\u5E55\u55AE\u4E00\u6BB5\u843D\u8D85\u904E 12000 \u5B57\u5143\u3002");
      const segment = { source, translation: null };
      segments.push(segment);
      return { prefix: lines.slice(0, timestamp + 1).join(separator), segment };
    });
    if (!segments.length)
      throw new Error("\u627E\u4E0D\u5230\u6709\u6548\u7684\u5B57\u5E55\u6642\u9593\u8EF8\u3002");
    return { title: title2, kind: "subtitle", segments, extension: format, export: (mode2) => new Blob([items.map((item) => {
      if (!item.segment)
        return item.prefix;
      const safe = item.segment.translation === null ? null : item.segment.translation.replace(/\r?\n\s*\r?\n/g, "\n").replace(/-->/g, "\u2192").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return item.prefix + separator + rendered({ source: item.segment.source, translation: safe }, mode2).replace(/\n/g, separator);
    }).join(separator + separator)], { type: format === "vtt" ? "text/vtt;charset=utf-8" : "text/plain;charset=utf-8" }) };
  }
  function safeDocumentUrl(value) {
    const normalized = value.replace(/[\u0000-\u0020\u007f]/g, "").trim();
    if (!normalized || normalized.startsWith("/") || normalized.includes("\\") || /^[a-z][a-z\d+.-]*:/i.test(normalized))
      return null;
    let decoded;
    try {
      decoded = decodeURIComponent(normalized).replace(/[\u0000-\u0020\u007f]/g, "");
    } catch {
      return null;
    }
    if (decoded.startsWith("/") || decoded.includes("\\") || /^[a-z][a-z\d+.-]*:/i.test(decoded))
      return null;
    return normalized;
  }
  function segmentBatches(segments, limit, maxCharacters = 6e4) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 40 || maxCharacters < 12e3)
      throw new Error("\u7FFB\u8B6F\u6279\u6B21\u9650\u5236\u4E0D\u5408\u6CD5\u3002");
    const result = [];
    let batch = [];
    let characters = 0;
    for (const segment of segments) {
      if (segment.source.length > maxCharacters)
        throw new Error("\u6BB5\u843D\u8D85\u904E\u7FFB\u8B6F\u5B57\u6578\u4E0A\u9650\u3002");
      if (batch.length && (batch.length >= limit || characters + segment.source.length > maxCharacters)) {
        result.push(batch);
        batch = [];
        characters = 0;
      }
      batch.push(segment);
      characters += segment.source.length;
    }
    if (batch.length)
      result.push(batch);
    return result;
  }
  function parseMarkup(text, xml) {
    const doc = new DOMParser().parseFromString(text, xml ? "application/xhtml+xml" : "text/html");
    if (xml && doc.querySelector("parsererror"))
      throw new Error("EPUB \u7AE0\u7BC0\u4E0D\u662F\u6709\u6548 XHTML\u3002");
    doc.doctype?.remove();
    const instructions = doc.createTreeWalker(doc, NodeFilter.SHOW_PROCESSING_INSTRUCTION);
    const removable = [];
    while (instructions.nextNode())
      removable.push(instructions.currentNode);
    for (const node of removable)
      node.parentNode?.removeChild(node);
    const forbidden = /* @__PURE__ */ new Set(["script", "iframe", "object", "embed", "base", "form", "input", "button", "textarea", "select", "meta", "link", "style", "svg", "animate", "animatemotion", "animatetransform", "set", "foreignobject", "audio", "video", "source", "track", "template"]);
    const safeAttributes = /* @__PURE__ */ new Set(["id", "class", "lang", "dir", "title", "alt", "width", "height", "colspan", "rowspan", "scope", "role"]);
    for (const el of [...doc.querySelectorAll("*")]) {
      const tag = el.localName.toLowerCase();
      if (forbidden.has(tag)) {
        el.remove();
        continue;
      }
      for (const attr of [...el.attributes]) {
        const name = attr.name.toLowerCase();
        if (name === "xmlns" && attr.value === "http://www.w3.org/1999/xhtml")
          continue;
        if (safeAttributes.has(name) || /^aria-[a-z-]+$/.test(name))
          continue;
        if (name === "href" && tag === "a" || name === "src" && tag === "img") {
          const safe = safeDocumentUrl(attr.value);
          if (safe !== null) {
            el.setAttribute(attr.name, safe);
            continue;
          }
        }
        el.removeAttribute(attr.name);
      }
    }
    return doc;
  }
  function markupPart(text, xml) {
    const doc = parseMarkup(text, xml);
    const records = [];
    const candidates = [...doc.querySelectorAll("p,h1,h2,h3,h4,h5,h6,li,td,th,figcaption,blockquote,dt,dd")];
    for (const element2 of candidates) {
      if (element2.closest("pre,code,svg,math,nav"))
        continue;
      if (element2.querySelector("p,h1,h2,h3,h4,h5,h6,li,td,th,figcaption,blockquote,dt,dd"))
        continue;
      const source = element2.textContent?.trim() ?? "";
      if (!source || !new RegExp("\\p{L}", "u").test(source))
        continue;
      records.push({ element: element2, source, segments: splitLongText(source).map((source2) => ({ source: source2, translation: null })) });
    }
    if (!records.length) {
      for (const element2 of doc.querySelectorAll("body > div,body")) {
        if (element2.children.length)
          continue;
        const source = element2.textContent?.trim() ?? "";
        if (source)
          records.push({ element: element2, source, segments: splitLongText(source).map((source2) => ({ source: source2, translation: null })) });
      }
    }
    return { doc, records };
  }
  function serializePart(part, mode2) {
    const copy = part.doc.cloneNode(true);
    if (!(copy instanceof Document))
      throw new Error("\u7121\u6CD5\u5EFA\u7ACB\u6587\u4EF6\u526F\u672C\u3002");
    const originals = [...part.doc.querySelectorAll("*")];
    const copies = [...copy.querySelectorAll("*")];
    for (const record of part.records) {
      const element2 = copies[originals.indexOf(record.element)];
      if (!element2 || record.segments.every((segment) => segment.translation === null))
        continue;
      const translation = record.segments.map((segment) => segment.translation ?? segment.source).join("");
      if (mode2 === "translated")
        element2.textContent = translation;
      else {
        const paragraph = copy.createElementNS(element2.namespaceURI, "span");
        paragraph.setAttribute("class", "local-translation");
        paragraph.setAttribute("style", "display:block;margin-top:0.6em;color:#75516a;");
        paragraph.textContent = translation;
        element2.appendChild(paragraph);
      }
    }
    return new XMLSerializer().serializeToString(copy);
  }
  function htmlDocument(text, title2) {
    const part = markupPart(text, false);
    return { title: title2, kind: "html", segments: part.records.flatMap((record) => record.segments), extension: "html", export: (mode2) => new Blob([serializePart(part, mode2)], { type: "text/html;charset=utf-8" }) };
  }
  async function epubDocument(buffer, title2) {
    const entries = await readZip(buffer);
    const mime = entries.find((entry) => entry.name === "mimetype");
    if (!mime || decoder2.decode(mime.data).trim() !== "application/epub+zip")
      throw new Error("\u9019\u4E0D\u662F\u6709\u6548\u7684 EPUB \u6A94\u6848\u3002");
    if (entries.some((entry) => entry.name === "META-INF/encryption.xml"))
      throw new Error("\u76EE\u524D\u4E0D\u652F\u63F4\u542B\u52A0\u5BC6\u8CC7\u6E90\u7684 EPUB\uFF0C\u5305\u62EC\u6DF7\u6DC6\u5B57\u578B\u3002");
    const container = entries.find((entry) => entry.name === "META-INF/container.xml");
    if (!container)
      throw new Error("EPUB \u7F3A\u5C11 container.xml\u3002");
    const containerDoc = new DOMParser().parseFromString(decoder2.decode(container.data), "application/xml");
    const packagePath = containerDoc.getElementsByTagNameNS("*", "rootfile")[0]?.getAttribute("full-path");
    const packageEntry = entries.find((entry) => entry.name === packagePath);
    if (!packageEntry)
      throw new Error("EPUB \u7F3A\u5C11\u5957\u4EF6\u76EE\u9304\u3002");
    const packageDoc = new DOMParser().parseFromString(decoder2.decode(packageEntry.data), "application/xml");
    if (packageDoc.querySelector("parsererror"))
      throw new Error("EPUB \u5957\u4EF6\u76EE\u9304\u683C\u5F0F\u932F\u8AA4\u3002");
    const base = new URL(packageEntry.name, "https://epub.invalid/");
    const manifest = /* @__PURE__ */ new Map();
    for (const item of packageDoc.getElementsByTagNameNS("*", "item")) {
      const id = item.getAttribute("id");
      const href = item.getAttribute("href");
      if (!id || !href)
        continue;
      const url = new URL(href, base);
      if (url.origin !== base.origin)
        continue;
      const path = decodeURIComponent(url.pathname.slice(1));
      if (/\.(xhtml|html|htm)$/i.test(path))
        manifest.set(id, path);
    }
    const orderedPaths = [];
    for (const item of packageDoc.getElementsByTagNameNS("*", "itemref")) {
      const path = manifest.get(item.getAttribute("idref") ?? "");
      if (path && !orderedPaths.includes(path))
        orderedPaths.push(path);
    }
    for (const path of manifest.values())
      if (!orderedPaths.includes(path))
        orderedPaths.push(path);
    const parts = /* @__PURE__ */ new Map();
    for (const path of orderedPaths) {
      const entry = entries.find((entry2) => entry2.name === path);
      if (!entry)
        throw new Error("EPUB \u5957\u4EF6\u5BA3\u544A\u7684\u7AE0\u7BC0\u907A\u5931\u3002");
      parts.set(entry.name, markupPart(decoder2.decode(entry.data), /\.xhtml$/i.test(entry.name)));
    }
    if (!parts.size)
      throw new Error("EPUB \u6C92\u6709\u53EF\u8B80\u53D6\u7684 HTML \u7AE0\u7BC0\u3002");
    return { title: title2, kind: "epub", segments: [...parts.values()].flatMap((part) => part.records.flatMap((record) => record.segments)), extension: "epub", export: (mode2) => {
      const output = entries.map((entry) => {
        const part = parts.get(entry.name);
        return part ? { name: entry.name, data: encoder2.encode(serializePart(part, mode2)) } : entry;
      });
      return new Blob([writeZip(output)], { type: "application/epub+zip" });
    } };
  }
  async function loadDocument(file) {
    if (file.size > 100 * 1024 * 1024)
      throw new Error("\u6A94\u6848\u4E0D\u80FD\u8D85\u904E 100 MB\u3002");
    const ext = file.name.toLowerCase().split(".").pop();
    if (ext === "epub")
      return epubDocument(await file.arrayBuffer(), file.name);
    if (ext === "pdf") {
      const { pdfDocument: pdfDocument2 } = await Promise.resolve().then(() => (init_pdf(), pdf_exports));
      return pdfDocument2(await file.arrayBuffer(), file.name);
    }
    if (file.size > 10 * 1024 * 1024)
      throw new Error("\u6587\u5B57\u6587\u4EF6\u4E0D\u80FD\u8D85\u904E 10 MB\u3002");
    const text = await file.text();
    if (ext === "srt" || ext === "vtt")
      return subtitleDocument(text, file.name, ext);
    if (ext === "html" || ext === "htm")
      return htmlDocument(text, file.name);
    if (ext === "md" || ext === "markdown")
      return textDocument(text, file.name, true);
    if (ext === "txt")
      return textDocument(text, file.name);
    throw new Error("\u652F\u63F4\u6587\u5B57\u578B PDF\u3001TXT\u3001Markdown\u3001HTML\u3001SRT\u3001VTT \u8207\u672A\u52A0\u5BC6 EPUB\u3002");
  }
  var encoder2, decoder2;
  var init_formats = __esm({
    "src/documents/formats.ts"() {
      "use strict";
      init_zip();
      encoder2 = new TextEncoder();
      decoder2 = new TextDecoder();
    }
  });

  // src/documents/remote-pdf.ts
  function remotePdfURL(raw) {
    const url = new URL(raw);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) throw new Error("PDF \u7DB2\u5740\u9808\u70BA HTTP \u6216 HTTPS\uFF0C\u4E14\u4E0D\u53EF\u542B\u5E33\u5BC6\u3002");
    url.hash = "";
    return url;
  }
  async function fetchPdfFile(raw) {
    const url = remotePdfURL(raw);
    const response = await fetch(url, { credentials: "omit", redirect: "error", signal: AbortSignal.timeout(3e4) });
    if (!response.ok) throw new Error("\u7121\u6CD5\u4E0B\u8F09 PDF\u3002\u9700\u8981\u767B\u5165\u6216\u91CD\u65B0\u5C0E\u5411\u7684\u6587\u4EF6\uFF0C\u8ACB\u5148\u4E0B\u8F09\u5230\u672C\u6A5F\u518D\u9078\u53D6\u3002");
    const limit = 50 * 1024 * 1024;
    if (Number(response.headers.get("content-length")) > limit) throw new Error("PDF \u4E0D\u80FD\u8D85\u904E 50 MB\u3002");
    const reader = response.body?.getReader();
    if (!reader) throw new Error("PDF \u6C92\u6709\u5167\u5BB9\u3002");
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const item = await reader.read();
        if (item.done) break;
        size += item.value.length;
        if (size > limit) throw new Error("PDF \u4E0D\u80FD\u8D85\u904E 50 MB\u3002");
        chunks.push(new Uint8Array(item.value));
      }
    } finally {
      await reader.cancel();
    }
    const blob = new Blob(chunks);
    const header = new TextDecoder().decode(await blob.slice(0, 1024).arrayBuffer());
    if (!header.includes("%PDF-")) throw new Error("\u7DB2\u5740\u6C92\u6709\u56DE\u50B3 PDF\uFF0C\u53EF\u80FD\u662F\u767B\u5165\u9801\u3002\u8ACB\u4E0B\u8F09 PDF \u5F8C\u518D\u9078\u53D6\u6A94\u6848\u3002");
    let name = "document.pdf";
    try {
      name = decodeURIComponent(url.pathname.split("/").pop() ?? "") || name;
    } catch {
    }
    if (!/\.pdf$/i.test(name)) name = "document.pdf";
    return new File([blob], name, { type: "application/pdf" });
  }

  // src/core/messages.ts
  init_zod();

  // src/core/settings.ts
  init_zod();
  var modeSchema = external_exports.enum(["original", "bilingual", "translated"]);
  var providerIdSchema = external_exports.enum(["openai", "gemini", "deepl"]);
  var providerSchema = external_exports.object({ apiKey: external_exports.string().max(4096).default(""), endpoint: external_exports.string().url(), model: external_exports.string().max(200), prompt: external_exports.string().max(8e3) });
  var settingsSchema = external_exports.object({ source: external_exports.string().min(2).max(30), target: external_exports.string().min(2).max(30), mode: modeSchema, provider: providerIdSchema, autoTranslate: external_exports.boolean(), hover: external_exports.boolean(), selection: external_exports.boolean(), subtitles: external_exports.boolean(), style: external_exports.object({ theme: external_exports.enum(["plain", "highlight", "gray", "underline", "dotted", "dashed", "wavy", "blockquote", "mask"]).default("highlight"), color: external_exports.string().regex(/^#[\da-f]{6}$/i), background: external_exports.string().regex(/^#[\da-f]{6}$/i), fontSize: external_exports.number().min(50).max(200), border: external_exports.boolean() }), allowSites: external_exports.array(external_exports.string().max(253)).max(1e3), blockSites: external_exports.array(external_exports.string().max(253)).max(1e3), providers: external_exports.object({ openai: providerSchema, gemini: providerSchema, deepl: providerSchema }), requestsPerMinute: external_exports.number().int().min(1).max(120), batchSize: external_exports.number().int().min(1).max(20) });
  var publicSettingsSchema = settingsSchema.omit({ providers: true });

  // src/core/messages.ts
  var requestSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("settings.get") }),
    external_exports.object({ kind: external_exports.literal("settings.public") }),
    external_exports.object({ kind: external_exports.literal("settings.save"), settings: settingsSchema }),
    external_exports.object({ kind: external_exports.literal("captions.info") }),
    external_exports.object({ kind: external_exports.literal("translate"), priority: external_exports.enum(["normal", "subtitle"]).optional(), texts: external_exports.array(external_exports.string().max(12e3)).min(1).max(40), source: external_exports.string().min(2).max(30).optional(), target: external_exports.string().min(2).max(30).optional() }),
    external_exports.object({ kind: external_exports.literal("page.mode"), mode: modeSchema }),
    external_exports.object({ kind: external_exports.literal("page.selection"), text: external_exports.string().max(12e3).optional() }),
    external_exports.object({ kind: external_exports.literal("stats.get") }),
    external_exports.object({ kind: external_exports.literal("cache.clear") }),
    external_exports.object({ kind: external_exports.literal("stats.clear") }),
    external_exports.object({ kind: external_exports.literal("data.reset") })
  ]);
  var replySchema = external_exports.discriminatedUnion("ok", [external_exports.object({ ok: external_exports.literal(true), data: external_exports.unknown() }), external_exports.object({ ok: external_exports.literal(false), error: external_exports.string() })]);
  async function rpc(request) {
    return unwrapReply(await chrome.runtime.sendMessage(request));
  }
  async function translate(texts) {
    return external_exports.array(external_exports.string()).parse(await rpc({ kind: "translate", texts }));
  }
  var contentMessageSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("page.mode"), mode: modeSchema }),
    external_exports.object({ kind: external_exports.literal("page.selection"), text: external_exports.string().max(12e3).optional() }),
    external_exports.object({ kind: external_exports.literal("page.toggle") }),
    external_exports.object({ kind: external_exports.literal("settings.updated"), settings: publicSettingsSchema, restore: external_exports.boolean().default(false) })
  ]);
  function unwrapReply(value) {
    const parsed = replySchema.parse(value);
    if (!parsed.ok) throw new Error(parsed.error);
    return parsed.data;
  }

  // src/documents/documents.ts
  init_errors2();
  init_formats();
  function element(id, ctor) {
    const value = document.getElementById(id);
    if (!(value instanceof ctor))
      throw new Error("\u6587\u4EF6\u4ECB\u9762\u521D\u59CB\u5316\u5931\u6557\u3002");
    return value;
  }
  var input = element("file", HTMLInputElement);
  var start = element("start", HTMLButtonElement);
  var cancel = element("cancel", HTMLButtonElement);
  var save = element("save", HTMLButtonElement);
  var mode = element("output-mode", HTMLSelectElement);
  var status = element("status", HTMLElement);
  var progress = element("progress", HTMLProgressElement);
  var preview = element("preview", HTMLElement);
  var title = element("document-name", HTMLElement);
  var next = element("next", HTMLButtonElement);
  var previous = element("previous", HTMLButtonElement);
  var pageLabel = element("page-label", HTMLElement);
  var current = null;
  var generation = 0;
  var running = false;
  var page = 0;
  var batchSize = 8;
  var PAGE_SIZE = 30;
  function updateButtons() {
    start.disabled = !current || running || current.segments.every((segment) => segment.translation !== null);
    cancel.disabled = !running;
    input.disabled = running;
    save.disabled = !current || running || !current.segments.some((segment) => segment.translation !== null);
  }
  function render() {
    preview.replaceChildren();
    if (!current) {
      updateButtons();
      pageLabel.textContent = "";
      return;
    }
    const segments = current.segments.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    const fragment = document.createDocumentFragment();
    for (const segment of segments) {
      const row = document.createElement("article");
      row.className = "pair";
      const source = document.createElement("div");
      source.className = "source";
      source.textContent = segment.source;
      const translation = document.createElement("div");
      translation.className = "translation";
      translation.textContent = segment.translation ?? "\u5C1A\u672A\u7FFB\u8B6F";
      if (segment.translation === null)
        translation.classList.add("pending");
      row.append(source, translation);
      fragment.append(row);
    }
    preview.append(fragment);
    const pages = Math.max(1, Math.ceil(current.segments.length / PAGE_SIZE));
    pageLabel.textContent = `\u7B2C ${page + 1} / ${pages} \u9801`;
    previous.disabled = page === 0;
    next.disabled = page + 1 >= pages;
    const completed = current.segments.filter((segment) => segment.translation !== null).length;
    progress.max = Math.max(current.segments.length, 1);
    progress.value = completed;
    element("count", HTMLElement).textContent = `${completed} / ${current.segments.length} \u6BB5`;
    updateButtons();
  }
  function openFile(file, token = ++generation) {
    current = null;
    running = false;
    page = 0;
    updateButtons();
    status.textContent = "\u6B63\u5728\u672C\u6A5F\u8B80\u53D6\u6587\u4EF6\u2026";
    void loadDocument(file).then((doc) => {
      if (token !== generation)
        return;
      current = doc;
      title.textContent = doc.title;
      status.textContent = doc.segments.length ? "\u6587\u4EF6\u5DF2\u5C31\u7DD2\u3002\u6309\u300C\u958B\u59CB\u7FFB\u8B6F\u300D\u624D\u6703\u5C07\u6587\u5B57\u50B3\u7D66\u4F60\u8A2D\u5B9A\u7684\u7FFB\u8B6F\u670D\u52D9\u3002" : "\u6587\u4EF6\u5167\u6C92\u6709\u53EF\u7FFB\u8B6F\u7684\u6587\u5B57\u3002";
      render();
    }).catch((error) => {
      if (token !== generation)
        return;
      status.textContent = error instanceof DocumentLoadError ? error.message : "\u7121\u6CD5\u8B80\u53D6\u6587\u4EF6\u3002\u8ACB\u78BA\u8A8D\u683C\u5F0F\u6B63\u78BA\u3001\u6A94\u6848\u672A\u640D\u58DE\uFF0C\u4E14 EPUB \u672A\u52A0\u5BC6\u3002";
      preview.replaceChildren();
      title.textContent = "\u958B\u555F\u4E00\u4EFD\u6587\u4EF6";
      updateButtons();
    });
  }
  input.addEventListener("change", () => {
    const file = input.files?.[0];
    if (file) openFile(file);
  });
  start.addEventListener("click", () => {
    if (!current || running)
      return;
    const doc = current;
    const token = ++generation;
    running = true;
    updateButtons();
    status.textContent = "\u7FFB\u8B6F\u4E2D\uFF0C\u53EF\u96A8\u6642\u505C\u6B62\u5F8C\u7E7C\u7E8C\u3002";
    void (async () => {
      const pending = doc.segments.filter((segment) => segment.translation === null);
      for (const batch of segmentBatches(pending, batchSize)) {
        if (token !== generation)
          return;
        const results = await translate(batch.map((segment) => segment.source));
        if (token !== generation)
          return;
        if (results.length !== batch.length)
          throw new Error("\u7FFB\u8B6F\u7D50\u679C\u6578\u91CF\u4E0D\u7B26\u3002");
        for (const [index, segment] of batch.entries())
          segment.translation = results[index] ?? null;
        render();
      }
      status.textContent = "\u7FFB\u8B6F\u5B8C\u6210\u3002\u53EF\u9078\u64C7\u96D9\u8A9E\u6216\u50C5\u8B6F\u6587\u4E0B\u8F09\u3002";
    })().catch(() => {
      if (token === generation)
        status.textContent = "\u7FFB\u8B6F\u5931\u6557\uFF0C\u5DF2\u5B8C\u6210\u6BB5\u843D\u5DF2\u4FDD\u7559\u3002\u8ACB\u6AA2\u67E5\u670D\u52D9\u8A2D\u5B9A\u3001\u6B0A\u9650\u8207\u984D\u5EA6\uFF0C\u518D\u6309\u300C\u958B\u59CB\u7FFB\u8B6F\u300D\u7E7C\u7E8C\u3002";
    }).finally(() => {
      if (token === generation) {
        running = false;
        render();
      }
    });
  });
  cancel.addEventListener("click", () => {
    generation++;
    running = false;
    status.textContent = "\u5DF2\u505C\u6B62\u5F8C\u7E8C\u6279\u6B21\uFF0C\u5B8C\u6210\u6BB5\u843D\u5DF2\u4FDD\u7559\u3002\u6B63\u5728\u8655\u7406\u7684 API \u8ACB\u6C42\u4ECD\u53EF\u80FD\u8A08\u8CBB\u3002";
    render();
  });
  save.addEventListener("click", () => {
    if (!current || running)
      return;
    const outputMode = mode.value === "translated" ? "translated" : "bilingual";
    try {
      const blob = current.export(outputMode);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = current.title.replace(/\.[^.]+$/, "") + "." + outputMode + "." + current.extension;
      anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 3e4);
      status.textContent = current.segments.some((segment) => segment.translation === null) ? "\u5DF2\u4E0B\u8F09\u90E8\u5206\u7FFB\u8B6F\uFF0C\u672A\u5B8C\u6210\u6BB5\u843D\u4FDD\u7559\u539F\u6587\u3002" : "\u5DF2\u4E0B\u8F09\u7FFB\u8B6F\u6587\u4EF6\u3002";
    } catch {
      status.textContent = "\u7121\u6CD5\u532F\u51FA\u3002\u6587\u4EF6\u53EF\u80FD\u8D85\u51FA 100 MB \u8F38\u51FA\u4E0A\u9650\u3002";
    }
  });
  next.addEventListener("click", () => {
    if (current && (page + 1) * PAGE_SIZE < current.segments.length) {
      page++;
      render();
    }
  });
  previous.addEventListener("click", () => {
    page = Math.max(0, page - 1);
    render();
  });
  element("settings", HTMLButtonElement).addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
  void rpc({ kind: "settings.public" }).then((value) => {
    const settings = settingsSchema.omit({ providers: true }).parse(value);
    batchSize = settings.batchSize;
    element("service", HTMLElement).textContent = `${settings.provider} \xB7 ${settings.source === "auto" ? "\u81EA\u52D5\u5075\u6E2C" : settings.source} \u2192 ${settings.target}`;
  }).catch(() => {
    status.textContent = "\u7121\u6CD5\u8B80\u53D6\u8A2D\u5B9A\u3002\u8ACB\u91CD\u65B0\u8F09\u5165\u64F4\u5145\u5957\u4EF6\u5F8C\u518D\u8A66\u3002";
  });
  updateButtons();
  var pdfUrl = element("pdf-url", HTMLInputElement);
  var loadPdf = element("load-pdf", HTMLButtonElement);
  var params = new URLSearchParams(location.hash.slice(1));
  if (params.has("pdf")) {
    try {
      pdfUrl.value = remotePdfURL(params.get("pdf") ?? "").href;
    } catch {
      status.textContent = "PDF \u7DB2\u5740\u7121\u6548\uFF0C\u8ACB\u9078\u64C7\u672C\u6A5F\u6A94\u6848\u3002";
    }
  }
  if (location.hash === "#local-pdf") element("pdf-help", HTMLElement).textContent = "\u8ACB\u7528\u4E0B\u65B9\u6A94\u6848\u9078\u64C7\u5668\u91CD\u65B0\u9078\u64C7\u672C\u6A5F PDF\u3002\u700F\u89BD\u5668\u5167\u5EFA PDF \u95B1\u8B80\u5668\u7684\u6587\u5B57\u7121\u6CD5\u76F4\u63A5\u7FFB\u8B6F\u3002";
  if (location.hash) history.replaceState(null, "", location.pathname);
  loadPdf.addEventListener("click", () => {
    if (running) return;
    let url;
    try {
      url = remotePdfURL(pdfUrl.value);
    } catch {
      status.textContent = "\u8ACB\u8F38\u5165\u6709\u6548\u7684 HTTP\uFF0FHTTPS PDF \u7DB2\u5740\u3002";
      return;
    }
    const token = ++generation;
    current = null;
    render();
    loadPdf.disabled = true;
    status.textContent = "\u6B63\u5728\u53D6\u5F97 PDF \u8B80\u53D6\u6B0A\u9650\u2026";
    void chrome.permissions.request({ origins: [url.origin + "/*"] }).then(async (granted) => {
      if (!granted) throw new Error("\u672A\u6388\u6B0A PDF \u7DB2\u7AD9\u3002\u4E5F\u53EF\u4EE5\u4E0B\u8F09 PDF \u5F8C\u9078\u64C7\u672C\u6A5F\u6A94\u6848\u3002");
      if (token !== generation) return;
      status.textContent = "\u6B63\u5728\u4E0B\u8F09 PDF\u2026";
      const file = await fetchPdfFile(url.href);
      if (token === generation) openFile(file, token);
    }).catch((error) => {
      if (token === generation) status.textContent = error instanceof Error ? error.message : "PDF \u8B80\u53D6\u5931\u6557\u3002\u8ACB\u4E0B\u8F09\u5F8C\u9078\u64C7\u672C\u6A5F\u6A94\u6848\u3002";
    }).finally(() => {
      loadPdf.disabled = false;
    });
  });
})();
//# sourceMappingURL=documents.js.map
