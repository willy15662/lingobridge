"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/zod/v3/helpers/util.js
  var util, objectUtil, ZodParsedType, getParsedType;
  var init_util = __esm({
    "node_modules/zod/v3/helpers/util.js"() {
      (function(util2) {
        util2.assertEqual = (_) => {
        };
        function assertIs(_arg) {
        }
        util2.assertIs = assertIs;
        function assertNever(_x) {
          throw new Error();
        }
        util2.assertNever = assertNever;
        util2.arrayToEnum = (items) => {
          const obj = {};
          for (const item of items) {
            obj[item] = item;
          }
          return obj;
        };
        util2.getValidEnumValues = (obj) => {
          const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
          const filtered = {};
          for (const k of validKeys) {
            filtered[k] = obj[k];
          }
          return util2.objectValues(filtered);
        };
        util2.objectValues = (obj) => {
          return util2.objectKeys(obj).map(function(e) {
            return obj[e];
          });
        };
        util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
          const keys = [];
          for (const key in object) {
            if (Object.prototype.hasOwnProperty.call(object, key)) {
              keys.push(key);
            }
          }
          return keys;
        };
        util2.find = (arr, checker) => {
          for (const item of arr) {
            if (checker(item))
              return item;
          }
          return void 0;
        };
        util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
        function joinValues(array, separator = " | ") {
          return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
        }
        util2.joinValues = joinValues;
        util2.jsonStringifyReplacer = (_, value) => {
          if (typeof value === "bigint") {
            return value.toString();
          }
          return value;
        };
      })(util || (util = {}));
      (function(objectUtil2) {
        objectUtil2.mergeShapes = (first, second) => {
          return {
            ...first,
            ...second
            // second overwrites first
          };
        };
      })(objectUtil || (objectUtil = {}));
      ZodParsedType = util.arrayToEnum([
        "string",
        "nan",
        "number",
        "integer",
        "float",
        "boolean",
        "date",
        "bigint",
        "symbol",
        "function",
        "undefined",
        "null",
        "array",
        "object",
        "unknown",
        "promise",
        "void",
        "never",
        "map",
        "set"
      ]);
      getParsedType = (data) => {
        const t = typeof data;
        switch (t) {
          case "undefined":
            return ZodParsedType.undefined;
          case "string":
            return ZodParsedType.string;
          case "number":
            return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
          case "boolean":
            return ZodParsedType.boolean;
          case "function":
            return ZodParsedType.function;
          case "bigint":
            return ZodParsedType.bigint;
          case "symbol":
            return ZodParsedType.symbol;
          case "object":
            if (Array.isArray(data)) {
              return ZodParsedType.array;
            }
            if (data === null) {
              return ZodParsedType.null;
            }
            if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
              return ZodParsedType.promise;
            }
            if (typeof Map !== "undefined" && data instanceof Map) {
              return ZodParsedType.map;
            }
            if (typeof Set !== "undefined" && data instanceof Set) {
              return ZodParsedType.set;
            }
            if (typeof Date !== "undefined" && data instanceof Date) {
              return ZodParsedType.date;
            }
            return ZodParsedType.object;
          default:
            return ZodParsedType.unknown;
        }
      };
    }
  });

  // node_modules/zod/v3/ZodError.js
  var ZodIssueCode, quotelessJson, ZodError;
  var init_ZodError = __esm({
    "node_modules/zod/v3/ZodError.js"() {
      init_util();
      ZodIssueCode = util.arrayToEnum([
        "invalid_type",
        "invalid_literal",
        "custom",
        "invalid_union",
        "invalid_union_discriminator",
        "invalid_enum_value",
        "unrecognized_keys",
        "invalid_arguments",
        "invalid_return_type",
        "invalid_date",
        "invalid_string",
        "too_small",
        "too_big",
        "invalid_intersection_types",
        "not_multiple_of",
        "not_finite"
      ]);
      quotelessJson = (obj) => {
        const json = JSON.stringify(obj, null, 2);
        return json.replace(/"([^"]+)":/g, "$1:");
      };
      ZodError = class _ZodError extends Error {
        get errors() {
          return this.issues;
        }
        constructor(issues) {
          super();
          this.issues = [];
          this.addIssue = (sub) => {
            this.issues = [...this.issues, sub];
          };
          this.addIssues = (subs = []) => {
            this.issues = [...this.issues, ...subs];
          };
          const actualProto = new.target.prototype;
          if (Object.setPrototypeOf) {
            Object.setPrototypeOf(this, actualProto);
          } else {
            this.__proto__ = actualProto;
          }
          this.name = "ZodError";
          this.issues = issues;
        }
        format(_mapper) {
          const mapper = _mapper || function(issue) {
            return issue.message;
          };
          const fieldErrors = { _errors: [] };
          const processError = (error) => {
            for (const issue of error.issues) {
              if (issue.code === "invalid_union") {
                issue.unionErrors.map(processError);
              } else if (issue.code === "invalid_return_type") {
                processError(issue.returnTypeError);
              } else if (issue.code === "invalid_arguments") {
                processError(issue.argumentsError);
              } else if (issue.path.length === 0) {
                fieldErrors._errors.push(mapper(issue));
              } else {
                let curr = fieldErrors;
                let i = 0;
                while (i < issue.path.length) {
                  const el = issue.path[i];
                  const terminal = i === issue.path.length - 1;
                  if (!terminal) {
                    curr[el] = curr[el] || { _errors: [] };
                  } else {
                    curr[el] = curr[el] || { _errors: [] };
                    curr[el]._errors.push(mapper(issue));
                  }
                  curr = curr[el];
                  i++;
                }
              }
            }
          };
          processError(this);
          return fieldErrors;
        }
        static assert(value) {
          if (!(value instanceof _ZodError)) {
            throw new Error(`Not a ZodError: ${value}`);
          }
        }
        toString() {
          return this.message;
        }
        get message() {
          return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
        }
        get isEmpty() {
          return this.issues.length === 0;
        }
        flatten(mapper = (issue) => issue.message) {
          const fieldErrors = {};
          const formErrors = [];
          for (const sub of this.issues) {
            if (sub.path.length > 0) {
              const firstEl = sub.path[0];
              fieldErrors[firstEl] = fieldErrors[firstEl] || [];
              fieldErrors[firstEl].push(mapper(sub));
            } else {
              formErrors.push(mapper(sub));
            }
          }
          return { formErrors, fieldErrors };
        }
        get formErrors() {
          return this.flatten();
        }
      };
      ZodError.create = (issues) => {
        const error = new ZodError(issues);
        return error;
      };
    }
  });

  // node_modules/zod/v3/locales/en.js
  var errorMap, en_default;
  var init_en = __esm({
    "node_modules/zod/v3/locales/en.js"() {
      init_ZodError();
      init_util();
      errorMap = (issue, _ctx) => {
        let message;
        switch (issue.code) {
          case ZodIssueCode.invalid_type:
            if (issue.received === ZodParsedType.undefined) {
              message = "Required";
            } else {
              message = `Expected ${issue.expected}, received ${issue.received}`;
            }
            break;
          case ZodIssueCode.invalid_literal:
            message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
            break;
          case ZodIssueCode.unrecognized_keys:
            message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
            break;
          case ZodIssueCode.invalid_union:
            message = `Invalid input`;
            break;
          case ZodIssueCode.invalid_union_discriminator:
            message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
            break;
          case ZodIssueCode.invalid_enum_value:
            message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
            break;
          case ZodIssueCode.invalid_arguments:
            message = `Invalid function arguments`;
            break;
          case ZodIssueCode.invalid_return_type:
            message = `Invalid function return type`;
            break;
          case ZodIssueCode.invalid_date:
            message = `Invalid date`;
            break;
          case ZodIssueCode.invalid_string:
            if (typeof issue.validation === "object") {
              if ("includes" in issue.validation) {
                message = `Invalid input: must include "${issue.validation.includes}"`;
                if (typeof issue.validation.position === "number") {
                  message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
                }
              } else if ("startsWith" in issue.validation) {
                message = `Invalid input: must start with "${issue.validation.startsWith}"`;
              } else if ("endsWith" in issue.validation) {
                message = `Invalid input: must end with "${issue.validation.endsWith}"`;
              } else {
                util.assertNever(issue.validation);
              }
            } else if (issue.validation !== "regex") {
              message = `Invalid ${issue.validation}`;
            } else {
              message = "Invalid";
            }
            break;
          case ZodIssueCode.too_small:
            if (issue.type === "array")
              message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
            else if (issue.type === "string")
              message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
            else if (issue.type === "number")
              message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
            else if (issue.type === "bigint")
              message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
            else if (issue.type === "date")
              message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
            else
              message = "Invalid input";
            break;
          case ZodIssueCode.too_big:
            if (issue.type === "array")
              message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
            else if (issue.type === "string")
              message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
            else if (issue.type === "number")
              message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
            else if (issue.type === "bigint")
              message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
            else if (issue.type === "date")
              message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
            else
              message = "Invalid input";
            break;
          case ZodIssueCode.custom:
            message = `Invalid input`;
            break;
          case ZodIssueCode.invalid_intersection_types:
            message = `Intersection results could not be merged`;
            break;
          case ZodIssueCode.not_multiple_of:
            message = `Number must be a multiple of ${issue.multipleOf}`;
            break;
          case ZodIssueCode.not_finite:
            message = "Number must be finite";
            break;
          default:
            message = _ctx.defaultError;
            util.assertNever(issue);
        }
        return { message };
      };
      en_default = errorMap;
    }
  });

  // node_modules/zod/v3/errors.js
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }
  var overrideErrorMap;
  var init_errors = __esm({
    "node_modules/zod/v3/errors.js"() {
      init_en();
      overrideErrorMap = en_default;
    }
  });

  // node_modules/zod/v3/helpers/parseUtil.js
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        // contextual error map is first priority
        ctx.schemaErrorMap,
        // then schema-bound map if available
        overrideMap,
        // then global override map
        overrideMap === en_default ? void 0 : en_default
        // then global default map
      ].filter((x) => !!x)
    });
    ctx.common.issues.push(issue);
  }
  var makeIssue, EMPTY_PATH, ParseStatus, INVALID, DIRTY, OK, isAborted, isDirty, isValid, isAsync;
  var init_parseUtil = __esm({
    "node_modules/zod/v3/helpers/parseUtil.js"() {
      init_errors();
      init_en();
      makeIssue = (params) => {
        const { data, path, errorMaps, issueData } = params;
        const fullPath = [...path, ...issueData.path || []];
        const fullIssue = {
          ...issueData,
          path: fullPath
        };
        if (issueData.message !== void 0) {
          return {
            ...issueData,
            path: fullPath,
            message: issueData.message
          };
        }
        let errorMessage = "";
        const maps = errorMaps.filter((m) => !!m).slice().reverse();
        for (const map of maps) {
          errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
        }
        return {
          ...issueData,
          path: fullPath,
          message: errorMessage
        };
      };
      EMPTY_PATH = [];
      ParseStatus = class _ParseStatus {
        constructor() {
          this.value = "valid";
        }
        dirty() {
          if (this.value === "valid")
            this.value = "dirty";
        }
        abort() {
          if (this.value !== "aborted")
            this.value = "aborted";
        }
        static mergeArray(status, results) {
          const arrayValue = [];
          for (const s of results) {
            if (s.status === "aborted")
              return INVALID;
            if (s.status === "dirty")
              status.dirty();
            arrayValue.push(s.value);
          }
          return { status: status.value, value: arrayValue };
        }
        static async mergeObjectAsync(status, pairs) {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value
            });
          }
          return _ParseStatus.mergeObjectSync(status, syncPairs);
        }
        static mergeObjectSync(status, pairs) {
          const finalObject = {};
          for (const pair of pairs) {
            const { key, value } = pair;
            if (key.status === "aborted")
              return INVALID;
            if (value.status === "aborted")
              return INVALID;
            if (key.status === "dirty")
              status.dirty();
            if (value.status === "dirty")
              status.dirty();
            if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
              finalObject[key.value] = value.value;
            }
          }
          return { status: status.value, value: finalObject };
        }
      };
      INVALID = Object.freeze({
        status: "aborted"
      });
      DIRTY = (value) => ({ status: "dirty", value });
      OK = (value) => ({ status: "valid", value });
      isAborted = (x) => x.status === "aborted";
      isDirty = (x) => x.status === "dirty";
      isValid = (x) => x.status === "valid";
      isAsync = (x) => typeof Promise !== "undefined" && x instanceof Promise;
    }
  });

  // node_modules/zod/v3/helpers/typeAliases.js
  var init_typeAliases = __esm({
    "node_modules/zod/v3/helpers/typeAliases.js"() {
    }
  });

  // node_modules/zod/v3/helpers/errorUtil.js
  var errorUtil;
  var init_errorUtil = __esm({
    "node_modules/zod/v3/helpers/errorUtil.js"() {
      (function(errorUtil2) {
        errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
        errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
      })(errorUtil || (errorUtil = {}));
    }
  });

  // node_modules/zod/v3/types.js
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      const { message } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message ?? ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: message ?? required_error ?? ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: message ?? invalid_type_error ?? ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  function timeRegexSource(args) {
    let secondsRegexSource = `[0-5]\\d`;
    if (args.precision) {
      secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
    }
    const secondsQuantifier = args.precision ? "+" : "?";
    return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  function isValidJWT(jwt, alg) {
    if (!jwtRegex.test(jwt))
      return false;
    try {
      const [header] = jwt.split(".");
      if (!header)
        return false;
      const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
      const decoded = JSON.parse(atob(base64));
      if (typeof decoded !== "object" || decoded === null)
        return false;
      if ("typ" in decoded && decoded?.typ !== "JWT")
        return false;
      if (!decoded.alg)
        return false;
      if (alg && decoded.alg !== alg)
        return false;
      return true;
    } catch {
      return false;
    }
  }
  function isValidCidr(ip, version) {
    if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
      return true;
    }
    return false;
  }
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
  }
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  function mergeValues(a, b) {
    const aType = getParsedType(a);
    const bType = getParsedType(b);
    if (a === b) {
      return { valid: true, data: a };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b);
      const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a, ...b };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a[key], b[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a.length !== b.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
      return { valid: true, data: a };
    } else {
      return { valid: false };
    }
  }
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  function cleanParams(params, data) {
    const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
    const p2 = typeof p === "string" ? { message: p } : p;
    return p2;
  }
  function custom(check, _params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        const r = check(data);
        if (r instanceof Promise) {
          return r.then((r2) => {
            if (!r2) {
              const params = cleanParams(_params, data);
              const _fatal = params.fatal ?? fatal ?? true;
              ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
            }
          });
        }
        if (!r) {
          const params = cleanParams(_params, data);
          const _fatal = params.fatal ?? fatal ?? true;
          ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
        }
        return;
      });
    return ZodAny.create();
  }
  var ParseInputLazyPath, handleResult, ZodType, cuidRegex, cuid2Regex, ulidRegex, uuidRegex, nanoidRegex, jwtRegex, durationRegex, emailRegex, _emojiRegex, emojiRegex, ipv4Regex, ipv4CidrRegex, ipv6Regex, ipv6CidrRegex, base64Regex, base64urlRegex, dateRegexSource, dateRegex, ZodString, ZodNumber, ZodBigInt, ZodBoolean, ZodDate, ZodSymbol, ZodUndefined, ZodNull, ZodAny, ZodUnknown, ZodNever, ZodVoid, ZodArray, ZodObject, ZodUnion, getDiscriminator, ZodDiscriminatedUnion, ZodIntersection, ZodTuple, ZodRecord, ZodMap, ZodSet, ZodFunction, ZodLazy, ZodLiteral, ZodEnum, ZodNativeEnum, ZodPromise, ZodEffects, ZodOptional, ZodNullable, ZodDefault, ZodCatch, ZodNaN, BRAND, ZodBranded, ZodPipeline, ZodReadonly, late, ZodFirstPartyTypeKind, instanceOfType, stringType, numberType, nanType, bigIntType, booleanType, dateType, symbolType, undefinedType, nullType, anyType, unknownType, neverType, voidType, arrayType, objectType, strictObjectType, unionType, discriminatedUnionType, intersectionType, tupleType, recordType, mapType, setType, functionType, lazyType, literalType, enumType, nativeEnumType, promiseType, effectsType, optionalType, nullableType, preprocessType, pipelineType, ostring, onumber, oboolean, coerce, NEVER;
  var init_types = __esm({
    "node_modules/zod/v3/types.js"() {
      init_ZodError();
      init_errors();
      init_errorUtil();
      init_parseUtil();
      init_util();
      ParseInputLazyPath = class {
        constructor(parent, value, path, key) {
          this._cachedPath = [];
          this.parent = parent;
          this.data = value;
          this._path = path;
          this._key = key;
        }
        get path() {
          if (!this._cachedPath.length) {
            if (Array.isArray(this._key)) {
              this._cachedPath.push(...this._path, ...this._key);
            } else {
              this._cachedPath.push(...this._path, this._key);
            }
          }
          return this._cachedPath;
        }
      };
      handleResult = (ctx, result) => {
        if (isValid(result)) {
          return { success: true, data: result.value };
        } else {
          if (!ctx.common.issues.length) {
            throw new Error("Validation failed but no issues detected.");
          }
          return {
            success: false,
            get error() {
              if (this._error)
                return this._error;
              const error = new ZodError(ctx.common.issues);
              this._error = error;
              return this._error;
            }
          };
        }
      };
      ZodType = class {
        get description() {
          return this._def.description;
        }
        _getType(input) {
          return getParsedType(input.data);
        }
        _getOrReturnCtx(input, ctx) {
          return ctx || {
            common: input.parent.common,
            data: input.data,
            parsedType: getParsedType(input.data),
            schemaErrorMap: this._def.errorMap,
            path: input.path,
            parent: input.parent
          };
        }
        _processInputParams(input) {
          return {
            status: new ParseStatus(),
            ctx: {
              common: input.parent.common,
              data: input.data,
              parsedType: getParsedType(input.data),
              schemaErrorMap: this._def.errorMap,
              path: input.path,
              parent: input.parent
            }
          };
        }
        _parseSync(input) {
          const result = this._parse(input);
          if (isAsync(result)) {
            throw new Error("Synchronous parse encountered promise.");
          }
          return result;
        }
        _parseAsync(input) {
          const result = this._parse(input);
          return Promise.resolve(result);
        }
        parse(data, params) {
          const result = this.safeParse(data, params);
          if (result.success)
            return result.data;
          throw result.error;
        }
        safeParse(data, params) {
          const ctx = {
            common: {
              issues: [],
              async: params?.async ?? false,
              contextualErrorMap: params?.errorMap
            },
            path: params?.path || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          const result = this._parseSync({ data, path: ctx.path, parent: ctx });
          return handleResult(ctx, result);
        }
        "~validate"(data) {
          const ctx = {
            common: {
              issues: [],
              async: !!this["~standard"].async
            },
            path: [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          if (!this["~standard"].async) {
            try {
              const result = this._parseSync({ data, path: [], parent: ctx });
              return isValid(result) ? {
                value: result.value
              } : {
                issues: ctx.common.issues
              };
            } catch (err) {
              if (err?.message?.toLowerCase()?.includes("encountered")) {
                this["~standard"].async = true;
              }
              ctx.common = {
                issues: [],
                async: true
              };
            }
          }
          return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
            value: result.value
          } : {
            issues: ctx.common.issues
          });
        }
        async parseAsync(data, params) {
          const result = await this.safeParseAsync(data, params);
          if (result.success)
            return result.data;
          throw result.error;
        }
        async safeParseAsync(data, params) {
          const ctx = {
            common: {
              issues: [],
              contextualErrorMap: params?.errorMap,
              async: true
            },
            path: params?.path || [],
            schemaErrorMap: this._def.errorMap,
            parent: null,
            data,
            parsedType: getParsedType(data)
          };
          const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
          const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
          return handleResult(ctx, result);
        }
        refine(check, message) {
          const getIssueProperties = (val) => {
            if (typeof message === "string" || typeof message === "undefined") {
              return { message };
            } else if (typeof message === "function") {
              return message(val);
            } else {
              return message;
            }
          };
          return this._refinement((val, ctx) => {
            const result = check(val);
            const setError = () => ctx.addIssue({
              code: ZodIssueCode.custom,
              ...getIssueProperties(val)
            });
            if (typeof Promise !== "undefined" && result instanceof Promise) {
              return result.then((data) => {
                if (!data) {
                  setError();
                  return false;
                } else {
                  return true;
                }
              });
            }
            if (!result) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        refinement(check, refinementData) {
          return this._refinement((val, ctx) => {
            if (!check(val)) {
              ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
              return false;
            } else {
              return true;
            }
          });
        }
        _refinement(refinement) {
          return new ZodEffects({
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "refinement", refinement }
          });
        }
        superRefine(refinement) {
          return this._refinement(refinement);
        }
        constructor(def) {
          this.spa = this.safeParseAsync;
          this._def = def;
          this.parse = this.parse.bind(this);
          this.safeParse = this.safeParse.bind(this);
          this.parseAsync = this.parseAsync.bind(this);
          this.safeParseAsync = this.safeParseAsync.bind(this);
          this.spa = this.spa.bind(this);
          this.refine = this.refine.bind(this);
          this.refinement = this.refinement.bind(this);
          this.superRefine = this.superRefine.bind(this);
          this.optional = this.optional.bind(this);
          this.nullable = this.nullable.bind(this);
          this.nullish = this.nullish.bind(this);
          this.array = this.array.bind(this);
          this.promise = this.promise.bind(this);
          this.or = this.or.bind(this);
          this.and = this.and.bind(this);
          this.transform = this.transform.bind(this);
          this.brand = this.brand.bind(this);
          this.default = this.default.bind(this);
          this.catch = this.catch.bind(this);
          this.describe = this.describe.bind(this);
          this.pipe = this.pipe.bind(this);
          this.readonly = this.readonly.bind(this);
          this.isNullable = this.isNullable.bind(this);
          this.isOptional = this.isOptional.bind(this);
          this["~standard"] = {
            version: 1,
            vendor: "zod",
            validate: (data) => this["~validate"](data)
          };
        }
        optional() {
          return ZodOptional.create(this, this._def);
        }
        nullable() {
          return ZodNullable.create(this, this._def);
        }
        nullish() {
          return this.nullable().optional();
        }
        array() {
          return ZodArray.create(this);
        }
        promise() {
          return ZodPromise.create(this, this._def);
        }
        or(option) {
          return ZodUnion.create([this, option], this._def);
        }
        and(incoming) {
          return ZodIntersection.create(this, incoming, this._def);
        }
        transform(transform) {
          return new ZodEffects({
            ...processCreateParams(this._def),
            schema: this,
            typeName: ZodFirstPartyTypeKind.ZodEffects,
            effect: { type: "transform", transform }
          });
        }
        default(def) {
          const defaultValueFunc = typeof def === "function" ? def : () => def;
          return new ZodDefault({
            ...processCreateParams(this._def),
            innerType: this,
            defaultValue: defaultValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodDefault
          });
        }
        brand() {
          return new ZodBranded({
            typeName: ZodFirstPartyTypeKind.ZodBranded,
            type: this,
            ...processCreateParams(this._def)
          });
        }
        catch(def) {
          const catchValueFunc = typeof def === "function" ? def : () => def;
          return new ZodCatch({
            ...processCreateParams(this._def),
            innerType: this,
            catchValue: catchValueFunc,
            typeName: ZodFirstPartyTypeKind.ZodCatch
          });
        }
        describe(description) {
          const This = this.constructor;
          return new This({
            ...this._def,
            description
          });
        }
        pipe(target) {
          return ZodPipeline.create(this, target);
        }
        readonly() {
          return ZodReadonly.create(this);
        }
        isOptional() {
          return this.safeParse(void 0).success;
        }
        isNullable() {
          return this.safeParse(null).success;
        }
      };
      cuidRegex = /^c[^\s-]{8,}$/i;
      cuid2Regex = /^[0-9a-z]+$/;
      ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
      uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
      nanoidRegex = /^[a-z0-9_-]{21}$/i;
      jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
      durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
      emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
      _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
      ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
      ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
      ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
      ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
      base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
      base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
      dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
      dateRegex = new RegExp(`^${dateRegexSource}$`);
      ZodString = class _ZodString extends ZodType {
        _parse(input) {
          if (this._def.coerce) {
            input.data = String(input.data);
          }
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.string) {
            const ctx2 = this._getOrReturnCtx(input);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.string,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          const status = new ParseStatus();
          let ctx = void 0;
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              if (input.data.length < check.value) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: false,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "max") {
              if (input.data.length > check.value) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "string",
                  inclusive: true,
                  exact: false,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "length") {
              const tooBig = input.data.length > check.value;
              const tooSmall = input.data.length < check.value;
              if (tooBig || tooSmall) {
                ctx = this._getOrReturnCtx(input, ctx);
                if (tooBig) {
                  addIssueToContext(ctx, {
                    code: ZodIssueCode.too_big,
                    maximum: check.value,
                    type: "string",
                    inclusive: true,
                    exact: true,
                    message: check.message
                  });
                } else if (tooSmall) {
                  addIssueToContext(ctx, {
                    code: ZodIssueCode.too_small,
                    minimum: check.value,
                    type: "string",
                    inclusive: true,
                    exact: true,
                    message: check.message
                  });
                }
                status.dirty();
              }
            } else if (check.kind === "email") {
              if (!emailRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "email",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "emoji") {
              if (!emojiRegex) {
                emojiRegex = new RegExp(_emojiRegex, "u");
              }
              if (!emojiRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "emoji",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "uuid") {
              if (!uuidRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "uuid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "nanoid") {
              if (!nanoidRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "nanoid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "cuid") {
              if (!cuidRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "cuid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "cuid2") {
              if (!cuid2Regex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "cuid2",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "ulid") {
              if (!ulidRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "ulid",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "url") {
              try {
                new URL(input.data);
              } catch {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "url",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "regex") {
              check.regex.lastIndex = 0;
              const testResult = check.regex.test(input.data);
              if (!testResult) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "regex",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "trim") {
              input.data = input.data.trim();
            } else if (check.kind === "includes") {
              if (!input.data.includes(check.value, check.position)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { includes: check.value, position: check.position },
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "toLowerCase") {
              input.data = input.data.toLowerCase();
            } else if (check.kind === "toUpperCase") {
              input.data = input.data.toUpperCase();
            } else if (check.kind === "startsWith") {
              if (!input.data.startsWith(check.value)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { startsWith: check.value },
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "endsWith") {
              if (!input.data.endsWith(check.value)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: { endsWith: check.value },
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "datetime") {
              const regex = datetimeRegex(check);
              if (!regex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "datetime",
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "date") {
              const regex = dateRegex;
              if (!regex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "date",
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "time") {
              const regex = timeRegex(check);
              if (!regex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_string,
                  validation: "time",
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "duration") {
              if (!durationRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "duration",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "ip") {
              if (!isValidIP(input.data, check.version)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "ip",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "jwt") {
              if (!isValidJWT(input.data, check.alg)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "jwt",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "cidr") {
              if (!isValidCidr(input.data, check.version)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "cidr",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "base64") {
              if (!base64Regex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "base64",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "base64url") {
              if (!base64urlRegex.test(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  validation: "base64url",
                  code: ZodIssueCode.invalid_string,
                  message: check.message
                });
                status.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status.value, value: input.data };
        }
        _regex(regex, validation, message) {
          return this.refinement((data) => regex.test(data), {
            validation,
            code: ZodIssueCode.invalid_string,
            ...errorUtil.errToObj(message)
          });
        }
        _addCheck(check) {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        email(message) {
          return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
        }
        url(message) {
          return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
        }
        emoji(message) {
          return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
        }
        uuid(message) {
          return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
        }
        nanoid(message) {
          return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
        }
        cuid(message) {
          return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
        }
        cuid2(message) {
          return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
        }
        ulid(message) {
          return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
        }
        base64(message) {
          return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
        }
        base64url(message) {
          return this._addCheck({
            kind: "base64url",
            ...errorUtil.errToObj(message)
          });
        }
        jwt(options) {
          return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
        }
        ip(options) {
          return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
        }
        cidr(options) {
          return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
        }
        datetime(options) {
          if (typeof options === "string") {
            return this._addCheck({
              kind: "datetime",
              precision: null,
              offset: false,
              local: false,
              message: options
            });
          }
          return this._addCheck({
            kind: "datetime",
            precision: typeof options?.precision === "undefined" ? null : options?.precision,
            offset: options?.offset ?? false,
            local: options?.local ?? false,
            ...errorUtil.errToObj(options?.message)
          });
        }
        date(message) {
          return this._addCheck({ kind: "date", message });
        }
        time(options) {
          if (typeof options === "string") {
            return this._addCheck({
              kind: "time",
              precision: null,
              message: options
            });
          }
          return this._addCheck({
            kind: "time",
            precision: typeof options?.precision === "undefined" ? null : options?.precision,
            ...errorUtil.errToObj(options?.message)
          });
        }
        duration(message) {
          return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
        }
        regex(regex, message) {
          return this._addCheck({
            kind: "regex",
            regex,
            ...errorUtil.errToObj(message)
          });
        }
        includes(value, options) {
          return this._addCheck({
            kind: "includes",
            value,
            position: options?.position,
            ...errorUtil.errToObj(options?.message)
          });
        }
        startsWith(value, message) {
          return this._addCheck({
            kind: "startsWith",
            value,
            ...errorUtil.errToObj(message)
          });
        }
        endsWith(value, message) {
          return this._addCheck({
            kind: "endsWith",
            value,
            ...errorUtil.errToObj(message)
          });
        }
        min(minLength, message) {
          return this._addCheck({
            kind: "min",
            value: minLength,
            ...errorUtil.errToObj(message)
          });
        }
        max(maxLength, message) {
          return this._addCheck({
            kind: "max",
            value: maxLength,
            ...errorUtil.errToObj(message)
          });
        }
        length(len, message) {
          return this._addCheck({
            kind: "length",
            value: len,
            ...errorUtil.errToObj(message)
          });
        }
        /**
         * Equivalent to `.min(1)`
         */
        nonempty(message) {
          return this.min(1, errorUtil.errToObj(message));
        }
        trim() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "trim" }]
          });
        }
        toLowerCase() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toLowerCase" }]
          });
        }
        toUpperCase() {
          return new _ZodString({
            ...this._def,
            checks: [...this._def.checks, { kind: "toUpperCase" }]
          });
        }
        get isDatetime() {
          return !!this._def.checks.find((ch) => ch.kind === "datetime");
        }
        get isDate() {
          return !!this._def.checks.find((ch) => ch.kind === "date");
        }
        get isTime() {
          return !!this._def.checks.find((ch) => ch.kind === "time");
        }
        get isDuration() {
          return !!this._def.checks.find((ch) => ch.kind === "duration");
        }
        get isEmail() {
          return !!this._def.checks.find((ch) => ch.kind === "email");
        }
        get isURL() {
          return !!this._def.checks.find((ch) => ch.kind === "url");
        }
        get isEmoji() {
          return !!this._def.checks.find((ch) => ch.kind === "emoji");
        }
        get isUUID() {
          return !!this._def.checks.find((ch) => ch.kind === "uuid");
        }
        get isNANOID() {
          return !!this._def.checks.find((ch) => ch.kind === "nanoid");
        }
        get isCUID() {
          return !!this._def.checks.find((ch) => ch.kind === "cuid");
        }
        get isCUID2() {
          return !!this._def.checks.find((ch) => ch.kind === "cuid2");
        }
        get isULID() {
          return !!this._def.checks.find((ch) => ch.kind === "ulid");
        }
        get isIP() {
          return !!this._def.checks.find((ch) => ch.kind === "ip");
        }
        get isCIDR() {
          return !!this._def.checks.find((ch) => ch.kind === "cidr");
        }
        get isBase64() {
          return !!this._def.checks.find((ch) => ch.kind === "base64");
        }
        get isBase64url() {
          return !!this._def.checks.find((ch) => ch.kind === "base64url");
        }
        get minLength() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxLength() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
      };
      ZodString.create = (params) => {
        return new ZodString({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodString,
          coerce: params?.coerce ?? false,
          ...processCreateParams(params)
        });
      };
      ZodNumber = class _ZodNumber extends ZodType {
        constructor() {
          super(...arguments);
          this.min = this.gte;
          this.max = this.lte;
          this.step = this.multipleOf;
        }
        _parse(input) {
          if (this._def.coerce) {
            input.data = Number(input.data);
          }
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.number) {
            const ctx2 = this._getOrReturnCtx(input);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.number,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          let ctx = void 0;
          const status = new ParseStatus();
          for (const check of this._def.checks) {
            if (check.kind === "int") {
              if (!util.isInteger(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.invalid_type,
                  expected: "integer",
                  received: "float",
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "min") {
              const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
              if (tooSmall) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  minimum: check.value,
                  type: "number",
                  inclusive: check.inclusive,
                  exact: false,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "max") {
              const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
              if (tooBig) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  maximum: check.value,
                  type: "number",
                  inclusive: check.inclusive,
                  exact: false,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "multipleOf") {
              if (floatSafeRemainder(input.data, check.value) !== 0) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_multiple_of,
                  multipleOf: check.value,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "finite") {
              if (!Number.isFinite(input.data)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_finite,
                  message: check.message
                });
                status.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status.value, value: input.data };
        }
        gte(value, message) {
          return this.setLimit("min", value, true, errorUtil.toString(message));
        }
        gt(value, message) {
          return this.setLimit("min", value, false, errorUtil.toString(message));
        }
        lte(value, message) {
          return this.setLimit("max", value, true, errorUtil.toString(message));
        }
        lt(value, message) {
          return this.setLimit("max", value, false, errorUtil.toString(message));
        }
        setLimit(kind, value, inclusive, message) {
          return new _ZodNumber({
            ...this._def,
            checks: [
              ...this._def.checks,
              {
                kind,
                value,
                inclusive,
                message: errorUtil.toString(message)
              }
            ]
          });
        }
        _addCheck(check) {
          return new _ZodNumber({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        int(message) {
          return this._addCheck({
            kind: "int",
            message: errorUtil.toString(message)
          });
        }
        positive(message) {
          return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        negative(message) {
          return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        nonpositive(message) {
          return this._addCheck({
            kind: "max",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        nonnegative(message) {
          return this._addCheck({
            kind: "min",
            value: 0,
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        multipleOf(value, message) {
          return this._addCheck({
            kind: "multipleOf",
            value,
            message: errorUtil.toString(message)
          });
        }
        finite(message) {
          return this._addCheck({
            kind: "finite",
            message: errorUtil.toString(message)
          });
        }
        safe(message) {
          return this._addCheck({
            kind: "min",
            inclusive: true,
            value: Number.MIN_SAFE_INTEGER,
            message: errorUtil.toString(message)
          })._addCheck({
            kind: "max",
            inclusive: true,
            value: Number.MAX_SAFE_INTEGER,
            message: errorUtil.toString(message)
          });
        }
        get minValue() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxValue() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
        get isInt() {
          return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
        }
        get isFinite() {
          let max = null;
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
              return true;
            } else if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            } else if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return Number.isFinite(min) && Number.isFinite(max);
        }
      };
      ZodNumber.create = (params) => {
        return new ZodNumber({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodNumber,
          coerce: params?.coerce || false,
          ...processCreateParams(params)
        });
      };
      ZodBigInt = class _ZodBigInt extends ZodType {
        constructor() {
          super(...arguments);
          this.min = this.gte;
          this.max = this.lte;
        }
        _parse(input) {
          if (this._def.coerce) {
            try {
              input.data = BigInt(input.data);
            } catch {
              return this._getInvalidInput(input);
            }
          }
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.bigint) {
            return this._getInvalidInput(input);
          }
          let ctx = void 0;
          const status = new ParseStatus();
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
              if (tooSmall) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  type: "bigint",
                  minimum: check.value,
                  inclusive: check.inclusive,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "max") {
              const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
              if (tooBig) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  type: "bigint",
                  maximum: check.value,
                  inclusive: check.inclusive,
                  message: check.message
                });
                status.dirty();
              }
            } else if (check.kind === "multipleOf") {
              if (input.data % check.value !== BigInt(0)) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.not_multiple_of,
                  multipleOf: check.value,
                  message: check.message
                });
                status.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return { status: status.value, value: input.data };
        }
        _getInvalidInput(input) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.bigint,
            received: ctx.parsedType
          });
          return INVALID;
        }
        gte(value, message) {
          return this.setLimit("min", value, true, errorUtil.toString(message));
        }
        gt(value, message) {
          return this.setLimit("min", value, false, errorUtil.toString(message));
        }
        lte(value, message) {
          return this.setLimit("max", value, true, errorUtil.toString(message));
        }
        lt(value, message) {
          return this.setLimit("max", value, false, errorUtil.toString(message));
        }
        setLimit(kind, value, inclusive, message) {
          return new _ZodBigInt({
            ...this._def,
            checks: [
              ...this._def.checks,
              {
                kind,
                value,
                inclusive,
                message: errorUtil.toString(message)
              }
            ]
          });
        }
        _addCheck(check) {
          return new _ZodBigInt({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        positive(message) {
          return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        negative(message) {
          return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: false,
            message: errorUtil.toString(message)
          });
        }
        nonpositive(message) {
          return this._addCheck({
            kind: "max",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        nonnegative(message) {
          return this._addCheck({
            kind: "min",
            value: BigInt(0),
            inclusive: true,
            message: errorUtil.toString(message)
          });
        }
        multipleOf(value, message) {
          return this._addCheck({
            kind: "multipleOf",
            value,
            message: errorUtil.toString(message)
          });
        }
        get minValue() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min;
        }
        get maxValue() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max;
        }
      };
      ZodBigInt.create = (params) => {
        return new ZodBigInt({
          checks: [],
          typeName: ZodFirstPartyTypeKind.ZodBigInt,
          coerce: params?.coerce ?? false,
          ...processCreateParams(params)
        });
      };
      ZodBoolean = class extends ZodType {
        _parse(input) {
          if (this._def.coerce) {
            input.data = Boolean(input.data);
          }
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.boolean) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.boolean,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input.data);
        }
      };
      ZodBoolean.create = (params) => {
        return new ZodBoolean({
          typeName: ZodFirstPartyTypeKind.ZodBoolean,
          coerce: params?.coerce || false,
          ...processCreateParams(params)
        });
      };
      ZodDate = class _ZodDate extends ZodType {
        _parse(input) {
          if (this._def.coerce) {
            input.data = new Date(input.data);
          }
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.date) {
            const ctx2 = this._getOrReturnCtx(input);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.date,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          if (Number.isNaN(input.data.getTime())) {
            const ctx2 = this._getOrReturnCtx(input);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_date
            });
            return INVALID;
          }
          const status = new ParseStatus();
          let ctx = void 0;
          for (const check of this._def.checks) {
            if (check.kind === "min") {
              if (input.data.getTime() < check.value) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_small,
                  message: check.message,
                  inclusive: true,
                  exact: false,
                  minimum: check.value,
                  type: "date"
                });
                status.dirty();
              }
            } else if (check.kind === "max") {
              if (input.data.getTime() > check.value) {
                ctx = this._getOrReturnCtx(input, ctx);
                addIssueToContext(ctx, {
                  code: ZodIssueCode.too_big,
                  message: check.message,
                  inclusive: true,
                  exact: false,
                  maximum: check.value,
                  type: "date"
                });
                status.dirty();
              }
            } else {
              util.assertNever(check);
            }
          }
          return {
            status: status.value,
            value: new Date(input.data.getTime())
          };
        }
        _addCheck(check) {
          return new _ZodDate({
            ...this._def,
            checks: [...this._def.checks, check]
          });
        }
        min(minDate, message) {
          return this._addCheck({
            kind: "min",
            value: minDate.getTime(),
            message: errorUtil.toString(message)
          });
        }
        max(maxDate, message) {
          return this._addCheck({
            kind: "max",
            value: maxDate.getTime(),
            message: errorUtil.toString(message)
          });
        }
        get minDate() {
          let min = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "min") {
              if (min === null || ch.value > min)
                min = ch.value;
            }
          }
          return min != null ? new Date(min) : null;
        }
        get maxDate() {
          let max = null;
          for (const ch of this._def.checks) {
            if (ch.kind === "max") {
              if (max === null || ch.value < max)
                max = ch.value;
            }
          }
          return max != null ? new Date(max) : null;
        }
      };
      ZodDate.create = (params) => {
        return new ZodDate({
          checks: [],
          coerce: params?.coerce || false,
          typeName: ZodFirstPartyTypeKind.ZodDate,
          ...processCreateParams(params)
        });
      };
      ZodSymbol = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.symbol) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.symbol,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input.data);
        }
      };
      ZodSymbol.create = (params) => {
        return new ZodSymbol({
          typeName: ZodFirstPartyTypeKind.ZodSymbol,
          ...processCreateParams(params)
        });
      };
      ZodUndefined = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.undefined,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input.data);
        }
      };
      ZodUndefined.create = (params) => {
        return new ZodUndefined({
          typeName: ZodFirstPartyTypeKind.ZodUndefined,
          ...processCreateParams(params)
        });
      };
      ZodNull = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.null) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.null,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input.data);
        }
      };
      ZodNull.create = (params) => {
        return new ZodNull({
          typeName: ZodFirstPartyTypeKind.ZodNull,
          ...processCreateParams(params)
        });
      };
      ZodAny = class extends ZodType {
        constructor() {
          super(...arguments);
          this._any = true;
        }
        _parse(input) {
          return OK(input.data);
        }
      };
      ZodAny.create = (params) => {
        return new ZodAny({
          typeName: ZodFirstPartyTypeKind.ZodAny,
          ...processCreateParams(params)
        });
      };
      ZodUnknown = class extends ZodType {
        constructor() {
          super(...arguments);
          this._unknown = true;
        }
        _parse(input) {
          return OK(input.data);
        }
      };
      ZodUnknown.create = (params) => {
        return new ZodUnknown({
          typeName: ZodFirstPartyTypeKind.ZodUnknown,
          ...processCreateParams(params)
        });
      };
      ZodNever = class extends ZodType {
        _parse(input) {
          const ctx = this._getOrReturnCtx(input);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: ZodParsedType.never,
            received: ctx.parsedType
          });
          return INVALID;
        }
      };
      ZodNever.create = (params) => {
        return new ZodNever({
          typeName: ZodFirstPartyTypeKind.ZodNever,
          ...processCreateParams(params)
        });
      };
      ZodVoid = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.undefined) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.void,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return OK(input.data);
        }
      };
      ZodVoid.create = (params) => {
        return new ZodVoid({
          typeName: ZodFirstPartyTypeKind.ZodVoid,
          ...processCreateParams(params)
        });
      };
      ZodArray = class _ZodArray extends ZodType {
        _parse(input) {
          const { ctx, status } = this._processInputParams(input);
          const def = this._def;
          if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.array,
              received: ctx.parsedType
            });
            return INVALID;
          }
          if (def.exactLength !== null) {
            const tooBig = ctx.data.length > def.exactLength.value;
            const tooSmall = ctx.data.length < def.exactLength.value;
            if (tooBig || tooSmall) {
              addIssueToContext(ctx, {
                code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
                minimum: tooSmall ? def.exactLength.value : void 0,
                maximum: tooBig ? def.exactLength.value : void 0,
                type: "array",
                inclusive: true,
                exact: true,
                message: def.exactLength.message
              });
              status.dirty();
            }
          }
          if (def.minLength !== null) {
            if (ctx.data.length < def.minLength.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: def.minLength.value,
                type: "array",
                inclusive: true,
                exact: false,
                message: def.minLength.message
              });
              status.dirty();
            }
          }
          if (def.maxLength !== null) {
            if (ctx.data.length > def.maxLength.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: def.maxLength.value,
                type: "array",
                inclusive: true,
                exact: false,
                message: def.maxLength.message
              });
              status.dirty();
            }
          }
          if (ctx.common.async) {
            return Promise.all([...ctx.data].map((item, i) => {
              return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
            })).then((result2) => {
              return ParseStatus.mergeArray(status, result2);
            });
          }
          const result = [...ctx.data].map((item, i) => {
            return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
          });
          return ParseStatus.mergeArray(status, result);
        }
        get element() {
          return this._def.type;
        }
        min(minLength, message) {
          return new _ZodArray({
            ...this._def,
            minLength: { value: minLength, message: errorUtil.toString(message) }
          });
        }
        max(maxLength, message) {
          return new _ZodArray({
            ...this._def,
            maxLength: { value: maxLength, message: errorUtil.toString(message) }
          });
        }
        length(len, message) {
          return new _ZodArray({
            ...this._def,
            exactLength: { value: len, message: errorUtil.toString(message) }
          });
        }
        nonempty(message) {
          return this.min(1, message);
        }
      };
      ZodArray.create = (schema, params) => {
        return new ZodArray({
          type: schema,
          minLength: null,
          maxLength: null,
          exactLength: null,
          typeName: ZodFirstPartyTypeKind.ZodArray,
          ...processCreateParams(params)
        });
      };
      ZodObject = class _ZodObject extends ZodType {
        constructor() {
          super(...arguments);
          this._cached = null;
          this.nonstrict = this.passthrough;
          this.augment = this.extend;
        }
        _getCached() {
          if (this._cached !== null)
            return this._cached;
          const shape = this._def.shape();
          const keys = util.objectKeys(shape);
          this._cached = { shape, keys };
          return this._cached;
        }
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.object) {
            const ctx2 = this._getOrReturnCtx(input);
            addIssueToContext(ctx2, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx2.parsedType
            });
            return INVALID;
          }
          const { status, ctx } = this._processInputParams(input);
          const { shape, keys: shapeKeys } = this._getCached();
          const extraKeys = [];
          if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
            for (const key in ctx.data) {
              if (!shapeKeys.includes(key)) {
                extraKeys.push(key);
              }
            }
          }
          const pairs = [];
          for (const key of shapeKeys) {
            const keyValidator = shape[key];
            const value = ctx.data[key];
            pairs.push({
              key: { status: "valid", value: key },
              value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
              alwaysSet: key in ctx.data
            });
          }
          if (this._def.catchall instanceof ZodNever) {
            const unknownKeys = this._def.unknownKeys;
            if (unknownKeys === "passthrough") {
              for (const key of extraKeys) {
                pairs.push({
                  key: { status: "valid", value: key },
                  value: { status: "valid", value: ctx.data[key] }
                });
              }
            } else if (unknownKeys === "strict") {
              if (extraKeys.length > 0) {
                addIssueToContext(ctx, {
                  code: ZodIssueCode.unrecognized_keys,
                  keys: extraKeys
                });
                status.dirty();
              }
            } else if (unknownKeys === "strip") {
            } else {
              throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
            }
          } else {
            const catchall = this._def.catchall;
            for (const key of extraKeys) {
              const value = ctx.data[key];
              pairs.push({
                key: { status: "valid", value: key },
                value: catchall._parse(
                  new ParseInputLazyPath(ctx, value, ctx.path, key)
                  //, ctx.child(key), value, getParsedType(value)
                ),
                alwaysSet: key in ctx.data
              });
            }
          }
          if (ctx.common.async) {
            return Promise.resolve().then(async () => {
              const syncPairs = [];
              for (const pair of pairs) {
                const key = await pair.key;
                const value = await pair.value;
                syncPairs.push({
                  key,
                  value,
                  alwaysSet: pair.alwaysSet
                });
              }
              return syncPairs;
            }).then((syncPairs) => {
              return ParseStatus.mergeObjectSync(status, syncPairs);
            });
          } else {
            return ParseStatus.mergeObjectSync(status, pairs);
          }
        }
        get shape() {
          return this._def.shape();
        }
        strict(message) {
          errorUtil.errToObj;
          return new _ZodObject({
            ...this._def,
            unknownKeys: "strict",
            ...message !== void 0 ? {
              errorMap: (issue, ctx) => {
                const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
                if (issue.code === "unrecognized_keys")
                  return {
                    message: errorUtil.errToObj(message).message ?? defaultError
                  };
                return {
                  message: defaultError
                };
              }
            } : {}
          });
        }
        strip() {
          return new _ZodObject({
            ...this._def,
            unknownKeys: "strip"
          });
        }
        passthrough() {
          return new _ZodObject({
            ...this._def,
            unknownKeys: "passthrough"
          });
        }
        // const AugmentFactory =
        //   <Def extends ZodObjectDef>(def: Def) =>
        //   <Augmentation extends ZodRawShape>(
        //     augmentation: Augmentation
        //   ): ZodObject<
        //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
        //     Def["unknownKeys"],
        //     Def["catchall"]
        //   > => {
        //     return new ZodObject({
        //       ...def,
        //       shape: () => ({
        //         ...def.shape(),
        //         ...augmentation,
        //       }),
        //     }) as any;
        //   };
        extend(augmentation) {
          return new _ZodObject({
            ...this._def,
            shape: () => ({
              ...this._def.shape(),
              ...augmentation
            })
          });
        }
        /**
         * Prior to zod@1.0.12 there was a bug in the
         * inferred type of merged objects. Please
         * upgrade if you are experiencing issues.
         */
        merge(merging) {
          const merged = new _ZodObject({
            unknownKeys: merging._def.unknownKeys,
            catchall: merging._def.catchall,
            shape: () => ({
              ...this._def.shape(),
              ...merging._def.shape()
            }),
            typeName: ZodFirstPartyTypeKind.ZodObject
          });
          return merged;
        }
        // merge<
        //   Incoming extends AnyZodObject,
        //   Augmentation extends Incoming["shape"],
        //   NewOutput extends {
        //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
        //       ? Augmentation[k]["_output"]
        //       : k extends keyof Output
        //       ? Output[k]
        //       : never;
        //   },
        //   NewInput extends {
        //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
        //       ? Augmentation[k]["_input"]
        //       : k extends keyof Input
        //       ? Input[k]
        //       : never;
        //   }
        // >(
        //   merging: Incoming
        // ): ZodObject<
        //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
        //   Incoming["_def"]["unknownKeys"],
        //   Incoming["_def"]["catchall"],
        //   NewOutput,
        //   NewInput
        // > {
        //   const merged: any = new ZodObject({
        //     unknownKeys: merging._def.unknownKeys,
        //     catchall: merging._def.catchall,
        //     shape: () =>
        //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
        //     typeName: ZodFirstPartyTypeKind.ZodObject,
        //   }) as any;
        //   return merged;
        // }
        setKey(key, schema) {
          return this.augment({ [key]: schema });
        }
        // merge<Incoming extends AnyZodObject>(
        //   merging: Incoming
        // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
        // ZodObject<
        //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
        //   Incoming["_def"]["unknownKeys"],
        //   Incoming["_def"]["catchall"]
        // > {
        //   // const mergedShape = objectUtil.mergeShapes(
        //   //   this._def.shape(),
        //   //   merging._def.shape()
        //   // );
        //   const merged: any = new ZodObject({
        //     unknownKeys: merging._def.unknownKeys,
        //     catchall: merging._def.catchall,
        //     shape: () =>
        //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
        //     typeName: ZodFirstPartyTypeKind.ZodObject,
        //   }) as any;
        //   return merged;
        // }
        catchall(index) {
          return new _ZodObject({
            ...this._def,
            catchall: index
          });
        }
        pick(mask) {
          const shape = {};
          for (const key of util.objectKeys(mask)) {
            if (mask[key] && this.shape[key]) {
              shape[key] = this.shape[key];
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => shape
          });
        }
        omit(mask) {
          const shape = {};
          for (const key of util.objectKeys(this.shape)) {
            if (!mask[key]) {
              shape[key] = this.shape[key];
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => shape
          });
        }
        /**
         * @deprecated
         */
        deepPartial() {
          return deepPartialify(this);
        }
        partial(mask) {
          const newShape = {};
          for (const key of util.objectKeys(this.shape)) {
            const fieldSchema = this.shape[key];
            if (mask && !mask[key]) {
              newShape[key] = fieldSchema;
            } else {
              newShape[key] = fieldSchema.optional();
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => newShape
          });
        }
        required(mask) {
          const newShape = {};
          for (const key of util.objectKeys(this.shape)) {
            if (mask && !mask[key]) {
              newShape[key] = this.shape[key];
            } else {
              const fieldSchema = this.shape[key];
              let newField = fieldSchema;
              while (newField instanceof ZodOptional) {
                newField = newField._def.innerType;
              }
              newShape[key] = newField;
            }
          }
          return new _ZodObject({
            ...this._def,
            shape: () => newShape
          });
        }
        keyof() {
          return createZodEnum(util.objectKeys(this.shape));
        }
      };
      ZodObject.create = (shape, params) => {
        return new ZodObject({
          shape: () => shape,
          unknownKeys: "strip",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params)
        });
      };
      ZodObject.strictCreate = (shape, params) => {
        return new ZodObject({
          shape: () => shape,
          unknownKeys: "strict",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params)
        });
      };
      ZodObject.lazycreate = (shape, params) => {
        return new ZodObject({
          shape,
          unknownKeys: "strip",
          catchall: ZodNever.create(),
          typeName: ZodFirstPartyTypeKind.ZodObject,
          ...processCreateParams(params)
        });
      };
      ZodUnion = class extends ZodType {
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          const options = this._def.options;
          function handleResults(results) {
            for (const result of results) {
              if (result.result.status === "valid") {
                return result.result;
              }
            }
            for (const result of results) {
              if (result.result.status === "dirty") {
                ctx.common.issues.push(...result.ctx.common.issues);
                return result.result;
              }
            }
            const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union,
              unionErrors
            });
            return INVALID;
          }
          if (ctx.common.async) {
            return Promise.all(options.map(async (option) => {
              const childCtx = {
                ...ctx,
                common: {
                  ...ctx.common,
                  issues: []
                },
                parent: null
              };
              return {
                result: await option._parseAsync({
                  data: ctx.data,
                  path: ctx.path,
                  parent: childCtx
                }),
                ctx: childCtx
              };
            })).then(handleResults);
          } else {
            let dirty = void 0;
            const issues = [];
            for (const option of options) {
              const childCtx = {
                ...ctx,
                common: {
                  ...ctx.common,
                  issues: []
                },
                parent: null
              };
              const result = option._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: childCtx
              });
              if (result.status === "valid") {
                return result;
              } else if (result.status === "dirty" && !dirty) {
                dirty = { result, ctx: childCtx };
              }
              if (childCtx.common.issues.length) {
                issues.push(childCtx.common.issues);
              }
            }
            if (dirty) {
              ctx.common.issues.push(...dirty.ctx.common.issues);
              return dirty.result;
            }
            const unionErrors = issues.map((issues2) => new ZodError(issues2));
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union,
              unionErrors
            });
            return INVALID;
          }
        }
        get options() {
          return this._def.options;
        }
      };
      ZodUnion.create = (types, params) => {
        return new ZodUnion({
          options: types,
          typeName: ZodFirstPartyTypeKind.ZodUnion,
          ...processCreateParams(params)
        });
      };
      getDiscriminator = (type) => {
        if (type instanceof ZodLazy) {
          return getDiscriminator(type.schema);
        } else if (type instanceof ZodEffects) {
          return getDiscriminator(type.innerType());
        } else if (type instanceof ZodLiteral) {
          return [type.value];
        } else if (type instanceof ZodEnum) {
          return type.options;
        } else if (type instanceof ZodNativeEnum) {
          return util.objectValues(type.enum);
        } else if (type instanceof ZodDefault) {
          return getDiscriminator(type._def.innerType);
        } else if (type instanceof ZodUndefined) {
          return [void 0];
        } else if (type instanceof ZodNull) {
          return [null];
        } else if (type instanceof ZodOptional) {
          return [void 0, ...getDiscriminator(type.unwrap())];
        } else if (type instanceof ZodNullable) {
          return [null, ...getDiscriminator(type.unwrap())];
        } else if (type instanceof ZodBranded) {
          return getDiscriminator(type.unwrap());
        } else if (type instanceof ZodReadonly) {
          return getDiscriminator(type.unwrap());
        } else if (type instanceof ZodCatch) {
          return getDiscriminator(type._def.innerType);
        } else {
          return [];
        }
      };
      ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const discriminator = this.discriminator;
          const discriminatorValue = ctx.data[discriminator];
          const option = this.optionsMap.get(discriminatorValue);
          if (!option) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_union_discriminator,
              options: Array.from(this.optionsMap.keys()),
              path: [discriminator]
            });
            return INVALID;
          }
          if (ctx.common.async) {
            return option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
          } else {
            return option._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
          }
        }
        get discriminator() {
          return this._def.discriminator;
        }
        get options() {
          return this._def.options;
        }
        get optionsMap() {
          return this._def.optionsMap;
        }
        /**
         * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
         * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
         * have a different value for each object in the union.
         * @param discriminator the name of the discriminator property
         * @param types an array of object schemas
         * @param params
         */
        static create(discriminator, options, params) {
          const optionsMap = /* @__PURE__ */ new Map();
          for (const type of options) {
            const discriminatorValues = getDiscriminator(type.shape[discriminator]);
            if (!discriminatorValues.length) {
              throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
            }
            for (const value of discriminatorValues) {
              if (optionsMap.has(value)) {
                throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
              }
              optionsMap.set(value, type);
            }
          }
          return new _ZodDiscriminatedUnion({
            typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
            discriminator,
            options,
            optionsMap,
            ...processCreateParams(params)
          });
        }
      };
      ZodIntersection = class extends ZodType {
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          const handleParsed = (parsedLeft, parsedRight) => {
            if (isAborted(parsedLeft) || isAborted(parsedRight)) {
              return INVALID;
            }
            const merged = mergeValues(parsedLeft.value, parsedRight.value);
            if (!merged.valid) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.invalid_intersection_types
              });
              return INVALID;
            }
            if (isDirty(parsedLeft) || isDirty(parsedRight)) {
              status.dirty();
            }
            return { status: status.value, value: merged.data };
          };
          if (ctx.common.async) {
            return Promise.all([
              this._def.left._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              }),
              this._def.right._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              })
            ]).then(([left, right]) => handleParsed(left, right));
          } else {
            return handleParsed(this._def.left._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }), this._def.right._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            }));
          }
        }
      };
      ZodIntersection.create = (left, right, params) => {
        return new ZodIntersection({
          left,
          right,
          typeName: ZodFirstPartyTypeKind.ZodIntersection,
          ...processCreateParams(params)
        });
      };
      ZodTuple = class _ZodTuple extends ZodType {
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.array) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.array,
              received: ctx.parsedType
            });
            return INVALID;
          }
          if (ctx.data.length < this._def.items.length) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: this._def.items.length,
              inclusive: true,
              exact: false,
              type: "array"
            });
            return INVALID;
          }
          const rest = this._def.rest;
          if (!rest && ctx.data.length > this._def.items.length) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: this._def.items.length,
              inclusive: true,
              exact: false,
              type: "array"
            });
            status.dirty();
          }
          const items = [...ctx.data].map((item, itemIndex) => {
            const schema = this._def.items[itemIndex] || this._def.rest;
            if (!schema)
              return null;
            return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
          }).filter((x) => !!x);
          if (ctx.common.async) {
            return Promise.all(items).then((results) => {
              return ParseStatus.mergeArray(status, results);
            });
          } else {
            return ParseStatus.mergeArray(status, items);
          }
        }
        get items() {
          return this._def.items;
        }
        rest(rest) {
          return new _ZodTuple({
            ...this._def,
            rest
          });
        }
      };
      ZodTuple.create = (schemas, params) => {
        if (!Array.isArray(schemas)) {
          throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
        }
        return new ZodTuple({
          items: schemas,
          typeName: ZodFirstPartyTypeKind.ZodTuple,
          rest: null,
          ...processCreateParams(params)
        });
      };
      ZodRecord = class _ZodRecord extends ZodType {
        get keySchema() {
          return this._def.keyType;
        }
        get valueSchema() {
          return this._def.valueType;
        }
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.object) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.object,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const pairs = [];
          const keyType = this._def.keyType;
          const valueType = this._def.valueType;
          for (const key in ctx.data) {
            pairs.push({
              key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
              value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
              alwaysSet: key in ctx.data
            });
          }
          if (ctx.common.async) {
            return ParseStatus.mergeObjectAsync(status, pairs);
          } else {
            return ParseStatus.mergeObjectSync(status, pairs);
          }
        }
        get element() {
          return this._def.valueType;
        }
        static create(first, second, third) {
          if (second instanceof ZodType) {
            return new _ZodRecord({
              keyType: first,
              valueType: second,
              typeName: ZodFirstPartyTypeKind.ZodRecord,
              ...processCreateParams(third)
            });
          }
          return new _ZodRecord({
            keyType: ZodString.create(),
            valueType: first,
            typeName: ZodFirstPartyTypeKind.ZodRecord,
            ...processCreateParams(second)
          });
        }
      };
      ZodMap = class extends ZodType {
        get keySchema() {
          return this._def.keyType;
        }
        get valueSchema() {
          return this._def.valueType;
        }
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.map) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.map,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const keyType = this._def.keyType;
          const valueType = this._def.valueType;
          const pairs = [...ctx.data.entries()].map(([key, value], index) => {
            return {
              key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
              value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
            };
          });
          if (ctx.common.async) {
            const finalMap = /* @__PURE__ */ new Map();
            return Promise.resolve().then(async () => {
              for (const pair of pairs) {
                const key = await pair.key;
                const value = await pair.value;
                if (key.status === "aborted" || value.status === "aborted") {
                  return INVALID;
                }
                if (key.status === "dirty" || value.status === "dirty") {
                  status.dirty();
                }
                finalMap.set(key.value, value.value);
              }
              return { status: status.value, value: finalMap };
            });
          } else {
            const finalMap = /* @__PURE__ */ new Map();
            for (const pair of pairs) {
              const key = pair.key;
              const value = pair.value;
              if (key.status === "aborted" || value.status === "aborted") {
                return INVALID;
              }
              if (key.status === "dirty" || value.status === "dirty") {
                status.dirty();
              }
              finalMap.set(key.value, value.value);
            }
            return { status: status.value, value: finalMap };
          }
        }
      };
      ZodMap.create = (keyType, valueType, params) => {
        return new ZodMap({
          valueType,
          keyType,
          typeName: ZodFirstPartyTypeKind.ZodMap,
          ...processCreateParams(params)
        });
      };
      ZodSet = class _ZodSet extends ZodType {
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.set) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.set,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const def = this._def;
          if (def.minSize !== null) {
            if (ctx.data.size < def.minSize.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: def.minSize.value,
                type: "set",
                inclusive: true,
                exact: false,
                message: def.minSize.message
              });
              status.dirty();
            }
          }
          if (def.maxSize !== null) {
            if (ctx.data.size > def.maxSize.value) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: def.maxSize.value,
                type: "set",
                inclusive: true,
                exact: false,
                message: def.maxSize.message
              });
              status.dirty();
            }
          }
          const valueType = this._def.valueType;
          function finalizeSet(elements2) {
            const parsedSet = /* @__PURE__ */ new Set();
            for (const element of elements2) {
              if (element.status === "aborted")
                return INVALID;
              if (element.status === "dirty")
                status.dirty();
              parsedSet.add(element.value);
            }
            return { status: status.value, value: parsedSet };
          }
          const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
          if (ctx.common.async) {
            return Promise.all(elements).then((elements2) => finalizeSet(elements2));
          } else {
            return finalizeSet(elements);
          }
        }
        min(minSize, message) {
          return new _ZodSet({
            ...this._def,
            minSize: { value: minSize, message: errorUtil.toString(message) }
          });
        }
        max(maxSize, message) {
          return new _ZodSet({
            ...this._def,
            maxSize: { value: maxSize, message: errorUtil.toString(message) }
          });
        }
        size(size, message) {
          return this.min(size, message).max(size, message);
        }
        nonempty(message) {
          return this.min(1, message);
        }
      };
      ZodSet.create = (valueType, params) => {
        return new ZodSet({
          valueType,
          minSize: null,
          maxSize: null,
          typeName: ZodFirstPartyTypeKind.ZodSet,
          ...processCreateParams(params)
        });
      };
      ZodFunction = class _ZodFunction extends ZodType {
        constructor() {
          super(...arguments);
          this.validate = this.implement;
        }
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.function) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.function,
              received: ctx.parsedType
            });
            return INVALID;
          }
          function makeArgsIssue(args, error) {
            return makeIssue({
              data: args,
              path: ctx.path,
              errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
              issueData: {
                code: ZodIssueCode.invalid_arguments,
                argumentsError: error
              }
            });
          }
          function makeReturnsIssue(returns, error) {
            return makeIssue({
              data: returns,
              path: ctx.path,
              errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
              issueData: {
                code: ZodIssueCode.invalid_return_type,
                returnTypeError: error
              }
            });
          }
          const params = { errorMap: ctx.common.contextualErrorMap };
          const fn = ctx.data;
          if (this._def.returns instanceof ZodPromise) {
            const me = this;
            return OK(async function(...args) {
              const error = new ZodError([]);
              const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
                error.addIssue(makeArgsIssue(args, e));
                throw error;
              });
              const result = await Reflect.apply(fn, this, parsedArgs);
              const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
                error.addIssue(makeReturnsIssue(result, e));
                throw error;
              });
              return parsedReturns;
            });
          } else {
            const me = this;
            return OK(function(...args) {
              const parsedArgs = me._def.args.safeParse(args, params);
              if (!parsedArgs.success) {
                throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
              }
              const result = Reflect.apply(fn, this, parsedArgs.data);
              const parsedReturns = me._def.returns.safeParse(result, params);
              if (!parsedReturns.success) {
                throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
              }
              return parsedReturns.data;
            });
          }
        }
        parameters() {
          return this._def.args;
        }
        returnType() {
          return this._def.returns;
        }
        args(...items) {
          return new _ZodFunction({
            ...this._def,
            args: ZodTuple.create(items).rest(ZodUnknown.create())
          });
        }
        returns(returnType) {
          return new _ZodFunction({
            ...this._def,
            returns: returnType
          });
        }
        implement(func) {
          const validatedFunc = this.parse(func);
          return validatedFunc;
        }
        strictImplement(func) {
          const validatedFunc = this.parse(func);
          return validatedFunc;
        }
        static create(args, returns, params) {
          return new _ZodFunction({
            args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
            returns: returns || ZodUnknown.create(),
            typeName: ZodFirstPartyTypeKind.ZodFunction,
            ...processCreateParams(params)
          });
        }
      };
      ZodLazy = class extends ZodType {
        get schema() {
          return this._def.getter();
        }
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          const lazySchema = this._def.getter();
          return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
        }
      };
      ZodLazy.create = (getter, params) => {
        return new ZodLazy({
          getter,
          typeName: ZodFirstPartyTypeKind.ZodLazy,
          ...processCreateParams(params)
        });
      };
      ZodLiteral = class extends ZodType {
        _parse(input) {
          if (input.data !== this._def.value) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_literal,
              expected: this._def.value
            });
            return INVALID;
          }
          return { status: "valid", value: input.data };
        }
        get value() {
          return this._def.value;
        }
      };
      ZodLiteral.create = (value, params) => {
        return new ZodLiteral({
          value,
          typeName: ZodFirstPartyTypeKind.ZodLiteral,
          ...processCreateParams(params)
        });
      };
      ZodEnum = class _ZodEnum extends ZodType {
        _parse(input) {
          if (typeof input.data !== "string") {
            const ctx = this._getOrReturnCtx(input);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
              expected: util.joinValues(expectedValues),
              received: ctx.parsedType,
              code: ZodIssueCode.invalid_type
            });
            return INVALID;
          }
          if (!this._cache) {
            this._cache = new Set(this._def.values);
          }
          if (!this._cache.has(input.data)) {
            const ctx = this._getOrReturnCtx(input);
            const expectedValues = this._def.values;
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_enum_value,
              options: expectedValues
            });
            return INVALID;
          }
          return OK(input.data);
        }
        get options() {
          return this._def.values;
        }
        get enum() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        get Values() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        get Enum() {
          const enumValues = {};
          for (const val of this._def.values) {
            enumValues[val] = val;
          }
          return enumValues;
        }
        extract(values, newDef = this._def) {
          return _ZodEnum.create(values, {
            ...this._def,
            ...newDef
          });
        }
        exclude(values, newDef = this._def) {
          return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
            ...this._def,
            ...newDef
          });
        }
      };
      ZodEnum.create = createZodEnum;
      ZodNativeEnum = class extends ZodType {
        _parse(input) {
          const nativeEnumValues = util.getValidEnumValues(this._def.values);
          const ctx = this._getOrReturnCtx(input);
          if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
            const expectedValues = util.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
              expected: util.joinValues(expectedValues),
              received: ctx.parsedType,
              code: ZodIssueCode.invalid_type
            });
            return INVALID;
          }
          if (!this._cache) {
            this._cache = new Set(util.getValidEnumValues(this._def.values));
          }
          if (!this._cache.has(input.data)) {
            const expectedValues = util.objectValues(nativeEnumValues);
            addIssueToContext(ctx, {
              received: ctx.data,
              code: ZodIssueCode.invalid_enum_value,
              options: expectedValues
            });
            return INVALID;
          }
          return OK(input.data);
        }
        get enum() {
          return this._def.values;
        }
      };
      ZodNativeEnum.create = (values, params) => {
        return new ZodNativeEnum({
          values,
          typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
          ...processCreateParams(params)
        });
      };
      ZodPromise = class extends ZodType {
        unwrap() {
          return this._def.type;
        }
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.promise,
              received: ctx.parsedType
            });
            return INVALID;
          }
          const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
          return OK(promisified.then((data) => {
            return this._def.type.parseAsync(data, {
              path: ctx.path,
              errorMap: ctx.common.contextualErrorMap
            });
          }));
        }
      };
      ZodPromise.create = (schema, params) => {
        return new ZodPromise({
          type: schema,
          typeName: ZodFirstPartyTypeKind.ZodPromise,
          ...processCreateParams(params)
        });
      };
      ZodEffects = class extends ZodType {
        innerType() {
          return this._def.schema;
        }
        sourceType() {
          return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
        }
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          const effect = this._def.effect || null;
          const checkCtx = {
            addIssue: (arg) => {
              addIssueToContext(ctx, arg);
              if (arg.fatal) {
                status.abort();
              } else {
                status.dirty();
              }
            },
            get path() {
              return ctx.path;
            }
          };
          checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
          if (effect.type === "preprocess") {
            const processed = effect.transform(ctx.data, checkCtx);
            if (ctx.common.async) {
              return Promise.resolve(processed).then(async (processed2) => {
                if (status.value === "aborted")
                  return INVALID;
                const result = await this._def.schema._parseAsync({
                  data: processed2,
                  path: ctx.path,
                  parent: ctx
                });
                if (result.status === "aborted")
                  return INVALID;
                if (result.status === "dirty")
                  return DIRTY(result.value);
                if (status.value === "dirty")
                  return DIRTY(result.value);
                return result;
              });
            } else {
              if (status.value === "aborted")
                return INVALID;
              const result = this._def.schema._parseSync({
                data: processed,
                path: ctx.path,
                parent: ctx
              });
              if (result.status === "aborted")
                return INVALID;
              if (result.status === "dirty")
                return DIRTY(result.value);
              if (status.value === "dirty")
                return DIRTY(result.value);
              return result;
            }
          }
          if (effect.type === "refinement") {
            const executeRefinement = (acc) => {
              const result = effect.refinement(acc, checkCtx);
              if (ctx.common.async) {
                return Promise.resolve(result);
              }
              if (result instanceof Promise) {
                throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
              }
              return acc;
            };
            if (ctx.common.async === false) {
              const inner = this._def.schema._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (inner.status === "aborted")
                return INVALID;
              if (inner.status === "dirty")
                status.dirty();
              executeRefinement(inner.value);
              return { status: status.value, value: inner.value };
            } else {
              return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
                if (inner.status === "aborted")
                  return INVALID;
                if (inner.status === "dirty")
                  status.dirty();
                return executeRefinement(inner.value).then(() => {
                  return { status: status.value, value: inner.value };
                });
              });
            }
          }
          if (effect.type === "transform") {
            if (ctx.common.async === false) {
              const base = this._def.schema._parseSync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (!isValid(base))
                return INVALID;
              const result = effect.transform(base.value, checkCtx);
              if (result instanceof Promise) {
                throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
              }
              return { status: status.value, value: result };
            } else {
              return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
                if (!isValid(base))
                  return INVALID;
                return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
                  status: status.value,
                  value: result
                }));
              });
            }
          }
          util.assertNever(effect);
        }
      };
      ZodEffects.create = (schema, effect, params) => {
        return new ZodEffects({
          schema,
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          effect,
          ...processCreateParams(params)
        });
      };
      ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
        return new ZodEffects({
          schema,
          effect: { type: "preprocess", transform: preprocess },
          typeName: ZodFirstPartyTypeKind.ZodEffects,
          ...processCreateParams(params)
        });
      };
      ZodOptional = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType === ZodParsedType.undefined) {
            return OK(void 0);
          }
          return this._def.innerType._parse(input);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodOptional.create = (type, params) => {
        return new ZodOptional({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodOptional,
          ...processCreateParams(params)
        });
      };
      ZodNullable = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType === ZodParsedType.null) {
            return OK(null);
          }
          return this._def.innerType._parse(input);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodNullable.create = (type, params) => {
        return new ZodNullable({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodNullable,
          ...processCreateParams(params)
        });
      };
      ZodDefault = class extends ZodType {
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          let data = ctx.data;
          if (ctx.parsedType === ZodParsedType.undefined) {
            data = this._def.defaultValue();
          }
          return this._def.innerType._parse({
            data,
            path: ctx.path,
            parent: ctx
          });
        }
        removeDefault() {
          return this._def.innerType;
        }
      };
      ZodDefault.create = (type, params) => {
        return new ZodDefault({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodDefault,
          defaultValue: typeof params.default === "function" ? params.default : () => params.default,
          ...processCreateParams(params)
        });
      };
      ZodCatch = class extends ZodType {
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          const newCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            }
          };
          const result = this._def.innerType._parse({
            data: newCtx.data,
            path: newCtx.path,
            parent: {
              ...newCtx
            }
          });
          if (isAsync(result)) {
            return result.then((result2) => {
              return {
                status: "valid",
                value: result2.status === "valid" ? result2.value : this._def.catchValue({
                  get error() {
                    return new ZodError(newCtx.common.issues);
                  },
                  input: newCtx.data
                })
              };
            });
          } else {
            return {
              status: "valid",
              value: result.status === "valid" ? result.value : this._def.catchValue({
                get error() {
                  return new ZodError(newCtx.common.issues);
                },
                input: newCtx.data
              })
            };
          }
        }
        removeCatch() {
          return this._def.innerType;
        }
      };
      ZodCatch.create = (type, params) => {
        return new ZodCatch({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodCatch,
          catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
          ...processCreateParams(params)
        });
      };
      ZodNaN = class extends ZodType {
        _parse(input) {
          const parsedType = this._getType(input);
          if (parsedType !== ZodParsedType.nan) {
            const ctx = this._getOrReturnCtx(input);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: ZodParsedType.nan,
              received: ctx.parsedType
            });
            return INVALID;
          }
          return { status: "valid", value: input.data };
        }
      };
      ZodNaN.create = (params) => {
        return new ZodNaN({
          typeName: ZodFirstPartyTypeKind.ZodNaN,
          ...processCreateParams(params)
        });
      };
      BRAND = /* @__PURE__ */ Symbol("zod_brand");
      ZodBranded = class extends ZodType {
        _parse(input) {
          const { ctx } = this._processInputParams(input);
          const data = ctx.data;
          return this._def.type._parse({
            data,
            path: ctx.path,
            parent: ctx
          });
        }
        unwrap() {
          return this._def.type;
        }
      };
      ZodPipeline = class _ZodPipeline extends ZodType {
        _parse(input) {
          const { status, ctx } = this._processInputParams(input);
          if (ctx.common.async) {
            const handleAsync = async () => {
              const inResult = await this._def.in._parseAsync({
                data: ctx.data,
                path: ctx.path,
                parent: ctx
              });
              if (inResult.status === "aborted")
                return INVALID;
              if (inResult.status === "dirty") {
                status.dirty();
                return DIRTY(inResult.value);
              } else {
                return this._def.out._parseAsync({
                  data: inResult.value,
                  path: ctx.path,
                  parent: ctx
                });
              }
            };
            return handleAsync();
          } else {
            const inResult = this._def.in._parseSync({
              data: ctx.data,
              path: ctx.path,
              parent: ctx
            });
            if (inResult.status === "aborted")
              return INVALID;
            if (inResult.status === "dirty") {
              status.dirty();
              return {
                status: "dirty",
                value: inResult.value
              };
            } else {
              return this._def.out._parseSync({
                data: inResult.value,
                path: ctx.path,
                parent: ctx
              });
            }
          }
        }
        static create(a, b) {
          return new _ZodPipeline({
            in: a,
            out: b,
            typeName: ZodFirstPartyTypeKind.ZodPipeline
          });
        }
      };
      ZodReadonly = class extends ZodType {
        _parse(input) {
          const result = this._def.innerType._parse(input);
          const freeze = (data) => {
            if (isValid(data)) {
              data.value = Object.freeze(data.value);
            }
            return data;
          };
          return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
        }
        unwrap() {
          return this._def.innerType;
        }
      };
      ZodReadonly.create = (type, params) => {
        return new ZodReadonly({
          innerType: type,
          typeName: ZodFirstPartyTypeKind.ZodReadonly,
          ...processCreateParams(params)
        });
      };
      late = {
        object: ZodObject.lazycreate
      };
      (function(ZodFirstPartyTypeKind2) {
        ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
        ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
        ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
        ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
        ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
        ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
        ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
        ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
        ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
        ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
        ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
        ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
        ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
        ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
        ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
        ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
        ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
        ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
        ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
        ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
        ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
        ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
        ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
        ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
        ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
        ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
        ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
        ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
        ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
        ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
        ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
        ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
        ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
        ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
        ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
        ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
      })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
      instanceOfType = (cls, params = {
        message: `Input not instance of ${cls.name}`
      }) => custom((data) => data instanceof cls, params);
      stringType = ZodString.create;
      numberType = ZodNumber.create;
      nanType = ZodNaN.create;
      bigIntType = ZodBigInt.create;
      booleanType = ZodBoolean.create;
      dateType = ZodDate.create;
      symbolType = ZodSymbol.create;
      undefinedType = ZodUndefined.create;
      nullType = ZodNull.create;
      anyType = ZodAny.create;
      unknownType = ZodUnknown.create;
      neverType = ZodNever.create;
      voidType = ZodVoid.create;
      arrayType = ZodArray.create;
      objectType = ZodObject.create;
      strictObjectType = ZodObject.strictCreate;
      unionType = ZodUnion.create;
      discriminatedUnionType = ZodDiscriminatedUnion.create;
      intersectionType = ZodIntersection.create;
      tupleType = ZodTuple.create;
      recordType = ZodRecord.create;
      mapType = ZodMap.create;
      setType = ZodSet.create;
      functionType = ZodFunction.create;
      lazyType = ZodLazy.create;
      literalType = ZodLiteral.create;
      enumType = ZodEnum.create;
      nativeEnumType = ZodNativeEnum.create;
      promiseType = ZodPromise.create;
      effectsType = ZodEffects.create;
      optionalType = ZodOptional.create;
      nullableType = ZodNullable.create;
      preprocessType = ZodEffects.createWithPreprocess;
      pipelineType = ZodPipeline.create;
      ostring = () => stringType().optional();
      onumber = () => numberType().optional();
      oboolean = () => booleanType().optional();
      coerce = {
        string: ((arg) => ZodString.create({ ...arg, coerce: true })),
        number: ((arg) => ZodNumber.create({ ...arg, coerce: true })),
        boolean: ((arg) => ZodBoolean.create({
          ...arg,
          coerce: true
        })),
        bigint: ((arg) => ZodBigInt.create({ ...arg, coerce: true })),
        date: ((arg) => ZodDate.create({ ...arg, coerce: true }))
      };
      NEVER = INVALID;
    }
  });

  // node_modules/zod/v3/external.js
  var external_exports = {};
  __export(external_exports, {
    BRAND: () => BRAND,
    DIRTY: () => DIRTY,
    EMPTY_PATH: () => EMPTY_PATH,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    OK: () => OK,
    ParseStatus: () => ParseStatus,
    Schema: () => ZodType,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBigInt: () => ZodBigInt,
    ZodBoolean: () => ZodBoolean,
    ZodBranded: () => ZodBranded,
    ZodCatch: () => ZodCatch,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodEffects: () => ZodEffects,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNativeEnum: () => ZodNativeEnum,
    ZodNever: () => ZodNever,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodParsedType: () => ZodParsedType,
    ZodPipeline: () => ZodPipeline,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSchema: () => ZodType,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodSymbol: () => ZodSymbol,
    ZodTransformer: () => ZodEffects,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    addIssueToContext: () => addIssueToContext,
    any: () => anyType,
    array: () => arrayType,
    bigint: () => bigIntType,
    boolean: () => booleanType,
    coerce: () => coerce,
    custom: () => custom,
    date: () => dateType,
    datetimeRegex: () => datetimeRegex,
    defaultErrorMap: () => en_default,
    discriminatedUnion: () => discriminatedUnionType,
    effect: () => effectsType,
    enum: () => enumType,
    function: () => functionType,
    getErrorMap: () => getErrorMap,
    getParsedType: () => getParsedType,
    instanceof: () => instanceOfType,
    intersection: () => intersectionType,
    isAborted: () => isAborted,
    isAsync: () => isAsync,
    isDirty: () => isDirty,
    isValid: () => isValid,
    late: () => late,
    lazy: () => lazyType,
    literal: () => literalType,
    makeIssue: () => makeIssue,
    map: () => mapType,
    nan: () => nanType,
    nativeEnum: () => nativeEnumType,
    never: () => neverType,
    null: () => nullType,
    nullable: () => nullableType,
    number: () => numberType,
    object: () => objectType,
    objectUtil: () => objectUtil,
    oboolean: () => oboolean,
    onumber: () => onumber,
    optional: () => optionalType,
    ostring: () => ostring,
    pipeline: () => pipelineType,
    preprocess: () => preprocessType,
    promise: () => promiseType,
    quotelessJson: () => quotelessJson,
    record: () => recordType,
    set: () => setType,
    setErrorMap: () => setErrorMap,
    strictObject: () => strictObjectType,
    string: () => stringType,
    symbol: () => symbolType,
    transformer: () => effectsType,
    tuple: () => tupleType,
    undefined: () => undefinedType,
    union: () => unionType,
    unknown: () => unknownType,
    util: () => util,
    void: () => voidType
  });
  var init_external = __esm({
    "node_modules/zod/v3/external.js"() {
      init_errors();
      init_parseUtil();
      init_typeAliases();
      init_util();
      init_types();
      init_ZodError();
    }
  });

  // node_modules/zod/index.js
  var init_zod = __esm({
    "node_modules/zod/index.js"() {
      init_external();
      init_external();
    }
  });

  // src/core/images.ts
  var coordinate, imageRegionSchema, imageResultSchema, imageDataSchema;
  var init_images = __esm({
    "src/core/images.ts"() {
      "use strict";
      init_zod();
      coordinate = external_exports.number().finite().min(0).max(1e3);
      imageRegionSchema = external_exports.object({
        box: external_exports.tuple([coordinate, coordinate, coordinate, coordinate]).refine(([top, left, bottom, right]) => bottom > top && right > left),
        source: external_exports.string().min(1).max(4e3),
        translation: external_exports.string().min(1).max(8e3)
      });
      imageResultSchema = external_exports.object({ regions: external_exports.array(imageRegionSchema).max(100) });
      imageDataSchema = external_exports.string().max(45e5).regex(/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/);
    }
  });

  // src/core/vocabulary.ts
  var lookupInputSchema, dictionarySchema, vocabularyDraftSchema, vocabularyItemSchema;
  var init_vocabulary = __esm({
    "src/core/vocabulary.ts"() {
      "use strict";
      init_zod();
      lookupInputSchema = external_exports.object({
        term: external_exports.string().trim().min(1).max(160),
        context: external_exports.string().max(1600)
      });
      dictionarySchema = external_exports.object({
        pronunciation: external_exports.string().max(200),
        sourceLanguage: external_exports.string().min(2).max(30),
        senses: external_exports.array(external_exports.object({
          partOfSpeech: external_exports.string().max(80),
          meaning: external_exports.string().min(1).max(1200),
          example: external_exports.string().min(1).max(1200),
          translation: external_exports.string().min(1).max(1200)
        })).min(1).max(6),
        contextualMeaning: external_exports.string().min(1).max(1600)
      });
      vocabularyDraftSchema = lookupInputSchema.extend({ target: external_exports.string().min(2).max(30), entry: dictionarySchema });
      vocabularyItemSchema = vocabularyDraftSchema.extend({
        id: external_exports.string().min(1).max(2e3),
        url: external_exports.string().max(2e3),
        savedAt: external_exports.number().nonnegative(),
        dueAt: external_exports.number().nonnegative(),
        interval: external_exports.number().int().min(0).max(365),
        reviews: external_exports.number().int().nonnegative()
      });
    }
  });

  // src/core/settings.ts
  function matchesSite(host, rule) {
    const r = rule.trim().toLowerCase();
    return r.startsWith("*.") ? host === r.slice(2) || host.endsWith("." + r.slice(2)) : host === r;
  }
  function sitePolicy(host, s) {
    if (s.blockSites.some((r) => matchesSite(host, r)))
      return "blocked";
    return s.autoTranslate || s.allowSites.some((r) => matchesSite(host, r)) ? "auto" : "manual";
  }
  var modeSchema, providerIdSchema, providerSchema, settingsSchema, publicSettingsSchema;
  var init_settings = __esm({
    "src/core/settings.ts"() {
      "use strict";
      init_zod();
      modeSchema = external_exports.enum(["original", "bilingual", "translated"]);
      providerIdSchema = external_exports.enum(["openai", "gemini", "deepl"]);
      providerSchema = external_exports.object({ apiKey: external_exports.string().max(4096).default(""), endpoint: external_exports.string().url(), model: external_exports.string().max(200), prompt: external_exports.string().max(8e3) });
      settingsSchema = external_exports.object({ source: external_exports.string().min(2).max(30), target: external_exports.string().min(2).max(30), mode: modeSchema, provider: providerIdSchema, autoTranslate: external_exports.boolean(), hover: external_exports.boolean(), subtitles: external_exports.boolean(), images: external_exports.boolean().default(false), style: external_exports.object({ theme: external_exports.enum(["plain", "highlight", "gray", "underline", "dotted", "dashed", "wavy", "blockquote", "mask"]).default("highlight"), color: external_exports.string().regex(/^#[\da-f]{6}$/i), background: external_exports.string().regex(/^#[\da-f]{6}$/i), fontSize: external_exports.number().min(50).max(200), border: external_exports.boolean() }), allowSites: external_exports.array(external_exports.string().max(253)).max(1e3), blockSites: external_exports.array(external_exports.string().max(253)).max(1e3), providers: external_exports.object({ openai: providerSchema, gemini: providerSchema, deepl: providerSchema }), requestsPerMinute: external_exports.number().int().min(1).max(120), batchSize: external_exports.number().int().min(1).max(20) });
      publicSettingsSchema = settingsSchema.omit({ providers: true });
    }
  });

  // src/core/messages.ts
  var messages_exports = {};
  __export(messages_exports, {
    contentMessageSchema: () => contentMessageSchema,
    requestSchema: () => requestSchema,
    rpc: () => rpc,
    translate: () => translate,
    translateSubtitles: () => translateSubtitles,
    unwrapReply: () => unwrapReply
  });
  async function rpc(request) {
    return unwrapReply(await chrome.runtime.sendMessage(request));
  }
  async function translate(texts) {
    return external_exports.array(external_exports.string()).parse(await rpc({ kind: "translate", texts }));
  }
  function unwrapReply(value) {
    const parsed = replySchema.parse(value);
    if (!parsed.ok) throw new Error(parsed.error);
    return parsed.data;
  }
  async function translateSubtitles(texts) {
    return external_exports.array(external_exports.string()).parse(await rpc({ kind: "translate", texts, priority: "subtitle" }));
  }
  var requestSchema, replySchema, contentMessageSchema;
  var init_messages = __esm({
    "src/core/messages.ts"() {
      "use strict";
      init_images();
      init_vocabulary();
      init_zod();
      init_settings();
      requestSchema = external_exports.discriminatedUnion("kind", [
        external_exports.object({ kind: external_exports.literal("image.read"), url: external_exports.string().url().max(16e3) }),
        external_exports.object({ kind: external_exports.literal("image.translate"), data: imageDataSchema }),
        lookupInputSchema.extend({ kind: external_exports.literal("dictionary.lookup") }),
        external_exports.object({ kind: external_exports.literal("vocabulary.save"), draft: vocabularyDraftSchema }),
        external_exports.object({ kind: external_exports.literal("vocabulary.open") }),
        external_exports.object({ kind: external_exports.literal("vocabulary.list") }),
        external_exports.object({ kind: external_exports.literal("vocabulary.remove"), id: external_exports.string().startsWith("vocabulary:").max(2e3) }),
        external_exports.object({ kind: external_exports.literal("vocabulary.review"), id: external_exports.string().startsWith("vocabulary:").max(2e3), remembered: external_exports.boolean() }),
        external_exports.object({ kind: external_exports.literal("settings.get") }),
        external_exports.object({ kind: external_exports.literal("settings.public") }),
        external_exports.object({ kind: external_exports.literal("settings.save"), settings: settingsSchema }),
        external_exports.object({ kind: external_exports.literal("captions.info") }),
        external_exports.object({ kind: external_exports.literal("translate"), priority: external_exports.enum(["normal", "subtitle"]).optional(), texts: external_exports.array(external_exports.string().max(12e3)).min(1).max(40), source: external_exports.string().min(2).max(30).optional(), target: external_exports.string().min(2).max(30).optional() }),
        external_exports.object({ kind: external_exports.literal("page.mode"), mode: modeSchema }),
        external_exports.object({ kind: external_exports.literal("page.selection"), text: external_exports.string().max(12e3).optional() }),
        external_exports.object({ kind: external_exports.literal("stats.get") }),
        external_exports.object({ kind: external_exports.literal("cache.clear") }),
        external_exports.object({ kind: external_exports.literal("stats.clear") }),
        external_exports.object({ kind: external_exports.literal("data.reset") })
      ]);
      replySchema = external_exports.discriminatedUnion("ok", [external_exports.object({ ok: external_exports.literal(true), data: external_exports.unknown() }), external_exports.object({ ok: external_exports.literal(false), error: external_exports.string() })]);
      contentMessageSchema = external_exports.discriminatedUnion("kind", [
        external_exports.object({ kind: external_exports.literal("page.mode"), mode: modeSchema }),
        external_exports.object({ kind: external_exports.literal("page.selection"), text: external_exports.string().max(12e3).optional() }),
        external_exports.object({ kind: external_exports.literal("page.toggle") }),
        external_exports.object({ kind: external_exports.literal("settings.updated"), settings: publicSettingsSchema, restore: external_exports.boolean().default(false) })
      ]);
    }
  });

  // src/content/content.ts
  init_messages();
  init_settings();

  // src/content/image-style.ts
  var fallbackPalette = { background: "#fff", foreground: "#191919" };
  function imagePalette(pixels) {
    const colors = /* @__PURE__ */ new Map();
    for (let i = 0; i + 3 < pixels.length; i += 4) {
      if ((pixels[i + 3] ?? 0) < 128) continue;
      const red = pixels[i] ?? 255, green = pixels[i + 1] ?? 255, blue = pixels[i + 2] ?? 255;
      const key = `${red >> 4}:${green >> 4}:${blue >> 4}`;
      const color = colors.get(key);
      if (color) {
        color.count++;
        color.red += red;
        color.green += green;
        color.blue += blue;
      } else colors.set(key, { count: 1, red, green, blue });
    }
    let best;
    for (const color of colors.values()) if (!best || color.count > best.count) best = color;
    if (!best) return fallbackPalette;
    const rgb = [best.red, best.green, best.blue].map((channel) => Math.round(channel / best.count));
    const luminance = rgb.reduce((sum, channel, i) => {
      const value = channel / 255;
      return sum + (value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4) * ([0.2126, 0.7152, 0.0722][i] ?? 0);
    }, 0);
    return { background: `rgb(${rgb.join(",")})`, foreground: luminance > 0.179 ? "#191919" : "#fff" };
  }
  function imageFontSize(text, width, height, measure) {
    for (let size = 24; size >= 7; size--) {
      let lines = 1, line = "";
      for (const char of text) {
        if (lines * size * 1.2 > Math.max(0, height - 4)) break;
        if (char === "\n") {
          lines++;
          line = "";
          continue;
        }
        if (line && measure(line + char, size) > Math.max(1, width - 6)) {
          lines++;
          line = char;
        } else line += char;
      }
      if (lines * size * 1.2 <= Math.max(0, height - 4)) return size;
    }
    return 7;
  }

  // src/content/images.ts
  init_messages();
  init_images();

  // src/content/dom.ts
  var OWN_ATTRIBUTE = "data-local-translate";
  var LABEL_SELECTOR = 'a[href],[role="menuitem"],[role="tab"]';
  var PROSE_SELECTOR = "p,h1,h2,h3,h4,h5,h6,li,blockquote,figcaption,td,th,dt,dd";
  var BLOCK_SELECTOR = `p,h1,h2,h3,h4,h5,h6,li,blockquote,figcaption,td,th,dt,dd,summary,div,section,article,${LABEL_SELECTOR}`;
  function standaloneLabel(element) {
    return element.matches(LABEL_SELECTOR) && !element.closest(PROSE_SELECTOR);
  }
  var AD_SELECTOR = 'ins.adsbygoogle,[id^="google_ads_"],[id^="div-gpt-ad"],[data-ad],[data-ad-client],[data-ad-slot],[data-ad-unit],[data-testid*="ad" i],[aria-label="Advertisement" i],[aria-label="Sponsored" i],[aria-label*="\u5EE3\u544A"],.ad-showing,.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-player-overlay,ytd-ad-slot-renderer,ytd-in-feed-ad-layout-renderer,ytd-promoted-sparkles-web-renderer,ytd-promoted-video-renderer,ytd-display-ad-renderer,ytd-statement-banner-renderer,ytd-banner-promo-renderer';
  var EXCLUDED = `overflow-nav,.UnderlineNav,nav[aria-label="Repository" i],[role="tablist"],[role="tree"],[role="treeitem"],nav[aria-label*="breadcrumb" i],.react-code-view-header-path,.react-directory-filename-column,a[href*="/blob/"],a[href*="/tree/"],script,style,noscript,template,textarea,input,select,option,button,pre,code,kbd,samp,svg,canvas,math,rp,rt,[role="code"],.katex,.MathJax,.MathJax_Display,.MathJax_SVG,.MathJax_CHTML,.math-inline,.math-block,[hidden],[inert],[aria-hidden="true"],[contenteditable]:not([contenteditable="false"]),[translate="no"],.notranslate,[data-local-translate],.ytp-caption-window-container,${AD_SELECTOR}`;
  function isAd(element) {
    return element.closest(AD_SELECTOR) !== null;
  }
  function isExcluded(element) {
    return element.closest(EXCLUDED) !== null;
  }
  function sourceNodes(element) {
    const nodes = [];
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, { acceptNode(node) {
      const parent = node.parentElement;
      return parent && !isExcluded(parent) && node.textContent?.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    } });
    for (let node = walker.nextNode(); node; node = walker.nextNode())
      if (node instanceof Text)
        nodes.push({ node, original: node.data, written: null });
    return nodes;
  }
  function normalizedText(nodes) {
    return nodes.map((n) => n.original).join(" ").replace(/\s+/g, " ").trim();
  }
  function compactTranslation(element, text) {
    return text.length <= 80 && (standaloneLabel(element) || element.matches("h1,h2,h3,h4,h5,h6,th,dt,summary") || element.closest('nav,header,aside,[role="navigation"],[role="tablist"],td,th') !== null || ["flex", "inline-flex", "grid", "inline-grid"].includes(getComputedStyle(element).display));
  }
  function candidate(element) {
    if (isExcluded(element) || element.hidden || element.getAttribute("aria-hidden") === "true")
      return false;
    if (element.matches(LABEL_SELECTOR) && !standaloneLabel(element)) return false;
    const labelOwner = element.parentElement?.closest(LABEL_SELECTOR);
    if (labelOwner && standaloneLabel(labelOwner)) return false;
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden")
      return false;
    if (!standaloneLabel(element) && Array.from(element.querySelectorAll(BLOCK_SELECTOR)).some((child) => !isExcluded(child) && (!child.matches(LABEL_SELECTOR) || standaloneLabel(child))))
      return false;
    const text = normalizedText(sourceNodes(element));
    if (/^[\w.@/-]+$/.test(text) && (/[._/@-]/.test(text) || !/[a-zA-Z]{2}/.test(text)))
      return false;
    return text.length >= 2 && /[\p{L}\p{N}]/u.test(text);
  }
  function collectBlocks(root) {
    const elements = [];
    if (root instanceof HTMLElement && root.matches(BLOCK_SELECTOR) && candidate(root))
      elements.push(root);
    for (const node of root.querySelectorAll(BLOCK_SELECTOR))
      if (node instanceof HTMLElement && candidate(node))
        elements.push(node);
    return elements;
  }
  function changed(nodes) {
    return nodes.some((n) => !n.node.isConnected || n.node.data !== (n.written ?? n.original));
  }
  function restoreText(nodes) {
    for (const n of nodes) {
      if (n.written !== null && n.node.data === n.written)
        n.node.data = n.original;
      n.written = null;
    }
  }
  function replaceText(nodes, translation) {
    nodes.forEach((n, index) => {
      n.written = index === 0 ? translation : "";
      n.node.data = n.written;
    });
  }
  function splitText(text, max = 6e3) {
    const chunks = [];
    let rest = text;
    while (rest.length > max) {
      let cut = rest.lastIndexOf(" ", max);
      if (cut < max / 2)
        cut = max;
      if (/[\uD800-\uDBFF]/.test(rest.charAt(cut - 1)))
        cut--;
      chunks.push(rest.slice(0, cut));
      rest = rest.slice(cut).trimStart();
    }
    if (rest)
      chunks.push(rest);
    return chunks;
  }

  // src/content/images.ts
  init_settings();

  // src/content/interaction.ts
  function translationDirection(language) {
    const subtags = language.toLowerCase().split("-");
    if (subtags.includes("latn"))
      return "ltr";
    if (subtags.includes("arab") || subtags.includes("hebr"))
      return "rtl";
    return ["ar", "arc", "dv", "he", "ckb", "fa", "ur", "ug"].includes(subtags[0] ?? "") ? "rtl" : "ltr";
  }

  // src/content/images.ts
  var services = {
    translate: async (data) => imageResultSchema.parse(await rpc({ kind: "image.translate", data })),
    read: async (url) => {
      const data = await rpc({ kind: "image.read", url });
      if (typeof data !== "string") throw new Error("\u5716\u7247\u8B80\u53D6\u5931\u6557\u3002");
      return data;
    }
  };
  var ImageTranslator = class {
    constructor(settings, api = services) {
      this.settings = settings;
      this.api = api;
    }
    settings;
    api;
    states = /* @__PURE__ */ new Map();
    visible = /* @__PURE__ */ new Set();
    observer = null;
    mutations = null;
    running = false;
    epoch = 0;
    timer = null;
    frame = null;
    start() {
      if (this.observer) return;
      this.observer = new IntersectionObserver((entries) => {
        for (const entry of entries) if (entry.target instanceof HTMLImageElement) {
          if (entry.isIntersecting) this.visible.add(entry.target);
          else {
            this.visible.delete(entry.target);
            const state = this.states.get(entry.target);
            state?.host?.remove();
            if (state) {
              state.host = null;
              state.renderedKey = "";
              if (this.visibleTiles(state).length === 0) state.decoded = null;
            }
          }
        }
        this.schedule();
      });
      this.mutations = new MutationObserver((records) => {
        const changed2 = records.flatMap((record) => Array.from(record.addedNodes).concat(Array.from(record.removedNodes))).filter((node) => node instanceof Element && !node.closest(`[${OWN_ATTRIBUTE}]`));
        if (records.some((record) => record.type === "attributes" && record.target instanceof HTMLImageElement) || changed2.some((node) => node.matches("img") || node.querySelector("img"))) this.scan();
        else if (changed2.some((node) => node.matches("video") || node.querySelector("video"))) this.schedule();
      });
      this.mutations.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"] });
      window.addEventListener("scroll", this.onViewportChange, true);
      window.addEventListener("resize", this.onViewportChange);
      document.addEventListener("load", this.loaded, true);
      this.scan();
    }
    allowed() {
      return this.settings().images && sitePolicy(location.hostname, this.settings()) !== "blocked";
    }
    loaded = (event) => {
      if (event.target instanceof HTMLImageElement) this.scan();
    };
    scan() {
      for (const [image, state] of this.states) if (!image.isConnected || state.source !== image.currentSrc) {
        state.host?.remove();
        this.observer?.unobserve(image);
        this.visible.delete(image);
        this.states.delete(image);
      }
      for (const image of document.images) {
        if (this.states.has(image) || isExcluded(image) || image.closest('nav,header,[role="navigation"],a[href*="/watch"],a[href*="youtu.be"]')) continue;
        this.states.set(image, { image, source: image.currentSrc, tiles: /* @__PURE__ */ new Map(), decoded: null, host: null, original: false, revision: 0, renderedKey: "" });
        this.observer?.observe(image);
      }
      this.schedule();
    }
    onViewportChange = () => {
      if (!this.observer) return;
      if (this.frame === null) {
        this.frame = window.requestAnimationFrame(() => {
          this.frame = null;
          for (const image of this.visible) {
            const state = this.states.get(image);
            if (state) this.render(state);
          }
        });
      }
      this.schedule();
    };
    schedule = () => {
      if (!this.observer || this.timer !== null) return;
      this.timer = window.setTimeout(() => {
        this.timer = null;
        for (const image of this.visible) {
          const state = this.states.get(image);
          if (state) this.render(state);
        }
        void this.flush();
      }, 120);
    };
    eligible(state) {
      const image = state.image;
      const rect = image.getBoundingClientRect();
      return image.isConnected && image.complete && image.naturalWidth >= 160 && image.naturalHeight >= 80 && rect.width >= 140 && rect.height >= 80 && rect.bottom > 0 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && getComputedStyle(image).visibility !== "hidden";
    }
    visibleTiles(state) {
      const image = state.image;
      const rect = image.getBoundingClientRect();
      const height = Math.min(1800, Math.round(image.naturalWidth * 1.5));
      const start = Math.max(0, -rect.top / rect.height * image.naturalHeight);
      const end = Math.min(image.naturalHeight, (innerHeight - rect.top) / rect.height * image.naturalHeight);
      const tiles = [];
      for (let y = Math.floor(start / height) * height; y < end; y += height) if (!state.tiles.has(y)) tiles.push(y);
      return tiles;
    }
    async pixels(state, y, height) {
      const image = state.image;
      const canvas = document.createElement("canvas");
      const scale = Math.min(1, 1600 / image.naturalWidth, 1800 / height);
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(height * scale));
      const context = canvas.getContext("2d");
      if (!context) throw new Error("\u7121\u6CD5\u8B80\u53D6\u5716\u7247\u50CF\u7D20\u3002");
      const encode = (source) => {
        context.fillStyle = "#fff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(source, 0, y, source.naturalWidth, height, 0, 0, canvas.width, canvas.height);
        const data = canvas.toDataURL("image/jpeg", 0.92);
        if (data.length > 45e5) throw new Error("\u5716\u7247\u5340\u584A\u904E\u5927\u3002");
        return data;
      };
      try {
        return { data: encode(image), canvas };
      } catch {
        state.decoded ??= this.api.read(state.source).then(async (data) => {
          const decoded2 = new Image();
          decoded2.src = data;
          await decoded2.decode();
          return decoded2;
        });
        const decoded = await state.decoded;
        canvas.width = canvas.width;
        return { data: encode(decoded), canvas };
      }
    }
    async flush() {
      if (this.running || !this.allowed() || !this.observer) return;
      if (document.querySelector("video")) return;
      this.running = true;
      const epoch = this.epoch;
      try {
        for (const image of this.visible) {
          const state = this.states.get(image);
          if (!state || !this.eligible(state)) continue;
          for (const y of this.visibleTiles(state)) {
            if (epoch !== this.epoch || !this.observer || !this.allowed() || !this.visible.has(image) || !this.eligible(state) || state !== this.states.get(image) || document.querySelector("video")) return;
            if (!this.visibleTiles(state).includes(y)) continue;
            const height = Math.min(1800, Math.round(image.naturalWidth * 1.5), image.naturalHeight - y);
            state.tiles.set(y, { kind: "pending" });
            state.revision++;
            this.render(state);
            try {
              const { data, canvas } = await this.pixels(state, y, height);
              if (epoch !== this.epoch || state !== this.states.get(image) || !this.visible.has(image) || document.querySelector("video")) {
                state.tiles.delete(y);
                state.revision++;
                return;
              }
              const result = await this.api.translate(data);
              if (epoch !== this.epoch || state !== this.states.get(image)) return;
              const palettes = result.regions.map((region) => {
                try {
                  const [top, left, bottom, right] = region.box;
                  const sample = document.createElement("canvas");
                  sample.width = 32;
                  sample.height = 32;
                  const context = sample.getContext("2d");
                  if (!context) return fallbackPalette;
                  context.drawImage(canvas, left / 1e3 * canvas.width, top / 1e3 * canvas.height, (right - left) / 1e3 * canvas.width, (bottom - top) / 1e3 * canvas.height, 0, 0, 32, 32);
                  return imagePalette(context.getImageData(0, 0, 32, 32).data);
                } catch {
                  return fallbackPalette;
                }
              });
              state.tiles.set(y, { kind: "ready", height, result, palettes });
              state.revision++;
            } catch (error) {
              if (epoch !== this.epoch || state !== this.states.get(image)) return;
              state.tiles.set(y, { kind: "error", message: error instanceof Error ? error.message : "\u5716\u7247\u7FFB\u8B6F\u5931\u6557\u3002" });
              state.revision++;
            }
            this.render(state);
          }
        }
      } finally {
        this.running = false;
        if (this.observer && !document.querySelector("video") && Array.from(this.visible).some((image) => {
          const state = this.states.get(image);
          return state && this.eligible(state) && this.visibleTiles(state).length > 0;
        })) this.schedule();
      }
    }
    render(state) {
      if (document.querySelector("video") || !state.tiles.size || !this.visible.has(state.image) || !this.eligible(state) || !this.allowed()) {
        state.host?.remove();
        state.host = null;
        state.renderedKey = "";
        return;
      }
      const rect = state.image.getBoundingClientRect();
      if (!state.host) {
        state.host = document.createElement("div");
        state.host.setAttribute(OWN_ATTRIBUTE, "image");
        document.documentElement.append(state.host);
        state.renderedKey = "";
      }
      Object.assign(state.host.style, { position: "fixed", left: rect.left + "px", top: rect.top + "px", width: rect.width + "px", height: rect.height + "px", pointerEvents: "none", zIndex: "2147483645", overflow: "hidden" });
      const key = `${state.revision}:${state.original}:${Math.round(rect.width)}:${Math.round(rect.height)}:${this.settings().target}`;
      const shadow = state.host.shadowRoot ?? state.host.attachShadow({ mode: "open" });
      if (state.renderedKey === key) {
        const controls2 = shadow.querySelector(".controls");
        if (controls2) controls2.style.top = Math.max(4, -rect.top + 4) + "px";
        return;
      }
      state.renderedKey = key;
      const style = document.createElement("style");
      style.textContent = ":host{all:initial}.region{box-sizing:border-box;position:absolute;display:flex;align-items:center;justify-content:center;text-align:center;white-space:pre-wrap;overflow:hidden;overflow-wrap:anywhere;word-break:break-all;background:#fff;color:#191919;padding:2px;border-radius:3px;font-family:system-ui,sans-serif;line-height:1.2}.controls{position:absolute;left:4px;display:flex;gap:4px;max-width:calc(100% - 8px);pointer-events:auto}button{font:12px/1.5 system-ui,sans-serif;padding:4px 7px;background:#211e25eF;border:1px solid #98879f;color:white;border-radius:6px;cursor:pointer;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}button:focus-visible{outline:2px solid #dba4c3}";
      const nodes = [style];
      const measureContext = document.createElement("canvas").getContext("2d");
      let regions = 0;
      for (const [y, tile] of state.tiles) if (tile.kind === "ready") for (const [index, region] of tile.result.regions.entries()) {
        regions++;
        if (state.original) continue;
        const [top, left, bottom, right] = region.box;
        const span = document.createElement("span");
        span.className = "region";
        span.textContent = region.translation;
        span.lang = this.settings().target;
        span.dir = translationDirection(this.settings().target);
        const width = (right - left) / 1e3 * rect.width;
        const height = (bottom - top) / 1e3 * tile.height / state.image.naturalHeight * rect.height;
        const palette = tile.palettes[index] ?? fallbackPalette;
        const fontSize = imageFontSize(region.translation, width, height, (text, size) => {
          if (!measureContext) return Array.from(text).length * size;
          measureContext.font = `${size}px system-ui,sans-serif`;
          return measureContext.measureText(text).width;
        });
        Object.assign(span.style, { left: left / 10 + "%", top: (y + top / 1e3 * tile.height) / state.image.naturalHeight * 100 + "%", width: (right - left) / 10 + "%", height: height + "px", fontSize: fontSize + "px", background: palette.background, color: palette.foreground });
        span.setAttribute("aria-label", region.source + "\uFF1A" + region.translation);
        nodes.push(span);
      }
      const controls = document.createElement("div");
      controls.className = "controls";
      controls.style.top = Math.max(4, -rect.top + 4) + "px";
      const error = Array.from(state.tiles.values()).find((tile) => tile.kind === "error");
      const pending = Array.from(state.tiles.values()).some((tile) => tile.kind === "pending");
      if (!error && !pending && !regions) {
        state.host.remove();
        state.host = null;
        state.renderedKey = "";
        return;
      }
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = error ? "\u5716\u7247\u7FFB\u8B6F\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66" : pending ? "\u5716\u7247\u7FFB\u8B6F\u4E2D\u2026" : regions ? state.original ? "\u986F\u793A\u8B6F\u6587" : "\u986F\u793A\u539F\u5716" : "\u672A\u8FA8\u8B58\u5230\u6587\u5B57";
      if (error?.kind === "error") toggle.title = error.message;
      toggle.onclick = () => {
        if (error) {
          for (const [y, tile] of state.tiles) if (tile.kind === "error") state.tiles.delete(y);
          state.decoded = null;
          state.revision++;
          this.schedule();
        } else {
          state.original = !state.original;
          this.render(state);
        }
      };
      controls.append(toggle);
      nodes.push(controls);
      shadow.replaceChildren(...nodes);
    }
    stop() {
      this.epoch++;
      this.observer?.disconnect();
      this.observer = null;
      this.mutations?.disconnect();
      this.mutations = null;
      if (this.timer !== null) clearTimeout(this.timer);
      this.timer = null;
      if (this.frame !== null) cancelAnimationFrame(this.frame);
      this.frame = null;
      for (const state of this.states.values()) state.host?.remove();
      this.states.clear();
      this.visible.clear();
      window.removeEventListener("scroll", this.onViewportChange, true);
      window.removeEventListener("resize", this.onViewportChange);
      document.removeEventListener("load", this.loaded, true);
    }
  };

  // src/content/lookup.ts
  init_messages();
  init_vocabulary();
  init_settings();

  // src/ui/word-card.ts
  function speakWord(term, language) {
    if (!("speechSynthesis" in window)) return;
    const utterance = new SpeechSynthesisUtterance(term);
    utterance.lang = language;
    speechSynthesis.cancel();
    speechSynthesis.speak(utterance);
  }
  function wordDetails(term, entry, target) {
    const content = document.createElement("div");
    content.className = "word-details";
    content.lang = target;
    content.dir = translationDirection(target);
    const pronunciation = document.createElement("p");
    pronunciation.className = "pronunciation";
    pronunciation.textContent = entry.pronunciation;
    const audio = document.createElement("button");
    audio.type = "button";
    audio.textContent = "\u6717\u8B80";
    audio.setAttribute("aria-label", `\u6717\u8B80 ${term}`);
    audio.onclick = () => speakWord(term, entry.sourceLanguage);
    pronunciation.append(" ", audio);
    content.append(pronunciation);
    for (const sense of entry.senses) {
      const section = document.createElement("section");
      section.className = "sense";
      const meaning = document.createElement("p");
      const pos = document.createElement("span");
      pos.className = "part-of-speech";
      pos.textContent = sense.partOfSpeech;
      meaning.append(pos, " ", sense.meaning);
      const example = document.createElement("p");
      example.className = "example";
      example.lang = entry.sourceLanguage;
      example.dir = translationDirection(entry.sourceLanguage);
      example.textContent = sense.example;
      const translation = document.createElement("p");
      translation.className = "example-translation";
      translation.textContent = sense.translation;
      section.append(meaning, example, translation);
      content.append(section);
    }
    const context = document.createElement("section");
    context.className = "contextual-meaning";
    const label = document.createElement("strong");
    label.textContent = "\u5728\u9019\u88E1\u7684\u610F\u601D";
    const explanation = document.createElement("p");
    explanation.textContent = entry.contextualMeaning;
    context.append(label, explanation);
    content.append(context);
    return content;
  }
  var wordCardStyles = `
.word-details{line-height:1.7;overflow-wrap:anywhere}.word-details p{margin:8px 0}
.pronunciation,.part-of-speech,.example-translation{color:var(--muted,#746c7e)}
.sense{margin:20px 0}.part-of-speech{font-size:13px}.example,.example-translation{padding-inline-start:16px;border-inline-start:2px solid var(--border,#e9e4ed)}
.contextual-meaning{padding:16px;background:var(--soft,#f8f4f8);border-radius:12px;margin:18px 0}
`;

  // src/content/lookup.ts
  var services2 = {
    lookup: async (input) => dictionarySchema.parse(await rpc({ kind: "dictionary.lookup", ...input })),
    save: (draft) => rpc({ kind: "vocabulary.save", draft }),
    open: () => rpc({ kind: "vocabulary.open" })
  };
  function isPhrase(text) {
    return text.length > 0 && text.length <= 160 && text.trim().split(/\s+/).length <= 12;
  }
  function lookupContext(element, term) {
    const block = element.closest("p,li,td,th,blockquote,article") ?? element;
    const text = block instanceof HTMLElement ? normalizedText(sourceNodes(block)) : block.textContent ?? "";
    const index = text.toLocaleLowerCase().indexOf(term.toLocaleLowerCase());
    return text.slice(Math.max(0, index - 500), Math.max(0, index - 500) + 1600);
  }
  function wordAtPoint(x, y) {
    const range = document.caretRangeFromPoint(x, y);
    if (!range || !(range.startContainer instanceof Text)) return null;
    const node = range.startContainer;
    const parent = node.parentElement;
    if (!parent || isExcluded(parent)) return null;
    const offset = range.startOffset;
    for (const match of node.data.matchAll(/[\p{L}\p{M}]+(?:['’\-][\p{L}\p{M}]+)*/gu)) {
      const start = match.index;
      if (offset < start || offset > start + match[0].length) continue;
      range.setStart(node, start);
      range.setEnd(node, start + match[0].length);
      const rect = Array.from(range.getClientRects()).find((r) => x >= r.left && x <= r.right && y >= r.top && y <= r.bottom);
      if (!rect || !isPhrase(match[0])) return null;
      return { input: { term: match[0], context: lookupContext(parent, match[0]) }, anchor: rect, key: node, offset: start };
    }
    return null;
  }
  var WordLookup = class {
    constructor(settings, api = services2) {
      this.settings = settings;
      this.api = api;
      document.addEventListener("pointermove", this.move, true);
      document.addEventListener("pointerdown", this.outside, true);
      document.addEventListener("keydown", this.key, true);
      document.addEventListener("keyup", this.keyUp, true);
      document.addEventListener("pointerout", this.leave, true);
      document.addEventListener("selectionchange", this.selectionChanged);
      window.addEventListener("scroll", this.resetPointer, true);
      window.addEventListener("blur", this.resetPointer);
    }
    settings;
    api;
    host = null;
    timer = null;
    preview = null;
    sequence = 0;
    hovered = null;
    lastShown = "";
    pointer = null;
    controlHeld = false;
    controlChord = false;
    allowed() {
      return sitePolicy(location.hostname, this.settings()) !== "blocked";
    }
    cancel = () => {
      if (this.timer !== null) clearTimeout(this.timer);
      this.timer = null;
      this.hovered = null;
    };
    resetPointer = () => {
      this.cancel();
      this.clearPreview();
      this.pointer = null;
      this.controlHeld = false;
      this.controlChord = false;
    };
    selectionChanged = () => {
      this.cancel();
      this.clearPreview();
    };
    clearPreview() {
      this.preview?.remove();
      this.preview = null;
    }
    leave = (event) => {
      if (!event.relatedTarget) this.resetPointer();
    };
    key = (event) => {
      if (event.key === "Control" && !event.repeat && !event.altKey && !event.metaKey && !event.shiftKey) {
        this.controlHeld = true;
        this.controlChord = false;
        this.scheduleHover();
      } else if (event.key !== "Control") {
        if (event.ctrlKey) this.controlChord = true;
        this.controlHeld = false;
        this.cancel();
        if (event.key === "Escape") this.close();
      }
    };
    keyUp = (event) => {
      if (event.key === "Control") {
        this.controlHeld = false;
        this.controlChord = false;
        this.cancel();
      }
    };
    outside = (event) => {
      if (this.host && event.composedPath().includes(this.host) || this.preview && event.composedPath().includes(this.preview)) return;
      this.close();
    };
    move = (event) => {
      if (this.host && event.composedPath().includes(this.host) || this.preview && event.composedPath().includes(this.preview)) {
        this.cancel();
        this.pointer = null;
        return;
      }
      if (event.pointerType === "touch") {
        this.resetPointer();
        return;
      }
      this.pointer = { x: event.clientX, y: event.clientY };
      if (!event.ctrlKey || this.controlChord || event.buttons || event.altKey || event.metaKey || event.shiftKey) {
        this.controlHeld = false;
        this.cancel();
        return;
      }
      this.controlHeld = true;
      this.scheduleHover();
    };
    scheduleHover() {
      if (!this.pointer || !this.controlHeld || !this.settings().hover || !this.allowed()) {
        this.cancel();
        return;
      }
      const hit = this.hoverTarget();
      if (!hit) {
        this.cancel();
        return;
      }
      if (this.hovered?.node === hit.key && this.hovered.offset === hit.offset) return;
      this.cancel();
      this.hovered = { node: hit.key, offset: hit.offset };
      this.timer = window.setTimeout(() => {
        this.timer = null;
        const current = this.pointer && this.controlHeld ? this.hoverTarget() : null;
        if (current?.key === hit.key && current.offset === hit.offset && current.input.term === hit.input.term)
          this.showPreview(current.input, current.anchor);
      }, 700);
    }
    hoverTarget() {
      if (!this.pointer) return null;
      const selection = window.getSelection();
      const term = selection?.toString().trim() ?? "";
      if (!term) return wordAtPoint(this.pointer.x, this.pointer.y);
      if (!selection?.rangeCount || !isPhrase(term)) return null;
      const range = selection.getRangeAt(0);
      const parent = range.startContainer instanceof Element ? range.startContainer : range.startContainer.parentElement;
      if (!parent || isExcluded(parent)) return null;
      const point = this.pointer;
      const rect = Array.from(range.getClientRects()).find((r) => point.x >= r.left && point.x <= r.right && point.y >= r.top && point.y <= r.bottom);
      return rect ? { input: { term, context: lookupContext(parent, term) }, anchor: rect, key: range.startContainer, offset: range.startOffset } : null;
    }
    showPreview(input, anchor) {
      this.clearPreview();
      const host = document.createElement("div");
      host.setAttribute(OWN_ATTRIBUTE, "lookup-action");
      Object.assign(host.style, { position: "fixed", zIndex: "2147483647", left: Math.max(6, Math.min(anchor.left, innerWidth - 34)) + "px", top: Math.max(6, Math.min(anchor.bottom + 5, innerHeight - 34)) + "px" });
      const shadow = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = ":host{all:initial}button{box-sizing:border-box;width:28px;height:28px;padding:0;border:1px solid #d5d9e2;border-radius:5px;background:#fff;color:#4285f4;box-shadow:0 2px 8px #0002;cursor:pointer;font:bold 17px/1 system-ui;position:relative}small{font-size:10px;position:absolute;right:2px;bottom:2px;color:#687388;background:#fff}button:focus-visible{outline:2px solid #4285f4;outline-offset:2px}@media(prefers-color-scheme:dark){button{background:#282b32;border-color:#565a65;color:#a7c5ff}small{background:#282b32;color:#c1c8d5}}";
      const button = document.createElement("button");
      button.type = "button";
      button.title = "\u67E5\u8A62\u55AE\u5B57\uFF0F\u7247\u8A9E";
      button.setAttribute("aria-label", "\u67E5\u8A62\u55AE\u5B57\uFF0F\u7247\u8A9E");
      button.textContent = "\u6587";
      const latin = document.createElement("small");
      latin.textContent = "A";
      button.append(latin);
      button.onpointerdown = (event) => event.preventDefault();
      button.onclick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        void this.show(input, anchor);
      };
      shadow.append(style, button);
      document.documentElement.append(host);
      this.preview = host;
    }
    async show(input, anchor) {
      if (!this.allowed()) return;
      const identity = JSON.stringify([input, this.settings().target]);
      if (this.host?.isConnected && this.lastShown === identity) return;
      this.close();
      this.lastShown = identity;
      const sequence = this.sequence;
      const target = this.settings().target;
      const host = document.createElement("div");
      host.setAttribute(OWN_ATTRIBUTE, "lookup");
      const width = Math.min(460, window.innerWidth - 24);
      const left = Math.max(12, Math.min(anchor?.left ?? window.innerWidth - width - 20, window.innerWidth - width - 12));
      Object.assign(host.style, { position: "fixed", zIndex: "2147483647", left: left + "px", top: "12px", width: width + "px" });
      const shadow = host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = `:host{all:initial;color-scheme:light dark;--muted:#81798a;--border:#e8e0eb;--soft:#f8f4f8}*{box-sizing:border-box}.box{font:15px/1.65 system-ui,sans-serif;color:#302a39;background:#fff;border:1px solid var(--border);border-radius:16px;box-shadow:0 14px 60px #0003;padding:20px;max-height:min(620px,calc(100vh - 24px));overflow:auto}header,footer{display:flex;align-items:center;justify-content:space-between;gap:10px}header{margin-bottom:18px;font-size:12px;color:var(--muted)}h2{font-size:25px;line-height:1.3;margin:10px 0;overflow-wrap:anywhere}button{font:inherit;color:#a83f6d;background:var(--soft);border:1px solid var(--border);border-radius:8px;padding:6px 10px;cursor:pointer}button:disabled{opacity:.6;cursor:default}button:focus-visible{outline:2px solid #bb527c;outline-offset:3px}footer{margin-top:20px;flex-wrap:wrap}footer button:first-child{background:#b94d7b;color:white;border-color:transparent}.status{color:var(--muted);font-size:13px}p{white-space:pre-wrap}${wordCardStyles}@media(prefers-color-scheme:dark){:host{--muted:#b3abbc;--border:#433b49;--soft:#28232d}.box{background:#211e25;color:#eee8f1}button{color:#efa6c7}}`;
      const box = document.createElement("section");
      box.className = "box";
      box.setAttribute("role", "dialog");
      box.setAttribute("aria-label", `\u67E5\u8A5E\uFF1A${input.term}`);
      const header = document.createElement("header");
      header.textContent = "\u96D9\u8A9E\u95B1\u8B80 \xB7 \u67E5\u8A5E";
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "\u95DC\u9589";
      close.onclick = () => this.close();
      header.append(close);
      const title = document.createElement("h2");
      title.textContent = input.term;
      const body = document.createElement("div");
      const status = document.createElement("p");
      status.className = "status";
      status.setAttribute("role", "status");
      status.textContent = "\u6B63\u5728\u67E5\u8A62\u8A5E\u610F\u8207\u4F8B\u53E5\u2026";
      const footer = document.createElement("footer");
      const save = document.createElement("button");
      save.type = "button";
      save.textContent = "\u52A0\u5165\u55AE\u5B57\u672C";
      save.disabled = true;
      const open = document.createElement("button");
      open.type = "button";
      open.textContent = "\u958B\u555F\u55AE\u5B57\u672C";
      open.onclick = () => {
        void this.api.open().catch(() => {
          status.textContent = "\u7121\u6CD5\u958B\u555F\u55AE\u5B57\u672C\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u9801\u9762\u3002";
        });
      };
      footer.append(save, open);
      box.append(header, title, body, status, footer);
      shadow.append(style, box);
      document.documentElement.append(host);
      this.host = host;
      const position = () => {
        const height = box.getBoundingClientRect().height;
        const below = (anchor?.bottom ?? 12) + 10;
        const top = below + height <= innerHeight - 12 ? below : Math.max(12, (anchor?.top ?? innerHeight) - height - 10);
        host.style.top = top + "px";
      };
      position();
      const load = async () => {
        status.textContent = "\u6B63\u5728\u67E5\u8A62\u8A5E\u610F\u8207\u4F8B\u53E5\u2026";
        try {
          const entry = await this.api.lookup(input);
          if (sequence !== this.sequence) return;
          body.replaceChildren(wordDetails(input.term, entry, target));
          status.textContent = "AI \u8A5E\u610F\u8207\u4F8B\u53E5\uFF0C\u4F9D\u76EE\u524D\u4E0A\u4E0B\u6587\u89E3\u91CB\u3002";
          save.disabled = false;
          save.onclick = () => {
            save.disabled = true;
            void this.api.save({ ...input, target, entry }).then(() => {
              if (sequence !== this.sequence) return;
              save.textContent = "\u5DF2\u52A0\u5165\u55AE\u5B57\u672C";
              status.textContent = "\u5DF2\u5132\u5B58\u5728\u9019\u53F0\u88DD\u7F6E\uFF0C\u53EF\u5230\u55AE\u5B57\u672C\u8907\u7FD2\u3002";
            }).catch(() => {
              if (sequence === this.sequence) {
                save.disabled = false;
                status.textContent = "\u5132\u5B58\u5931\u6557\uFF0C\u8ACB\u518D\u8A66\u4E00\u6B21\u3002";
              }
            });
          };
          position();
        } catch (error) {
          if (sequence !== this.sequence) return;
          status.textContent = error instanceof Error ? error.message : "\u67E5\u8A5E\u5931\u6557\uFF0C\u8ACB\u91CD\u8A66\u3002";
          const retry = document.createElement("button");
          retry.type = "button";
          retry.textContent = "\u91CD\u65B0\u67E5\u8A62";
          retry.onclick = () => {
            body.replaceChildren();
            void load();
          };
          body.replaceChildren(retry);
          position();
        }
      };
      await load();
    }
    close() {
      this.cancel();
      this.clearPreview();
      this.sequence++;
      this.host?.remove();
      this.host = null;
      this.lastShown = "";
    }
    dispose() {
      this.close();
      document.removeEventListener("pointermove", this.move, true);
      document.removeEventListener("pointerdown", this.outside, true);
      document.removeEventListener("keydown", this.key, true);
      document.removeEventListener("keyup", this.keyUp, true);
      document.removeEventListener("pointerout", this.leave, true);
      document.removeEventListener("selectionchange", this.selectionChanged);
      window.removeEventListener("scroll", this.resetPointer, true);
      window.removeEventListener("blur", this.resetPointer);
    }
  };

  // src/content/controller.ts
  init_messages();

  // src/core/styles.ts
  function translationStyle(style) {
    const common = { display: "block", color: "inherit", background: "transparent", fontSize: style.fontSize + "%", borderInlineStart: "none", padding: "0", margin: "8px 0", lineHeight: "1.65", whiteSpace: "pre-wrap", overflowWrap: "anywhere", textAlign: "start", textDecoration: "none" };
    switch (style.theme) {
      case "plain":
        return common;
      case "highlight":
        return { ...common, color: style.color, background: style.background, borderInlineStart: style.border ? "2px solid " + style.color : "none", padding: "0.25em 0.55em" };
      case "gray":
        return { ...common, color: style.color, opacity: "0.72" };
      case "blockquote":
        return { ...common, color: style.color, borderInlineStart: "3px solid " + style.color, paddingInlineStart: "0.8em" };
      case "underline":
      case "dotted":
      case "dashed":
      case "wavy":
        return { ...common, textDecorationLine: "underline", textDecorationStyle: style.theme === "underline" ? "solid" : style.theme, textDecorationColor: style.color, textUnderlineOffset: "0.3em" };
      case "mask":
        return { ...common, background: style.background, cursor: "help" };
      default: {
        const exhaustive = style.theme;
        return exhaustive;
      }
    }
  }
  var maskStyles = '[data-local-translate="result"][data-theme="mask"]:not(:hover):not(:focus){color:transparent!important;user-select:none}[data-local-translate="result"][data-theme="mask"]:focus{outline:2px solid currentColor;outline-offset:2px}';
  function applyTranslationStyle(element, style) {
    element.removeAttribute("style");
    Object.assign(element.style, translationStyle(style));
    element.dataset.theme = style.theme;
    if (style.theme === "mask") {
      element.tabIndex = 0;
      element.title = "\u6ED1\u9F20\u505C\u7559\u6216\u6309 Tab \u805A\u7126\u986F\u793A\u8B6F\u6587";
    } else {
      element.removeAttribute("tabindex");
      element.removeAttribute("title");
    }
  }

  // src/content/controller.ts
  init_settings();

  // src/content/panel.ts
  var TranslationPanel = class {
    host = null;
    output = null;
    sequence = 0;
    ensure() {
      if (this.host?.isConnected)
        return this.host;
      const host = document.createElement("div");
      host.setAttribute(OWN_ATTRIBUTE, "panel");
      Object.assign(host.style, { position: "fixed", zIndex: "2147483647", right: "20px", bottom: "24px", maxWidth: "min(380px, calc(100vw - 32px))" });
      const shadow = host.attachShadow({ mode: "closed" });
      const style = document.createElement("style");
      style.textContent = ":host{all:initial}.box{font:14px/1.65 system-ui,sans-serif;color:#292735;background:white;border:1px solid #e7dce2;border-radius:14px;box-shadow:0 8px 40px #30203026;padding:16px;min-width:240px;max-height:60vh;overflow:auto}header{display:flex;justify-content:space-between;align-items:center;color:#b73967;font-weight:650}button{border:0;background:#f8edf1;border-radius:6px;padding:4px 8px;color:#73354d;cursor:pointer}p{white-space:pre-wrap;overflow-wrap:anywhere;margin:10px 0 0}";
      const box = document.createElement("div");
      box.className = "box";
      box.setAttribute("role", "status");
      const header = document.createElement("header");
      header.textContent = "\u672C\u6A5F\u96D9\u8A9E\u7FFB\u8B6F";
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "\u95DC\u9589";
      close.onclick = () => this.close();
      header.append(close);
      this.output = document.createElement("p");
      box.append(header, this.output);
      shadow.append(style, box);
      document.documentElement.append(host);
      this.host = host;
      return host;
    }
    show(text) {
      this.ensure();
      if (this.output)
        this.output.textContent = text;
    }
    close() {
      this.sequence++;
      this.host?.remove();
      this.host = null;
      this.output = null;
    }
    async translate(text, run) {
      const sequence = ++this.sequence;
      this.show("\u7FFB\u8B6F\u4E2D\u2026");
      try {
        const results = await run([text]);
        if (sequence === this.sequence)
          this.show(results[0] ?? "\u672A\u6536\u5230\u7FFB\u8B6F\u7D50\u679C");
      } catch (error) {
        if (sequence === this.sequence)
          this.show(error instanceof Error ? error.message : "\u7FFB\u8B6F\u5931\u6557\uFF0C\u8ACB\u6AA2\u67E5\u8A2D\u5B9A\u3002");
      }
    }
  };

  // src/content/subtitle-controls.ts
  var SubtitleControls = class {
    enabled = true;
    statusNode = null;
    statusText = "\u5B57\u5E55\u7FFB\u8B6F\u5DF2\u555F\u7528";
    setStatus(text) {
      this.statusText = text;
      if (this.statusNode && this.statusNode.textContent !== text) this.statusNode.textContent = text;
      const button = this.host?.querySelector("button");
      if (button) button.title = "\u4F34\u8B80\u5B57\u5E55\u8A2D\u5B9A\uFF1A" + text;
    }
    host = null;
    panel = null;
    listeners = null;
    mode = "bilingual";
    sourceSize = 100;
    sourceColor = "#ffffff";
    weight = 400;
    sourceWeight = 400;
    font = "sans-serif";
    sourceFont = "sans-serif";
    sheet = null;
    size = 100;
    color = "#ffffff";
    background = "#000000";
    opacity = 75;
    position = "below";
    attach() {
      this.refresh();
      const bar = document.querySelector(".ytp-right-controls");
      if (!bar || this.host?.isConnected)
        return;
      this.dispose();
      this.listeners = new AbortController();
      const host = document.createElement("span");
      host.dataset.localTranslate = "controls";
      this.host = host;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ytp-button";
      button.textContent = "\u8B6F";
      button.title = "\u4F34\u8B80\u5B57\u5E55\u8A2D\u5B9A";
      button.setAttribute("aria-label", button.title);
      button.setAttribute("aria-expanded", "false");
      const panel = document.createElement("div");
      this.panel = panel;
      panel.hidden = true;
      Object.assign(panel.style, { position: "absolute", right: "12px", bottom: "52px", width: "280px", maxWidth: "calc(100vw - 24px)", padding: "14px 16px", background: "rgba(20,20,20,.96)", color: "white", borderRadius: "14px", font: "14px/1.5 system-ui", zIndex: "100", maxHeight: "min(420px, calc(100vh - 120px))", overflowY: "auto" });
      panel.dataset.localTranslate = "controls";
      panel.setAttribute("role", "dialog");
      panel.setAttribute("aria-label", "\u5B57\u5E55\u5916\u89C0\u8207\u986F\u793A");
      const skin = document.createElement("style");
      skin.textContent = `[data-local-translate="controls"] [role="dialog"]{box-sizing:border-box;box-shadow:0 12px 40px #0008;border:1px solid #ffffff26;scrollbar-width:thin;color-scheme:dark;text-align:left;line-height:1.45!important}[data-local-translate="controls"] select{font:13px system-ui;color:#f5f5f5;background:#303035;border:1px solid #ffffff30;border-radius:8px;padding:5px 7px;max-width:135px}[data-local-translate="controls"] input{accent-color:#e5a2c3}[data-local-translate="controls"] input[type=color]{width:34px;height:26px;padding:2px;border:1px solid #ffffff40;border-radius:6px;background:transparent}[data-local-translate="controls"] button:focus-visible,[data-local-translate="controls"] input:focus-visible,[data-local-translate="controls"] select:focus-visible{outline:2px solid #e5a2c3;outline-offset:3px}[data-local-translate="controls"] input[type=checkbox]{width:18px;height:18px}`;
      host.append(skin);
      const heading = document.createElement("strong");
      heading.textContent = "\u5B57\u5E55\u8A2D\u5B9A";
      heading.style.fontSize = "16px";
      panel.append(heading);
      const help = document.createElement("p");
      help.textContent = "\u8ABF\u6574\u6B64\u9801\u9762\u7684\u5B57\u5E55\u986F\u793A\u8207\u5916\u89C0";
      Object.assign(help.style, { margin: "2px 0 8px", font: "12px system-ui", color: "#bdbdc8" });
      panel.append(help);
      this.statusNode = document.createElement("p");
      this.statusNode.setAttribute("role", "status");
      this.statusNode.style.cssText = "font:12px/1.4 system-ui;color:#e5b8cf;margin:6px 0";
      this.statusNode.textContent = this.statusText;
      panel.append(this.statusNode);
      const field = (label, input) => {
        const row = document.createElement("label");
        Object.assign(row.style, { display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px", marginTop: "8px" });
        row.append(document.createTextNode(label), input);
        panel.append(row);
      };
      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.checked = this.enabled;
      toggle.setAttribute("aria-label", "\u958B\u555F\u5B57\u5E55\u7FFB\u8B6F");
      toggle.onchange = () => {
        this.enabled = toggle.checked;
      };
      field("\u958B\u555F\u5B57\u5E55\u7FFB\u8B6F", toggle);
      for (const [label, key, values] of [["\u5B57\u5E55\u986F\u793A", "mode", [["bilingual", "\u96D9\u8A9E\u5B57\u5E55"], ["translated", "\u50C5\u8B6F\u6587"], ["original", "\u50C5\u539F\u6587"]]], ["\u8B6F\u6587\u5B57\u578B", "font", [["sans-serif", "\u7121\u896F\u7DDA"], ["serif", "\u896F\u7DDA"], ["monospace", "\u7B49\u5BEC"]]], ["\u539F\u6587\u5B57\u578B", "sourceFont", [["sans-serif", "\u7121\u896F\u7DDA"], ["serif", "\u896F\u7DDA"], ["monospace", "\u7B49\u5BEC"]]]]) {
        const select = document.createElement("select");
        select.setAttribute("aria-label", label);
        for (const [value, text] of values) {
          const option = document.createElement("option");
          option.value = value;
          option.textContent = text;
          select.append(option);
        }
        select.value = this[key];
        select.onchange = () => {
          this[key] = select.value;
        };
        field(label, select);
      }
      const position = document.createElement("select");
      position.setAttribute("aria-label", "\u8B6F\u6587\u4F4D\u7F6E");
      for (const [value, label] of [["below", "\u539F\u6587\u4E0B\u65B9"], ["above", "\u539F\u6587\u4E0A\u65B9"]]) {
        const option = document.createElement("option");
        option.value = value ?? "";
        option.textContent = label ?? "";
        position.append(option);
      }
      position.value = this.position;
      position.onchange = () => {
        this.position = position.value;
      };
      field("\u8B6F\u6587\u4F4D\u7F6E", position);
      for (const [label, key, min, max] of [["\u8B6F\u6587\u5B57\u578B\u5927\u5C0F", "size", 50, 200], ["\u80CC\u666F\u4E0D\u900F\u660E\u5EA6", "opacity", 0, 100], ["\u539F\u6587\u5B57\u578B\u5927\u5C0F", "sourceSize", 50, 200], ["\u8B6F\u6587\u7C97\u7D30", "weight", 100, 900], ["\u539F\u6587\u7C97\u7D30", "sourceWeight", 100, 900]]) {
        const input = document.createElement("input");
        input.type = "range";
        input.min = String(min);
        input.max = String(max);
        input.value = String(this[key]);
        input.style.width = "100px";
        const value = document.createElement("output");
        value.textContent = input.value + (key === "weight" || key === "sourceWeight" ? "" : "%");
        value.style.cssText = "font:12px system-ui;min-width:34px;text-align:right";
        input.oninput = () => {
          this[key] = Number(input.value);
          value.textContent = input.value + (key === "weight" || key === "sourceWeight" ? "" : "%");
        };
        input.setAttribute("aria-label", label);
        const group = document.createElement("span");
        group.style.cssText = "display:flex;align-items:center;gap:6px";
        group.append(input, value);
        field(label, group);
      }
      for (const [label, key] of [["\u8B6F\u6587\u5B57\u578B\u984F\u8272", "color"], ["\u80CC\u666F\u984F\u8272", "background"], ["\u539F\u6587\u5B57\u578B\u984F\u8272", "sourceColor"]]) {
        const input = document.createElement("input");
        input.type = "color";
        input.setAttribute("aria-label", label);
        input.value = this[key];
        input.oninput = () => {
          this[key] = input.value;
        };
        field(label, input);
      }
      const close = document.createElement("button");
      close.type = "button";
      close.textContent = "\u95DC\u9589";
      close.style.cssText = "margin-top:18px;width:100%;padding:8px;border:1px solid #ffffff30;border-radius:8px;background:#373139;color:white;font:14px system-ui;cursor:pointer";
      const dismiss = () => {
        panel.hidden = true;
        button.setAttribute("aria-expanded", "false");
      };
      close.onclick = () => {
        dismiss();
        button.focus();
      };
      panel.append(close);
      document.addEventListener("pointerdown", (e) => {
        if (e.target instanceof Node && !host.contains(e.target))
          dismiss();
      }, { signal: this.listeners.signal });
      panel.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          dismiss();
          button.focus();
        }
        if (e.key === "Tab") {
          const items = Array.from(panel.querySelectorAll("button,input,select"));
          const first = items[0], last = items[items.length - 1];
          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last?.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first?.focus();
          }
        }
      });
      for (const event of ["click", "keydown", "keyup"])
        panel.addEventListener(event, (e) => e.stopPropagation());
      button.onclick = (e) => {
        e.stopPropagation();
        panel.hidden = !panel.hidden;
        button.setAttribute("aria-expanded", String(!panel.hidden));
        if (!panel.hidden)
          toggle.focus();
      };
      host.append(button, panel);
      bar.prepend(host);
      this.refresh();
    }
    refresh() {
      if (!this.sheet) {
        this.sheet = document.createElement("style");
        this.sheet.dataset.localTranslate = "styles";
        document.documentElement.append(this.sheet);
      }
      const css = this.enabled && this.mode !== "original" ? `.ytp-caption-window-container .caption-window{background:${this.background}${Math.round(this.opacity * 2.55).toString(16).padStart(2, "0")}!important;border-radius:12px;height:auto!important;max-height:none!important;overflow:visible!important}.ytp-caption-window-container .captions-text{overflow:visible!important}.ytp-caption-window-container .ytp-caption-segment{background:transparent!important;color:${this.sourceColor}!important;${this.sourceSize === 100 ? "" : `zoom:${this.sourceSize / 100};`}font-family:${this.sourceFont}!important;font-weight:${this.sourceWeight}!important;${this.mode === "translated" ? "visibility:hidden;display:none!important;" : ""}}` : "";
      if (this.sheet.textContent !== css)
        this.sheet.textContent = css;
    }
    dispose() {
      this.listeners?.abort();
      this.listeners = null;
      this.sheet?.remove();
      this.sheet = null;
      this.host?.remove();
      this.host = null;
      this.panel = null;
    }
  };

  // src/content/caption-timeline.ts
  init_zod();
  var json3 = external_exports.object({ events: external_exports.array(external_exports.object({ tStartMs: external_exports.number().finite().nonnegative(), dDurationMs: external_exports.number().finite().positive().optional(), segs: external_exports.array(external_exports.object({ utf8: external_exports.string().max(12e3) })).optional() })).max(5e4) });
  function parseCaptionTimeline(value) {
    const events = json3.parse(value).events;
    const raw = [];
    for (const event of events) {
      const text = event.segs?.map((segment) => segment.utf8).join("").replace(/\s+/g, " ").trim();
      if (!text || text.length > 12e3 || !event.dDurationMs) continue;
      raw.push({ start: event.tStartMs / 1e3, end: (event.tStartMs + event.dDurationMs) / 1e3, text });
    }
    raw.sort((a, b) => a.start - b.start);
    for (let i = 0; i < raw.length - 1; i++) {
      const cur = raw[i], next = raw[i + 1];
      if (cur && next && cur.end > next.start && next.start > cur.start) cur.end = next.start;
    }
    const cues = [];
    for (const cue of raw) {
      const prev = cues[cues.length - 1];
      if (prev && cue.start - prev.end <= 0.5 && prev.end - prev.start < 7 && prev.text.length + 1 + cue.text.length <= 120 && !/[.!?。！？]["')\]]*$/.test(prev.text)) {
        prev.text += " " + cue.text;
        prev.end = Math.max(prev.end, cue.end);
      } else {
        cues.push({ ...cue });
      }
    }
    return cues;
  }
  function activeCaption(cues, time) {
    let lo = 0, hi = cues.length;
    while (lo < hi) {
      const mid = Math.floor((lo + hi) / 2);
      if ((cues[mid]?.start ?? Infinity) <= time) lo = mid + 1;
      else hi = mid;
    }
    for (let index = lo - 1; index >= 0; index--) {
      const cue = cues[index];
      if (cue && cue.end > time) return cue;
    }
    return void 0;
  }
  function captionWindow(cues, time, cached) {
    const selected = [];
    let size = 0;
    for (const cue of cues) {
      if (cue.end <= time || cue.start > time + 90 || cached.has(cue.text) || selected.includes(cue.text)) continue;
      if (selected.length >= 12 || size + cue.text.length > 24e3) break;
      selected.push(cue.text);
      size += cue.text.length;
    }
    return selected;
  }
  var trackSchema = external_exports.object({ baseUrl: external_exports.string().max(16e3), languageCode: external_exports.string().max(30), kind: external_exports.string().optional() });
  var captionInfoSchema = external_exports.object({ videoId: external_exports.string(), language: external_exports.string().optional(), tracks: external_exports.array(trackSchema).max(200) });
  function captionURL(info, page) {
    const parsed = captionInfoSchema.parse(info);
    if (parsed.videoId !== page.searchParams.get("v")) return null;
    const track = parsed.tracks.find((t) => t.languageCode === parsed.language) ?? parsed.tracks.find((t) => t.kind !== "asr") ?? parsed.tracks[0];
    if (!track) return null;
    const url = new URL(track.baseUrl);
    if (url.origin !== page.origin || url.pathname !== "/api/timedtext" || url.username || url.password) return null;
    url.searchParams.set("fmt", "json3");
    return url;
  }
  async function loadYouTubeTimeline(signal) {
    const page = new URL(location.href);
    if (!/(^|\.)youtube\.com$/.test(page.hostname) || page.pathname !== "/watch") return [];
    const { rpc: rpc2 } = await Promise.resolve().then(() => (init_messages(), messages_exports));
    const info = await rpc2({ kind: "captions.info" });
    let url = captionURL(info, page);
    if (typeof performance === "object" && typeof performance.getEntriesByType === "function") {
      const vid = page.searchParams.get("v");
      for (const entry of performance.getEntriesByType("resource")) {
        if (entry && typeof entry.name === "string" && entry.name.includes("/api/timedtext") && vid && entry.name.includes("v=" + vid) && entry.name.includes("pot=")) {
          try {
            const u = new URL(entry.name);
            if (u.origin === page.origin && u.pathname === "/api/timedtext" && !u.username && !u.password) {
              u.searchParams.set("fmt", "json3");
              url = u;
            }
          } catch {
          }
        }
      }
    }
    if (!url || signal.aborted) return [];
    const response = await fetch(url, { signal, credentials: "same-origin", redirect: "error" });
    if (!response.ok || Number(response.headers.get("content-length")) > 5e6) throw new Error("\u7121\u6CD5\u8B80\u53D6\u5B57\u5E55\u8ECC");
    const reader = response.body?.getReader();
    if (!reader) return [];
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        size += chunk.value.length;
        if (size > 5e6) throw new Error("\u5B57\u5E55\u8ECC\u904E\u5927");
        chunks.push(chunk.value);
      }
    } finally {
      await reader.cancel();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    const text = new TextDecoder().decode(bytes).trim();
    if (!text) return [];
    return parseCaptionTimeline(JSON.parse(text));
  }

  // src/content/subtitles.ts
  var SubtitleTranslator = class {
    constructor(translate2, batchSize = () => 8) {
      this.translate = translate2;
      this.batchSize = batchSize;
    }
    translate;
    batchSize;
    controls = new SubtitleControls();
    timer = null;
    last = "";
    revision = 0;
    session = 0;
    overlay = null;
    cache = /* @__PURE__ */ new Map();
    inFlight = /* @__PURE__ */ new Map();
    retryAfter = 0;
    lastStable = "";
    stableSince = 0;
    lastError = "";
    timeline = [];
    track = null;
    trackLength = 0;
    loading = null;
    timelineVideo = null;
    activeVideo = null;
    mediaKey = "";
    timelineRetry = 0;
    urgent = false;
    enabledTracks = /* @__PURE__ */ new Map();
    start() {
      if (this.timer !== null) return;
      this.timer = window.setInterval(() => this.tick(), 200);
      this.tick();
    }
    playback() {
      const video = Array.from(document.querySelectorAll("video")).find((video2) => !video2.paused && !video2.ended && !isAd(video2) && video2.getBoundingClientRect().width >= 20);
      return video ? { video, key: location.href + "|" + video.currentSrc } : null;
    }
    isYouTubeWatch() {
      return typeof location === "object" && /(^|\.)youtube\.com$/.test(location.hostname) && location.pathname === "/watch";
    }
    loadTimeline(video) {
      if (!this.isYouTubeWatch() || this.loading || this.timeline.length) return;
      const session = this.session;
      const loading = new AbortController();
      this.loading = loading;
      const timeout = setTimeout(() => loading.abort(), 15e3);
      void loadYouTubeTimeline(loading.signal).then((cues) => {
        if (session !== this.session || loading.signal.aborted) return;
        if (cues.length) {
          this.timeline = cues;
          this.timelineVideo = video;
          this.timelineRetry = 0;
        } else this.timelineRetry = Date.now() + 2e3;
      }).catch(() => {
        if (session === this.session) this.timelineRetry = Date.now() + 5e3;
      }).finally(() => {
        clearTimeout(timeout);
        if (this.loading === loading) this.loading = null;
      });
    }
    prepare(media) {
      this.clearSession();
      this.activeVideo = media.video;
      this.mediaKey = media.key;
      this.loadTimeline(media.video);
    }
    stop() {
      this.controls.dispose();
      if (this.timer !== null) clearInterval(this.timer);
      this.timer = null;
      this.clearSession();
    }
    clearSession() {
      this.session++;
      this.urgent = false;
      for (const [track, original] of this.enabledTracks) if (track.mode === "hidden") track.mode = original;
      this.enabledTracks.clear();
      this.activeVideo = null;
      this.mediaKey = "";
      this.timelineRetry = 0;
      this.loading?.abort();
      this.loading = null;
      this.timeline = [];
      this.timelineVideo = null;
      this.track = null;
      this.trackLength = 0;
      this.cache.clear();
      this.inFlight.clear();
      this.retryAfter = 0;
      this.lastError = "";
      this.lastStable = "";
      this.stableSince = 0;
      this.last = "";
      this.revision++;
      this.overlay?.remove();
      this.overlay = null;
    }
    current() {
      for (const video of document.querySelectorAll("video")) {
        if (video !== this.activeVideo || video.paused || video.ended || isAd(video) || video.getBoundingClientRect().width < 20)
          continue;
        let texts = [];
        const tracks = Array.from(video.textTracks);
        const selected = tracks.find((track) => track.mode === "showing") ?? tracks.find((track) => track.mode === "hidden") ?? tracks.find((track) => track.kind === "subtitles" || track.kind === "captions");
        if (selected?.mode === "disabled") {
          this.enabledTracks.set(selected, "disabled");
          selected.mode = "hidden";
        }
        for (const track of selected ? [selected] : []) {
          if (!track.activeCues) continue;
          if (track.cues && (this.track !== track || this.trackLength !== track.cues.length)) {
            this.track = track;
            this.trackLength = track.cues.length;
            this.timelineVideo = video;
            this.timeline = Array.from(track.cues).filter((cue) => cue instanceof VTTCue).map((cue) => ({ start: cue.startTime, end: cue.endTime, text: cue.text.replace(/<[^>]*>/g, "") })).filter((cue) => cue.text.trim() && cue.text.length <= 12e3).sort((a, b) => a.start - b.start);
          }
          for (const cue of track.activeCues)
            if (cue instanceof VTTCue)
              texts.push(cue.text.replace(/<[^>]*>/g, ""));
        }
        if (!texts.length && /(^|\.)youtube\.com$/.test(location.hostname))
          texts = Array.from(document.querySelectorAll(".ytp-caption-segment")).map((e) => e.textContent ?? "");
        const text = texts.join(" ").trim();
        if (text)
          return { text, video };
      }
      return null;
    }
    render(text, video) {
      if (!this.controls.enabled || this.controls.mode === "original") {
        if (this.overlay) this.overlay.hidden = true;
        return;
      }
      if (!this.overlay) {
        this.overlay = document.createElement("div");
        this.overlay.setAttribute(OWN_ATTRIBUTE, "subtitle");
        Object.assign(this.overlay.style, { position: "fixed", zIndex: "2147483646", pointerEvents: "none", padding: "5px 12px", borderRadius: "5px", background: "rgba(0,0,0,.82)", color: "white", font: "20px/1.5 system-ui", textAlign: "center", whiteSpace: "pre-wrap" });
        document.documentElement.append(this.overlay);
      }
      const caption = document.querySelector(".ytp-caption-window-container .caption-window");
      if (caption instanceof HTMLElement) {
        if (this.controls.position === "above") {
          if (caption.firstChild !== this.overlay) caption.prepend(this.overlay);
        } else if (caption.lastChild !== this.overlay) caption.append(this.overlay);
        Object.assign(this.overlay.style, { position: "static", width: "auto", padding: "3px 8px", fontSize: parseFloat(getComputedStyle(caption.querySelector(".ytp-caption-segment") ?? caption).fontSize) * this.controls.size / 100 + "px", fontFamily: this.controls.font, fontWeight: String(this.controls.weight), color: this.controls.color, background: "transparent", lineHeight: "1.4" });
        if (this.overlay.textContent !== text) this.overlay.textContent = text;
        this.overlay.hidden = false;
        return;
      }
      Object.assign(this.overlay.style, { position: "fixed", fontSize: 20 * this.controls.size / 100 + "px", fontFamily: this.controls.font, fontWeight: String(this.controls.weight), color: this.controls.color, background: this.controls.background + Math.round(this.controls.opacity * 2.55).toString(16).padStart(2, "0") });
      const full = document.fullscreenElement;
      if (full instanceof HTMLElement && !(full instanceof HTMLVideoElement) && this.overlay.parentElement !== full)
        full.append(this.overlay);
      else if (!full && this.overlay.parentElement !== document.documentElement)
        document.documentElement.append(this.overlay);
      const rect = video.getBoundingClientRect();
      this.overlay.style.left = Math.max(0, rect.left + rect.width * 0.1) + "px";
      this.overlay.style.top = Math.max(0, Math.min(innerHeight - 60, rect.bottom - 100)) + "px";
      this.overlay.style.width = Math.max(80, rect.width * 0.8 - 24) + "px";
      this.overlay.dataset.subtitleMode = this.timeline.length ? "prefetch" : "live";
      const nativeVisible = this.track ? this.track.mode === "showing" : document.querySelector(".ytp-subtitles-button")?.getAttribute("aria-pressed") !== "false";
      const source = activeCaption(this.timeline, video.currentTime)?.text ?? this.last;
      this.overlay.textContent = !nativeVisible && source ? source + "\n" + text : text;
      this.overlay.hidden = false;
    }
    window(time, current) {
      const pending = new Map(this.cache);
      for (const text of this.inFlight.keys()) pending.set(text, "");
      const upcoming = captionWindow(this.timeline, time, pending);
      if (current && !pending.has(current)) {
        const index = upcoming.indexOf(current);
        if (index >= 0) upcoming.splice(index, 1);
        upcoming.unshift(current);
      }
      return upcoming.slice(0, Math.min(8, this.batchSize()));
    }
    prefetch(texts, urgent = false) {
      const session = this.session;
      for (const text of texts) this.inFlight.set(text, session);
      void this.translate(texts).then((results) => {
        if (session !== this.session) return;
        if (results.length !== texts.length) throw new Error("\u5B57\u5E55\u7D50\u679C\u6578\u91CF\u4E0D\u7B26");
        this.lastError = "";
        texts.forEach((text, index) => {
          const value = results[index];
          if (value !== void 0) this.cache.set(text, value);
        });
        while (this.cache.size > 2e3) {
          const first = this.cache.keys().next().value;
          if (first === void 0) break;
          this.cache.delete(first);
        }
      }).catch((error) => {
        if (session === this.session) {
          this.lastError = error instanceof Error && error.message ? error.message : "\u5B57\u5E55\u7FFB\u8B6F\u5931\u6557\uFF0C\u7A0D\u5F8C\u91CD\u8A66";
          this.retryAfter = Date.now() + 1e4;
        }
      }).finally(() => {
        if (urgent && session === this.session) this.urgent = false;
        for (const text of texts) if (this.inFlight.get(text) === session) this.inFlight.delete(text);
      });
    }
    tick() {
      this.controls.attach();
      this.controls.setStatus(Date.now() < this.retryAfter && this.lastError ? this.lastError : this.inFlight.size ? "\u5B57\u5E55\u7FFB\u8B6F\u4E2D\uFF0C\u7B49\u5F85\u670D\u52D9\u56DE\u8986\u2026" : "\u5B57\u5E55\u7FFB\u8B6F\u5DF2\u555F\u7528");
      if (!this.controls.enabled || this.controls.mode === "original") {
        if (this.overlay) this.overlay.hidden = true;
        return;
      }
      const media = this.playback();
      if (!media) {
        const video2 = this.activeVideo;
        const cue = video2 ? activeCaption(this.timeline, video2.currentTime) : void 0;
        const cached = this.cache.get(cue?.text ?? (this.timeline.length ? "" : this.last));
        if (video2?.paused && !video2.ended && video2.isConnected && cached) this.render(cached, video2);
        else if (this.overlay) this.overlay.hidden = true;
        return;
      }
      if (media.video !== this.activeVideo || media.key !== this.mediaKey) this.prepare(media);
      else if (this.timelineRetry && Date.now() >= this.timelineRetry) {
        this.timelineRetry = 0;
        this.loadTimeline(media.video);
      }
      const current = this.current();
      const timelineVideo = this.timelineVideo;
      if (timelineVideo && this.timeline.length) {
        const ccOff = this.isYouTubeWatch() && document.querySelector(".ytp-subtitles-button")?.getAttribute("aria-pressed") === "false";
        const enabled = (this.track ? this.track.mode !== "disabled" : true) && !ccOff;
        if (!enabled || timelineVideo.paused || timelineVideo.ended || !timelineVideo.isConnected) {
          if (this.overlay) this.overlay.hidden = true;
          return;
        }
        const cue = activeCaption(this.timeline, timelineVideo.currentTime);
        const translated = cue ? this.cache.get(cue.text) : void 0;
        if (translated) this.render(translated, timelineVideo);
        else if (cue) this.render(Date.now() < this.retryAfter ? this.lastError || "\u5B57\u5E55\u7FFB\u8B6F\u5931\u6557\uFF0C\u7A0D\u5F8C\u91CD\u8A66" : "\u5B57\u5E55\u9810\u7FFB\u8B6F\u4E2D\u2026", timelineVideo);
        else if (this.overlay) this.overlay.hidden = true;
        if (cue && !translated && !this.inFlight.has(cue.text) && this.inFlight.size > 0 && !this.urgent && Date.now() >= this.retryAfter) {
          this.urgent = true;
          this.prefetch(this.window(timelineVideo.currentTime, cue.text), true);
        }
        if (!this.inFlight.size && Date.now() >= this.retryAfter) {
          const batch = this.window(timelineVideo.currentTime, cue?.text);
          if (batch.length) this.prefetch(batch);
        }
        return;
      }
      if (!current) {
        const ccEnabled = document.querySelector(".ytp-subtitles-button")?.getAttribute("aria-pressed") === "true";
        this.controls.setStatus(this.loading ? "\u6B63\u5728\u8B80\u53D6\u5B57\u5E55\u8ECC\u2026" : ccEnabled ? "\u5B57\u5E55\u5F85\u547D\u4E2D\uFF08\u76EE\u524D\u7247\u6BB5\u7121\u5C0D\u767D\uFF09" : "\u5C1A\u672A\u8B80\u53D6\u5230\u5B57\u5E55\uFF0C\u8ACB\u78BA\u8A8D CC \u5DF2\u958B\u555F");
        if (this.last) {
          this.last = "";
          this.revision++;
        }
        if (this.overlay)
          this.overlay.hidden = true;
        return;
      }
      const { text, video } = current;
      if (text !== this.last) {
        const growing = this.last && text.startsWith(this.last);
        this.last = text;
        this.revision++;
        if (growing && !/[.!?。！？]["')\]]*$/.test(text)) {
          this.stableSince = Date.now() + 350;
        } else {
          this.stableSince = 0;
          if (this.overlay)
            this.overlay.hidden = true;
        }
      }
      const existing = this.cache.get(text);
      if (existing) {
        this.render(existing, video);
        return;
      }
      this.controls.setStatus(Date.now() < this.retryAfter ? this.lastError || "\u5B57\u5E55\u7FFB\u8B6F\u5931\u6557\uFF0C\u7A0D\u5F8C\u91CD\u8A66\uFF1B\u8ACB\u6AA2\u67E5\u670D\u52D9\u8A2D\u5B9A" : "\u5373\u6642\u5B57\u5E55\u7FFB\u8B6F\u4E2D\uFF1B\u5B57\u5E55\u8ECC\u5C1A\u672A\u8F09\u5165\uFF0C\u7121\u6CD5\u9810\u8B80");
      if (this.inFlight.size > 0 || text.length > 12e3 || Date.now() < this.retryAfter || Date.now() < this.stableSince)
        return;
      this.lastStable = text;
      const revision = this.revision;
      const session = this.session;
      this.inFlight.set(text, session);
      void this.translate([text]).then((results) => {
        if (session !== this.session)
          return;
        const result = results[0];
        if (!result)
          return;
        this.lastError = "";
        this.cache.set(text, result);
        if (this.cache.size > 300) {
          const oldest = this.cache.keys().next().value;
          if (oldest !== void 0)
            this.cache.delete(oldest);
        }
        if (this.revision === revision && this.last === text || this.last.startsWith(text))
          this.render(result, video);
      }).catch((error) => {
        if (session === this.session) {
          this.lastError = error instanceof Error && error.message ? error.message : "\u5B57\u5E55\u7FFB\u8B6F\u5931\u6557\uFF0C\u7A0D\u5F8C\u91CD\u8A66\uFF1B\u8ACB\u6AA2\u67E5\u670D\u52D9\u8A2D\u5B9A";
          this.retryAfter = Date.now() + 15e3;
        }
      }).finally(() => {
        if (this.inFlight.get(text) === session) this.inFlight.delete(text);
      });
    }
  };

  // src/content/controller.ts
  var PageTranslator = class {
    constructor(settings, translate2, subtitleTranslate = translateSubtitles) {
      this.settings = settings;
      this.translate = translate2;
      this.lookup = new WordLookup(() => this.settings);
      this.themeStyles.setAttribute(OWN_ATTRIBUTE, "styles");
      this.themeStyles.textContent = maskStyles;
      document.documentElement.append(this.themeStyles);
      this.subtitles = new SubtitleTranslator(subtitleTranslate, () => this.settings.batchSize);
      this.images = new ImageTranslator(() => this.settings);
      this.intersections = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (!(entry.target instanceof HTMLElement))
            continue;
          if (entry.isIntersecting) {
            this.visible.add(entry.target);
            const block = this.blocks.get(entry.target);
            if (block)
              this.enqueue(block);
          } else
            this.visible.delete(entry.target);
        }
      }, { rootMargin: "200px" });
      this.mutations = new MutationObserver((records) => {
        if (!this.explicitPage && this.mode !== "original" && this.mediaPage()) this.setMode("original", false);
        if (this.mode !== "original" && records.some((record) => !this.ownedMutation(record))) this.scheduleScan();
      });
      this.mutations.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["hidden", "inert", "aria-hidden", "contenteditable", "translate"] });
      document.addEventListener("keydown", this.keyDown, true);
      this.navigationTimer = window.setInterval(() => {
        if (location.href !== this.lastUrl) {
          this.lastUrl = location.href;
          this.subtitles.stop();
          this.images.stop();
          this.reset(this.settings, "original", false);
          if (sitePolicy(location.hostname, this.settings) === "auto" && !this.mediaPage()) this.setMode(this.settings.mode, false);
        }
      }, 750);
      this.syncSubtitles();
      if (sitePolicy(location.hostname, settings) === "auto" && !this.mediaPage()) this.setMode(settings.mode, false);
    }
    settings;
    translate;
    mode = "original";
    epoch = 0;
    blocks = /* @__PURE__ */ new Map();
    visible = /* @__PURE__ */ new Set();
    pending = /* @__PURE__ */ new Set();
    flushing = false;
    scanTimer = null;
    stopped = false;
    explicitPage = false;
    lastUrl = location.href;
    panel = new TranslationPanel();
    themeStyles = document.createElement("style");
    lookup;
    subtitles;
    images;
    intersections;
    mutations;
    navigationTimer;
    mediaPage() {
      return this.settings.images || !!document.querySelector("video") || /(^|\.)youtube\.com$/.test(location.hostname) && location.pathname === "/watch";
    }
    syncSubtitles() {
      if (this.settings.subtitles && sitePolicy(location.hostname, this.settings) !== "blocked") this.subtitles.start();
      else this.subtitles.stop();
      if (this.settings.images && sitePolicy(location.hostname, this.settings) !== "blocked") this.images.start();
      else this.images.stop();
    }
    ownedMutation(record) {
      const element = record.target instanceof Element ? record.target : record.target.parentElement;
      if (element?.closest(`[${OWN_ATTRIBUTE}]`))
        return true;
      if (record.type === "childList")
        return Array.from(record.addedNodes).concat(Array.from(record.removedNodes)).every((node) => node instanceof Element && node.hasAttribute(OWN_ATTRIBUTE));
      if (record.type === "characterData" && record.target instanceof Text) {
        for (const block of this.blocks.values())
          if (block.nodes.some((n) => n.node === record.target && n.node.data === (n.written ?? n.original)))
            return true;
      }
      return false;
    }
    scheduleScan() {
      if (this.scanTimer !== null || this.stopped)
        return;
      this.scanTimer = window.setTimeout(() => {
        this.scanTimer = null;
        this.scan();
      }, 100);
    }
    discard(block) {
      block.revision++;
      restoreText(block.nodes);
      block.output?.remove();
      this.intersections.unobserve(block.element);
      this.visible.delete(block.element);
      this.pending.delete(block);
      this.blocks.delete(block.element);
    }
    scan() {
      if (this.stopped)
        return;
      for (const block of this.blocks.values()) {
        if (!block.element.isConnected) {
          this.discard(block);
          continue;
        }
        if (changed(block.nodes) || block.nodes.some((n) => !block.element.contains(n.node)) || sourceNodes(block.element).some((n) => !block.nodes.some((known) => known.node === n.node))) {
          restoreText(block.nodes);
          block.output?.remove();
          block.output = null;
          block.nodes = sourceNodes(block.element);
          block.source = normalizedText(block.nodes);
          block.revision++;
          block.result = { kind: "idle" };
        }
        if (!candidate(block.element)) {
          this.discard(block);
          continue;
        }
      }
      if (this.mode !== "original")
        for (const element of collectBlocks(document.body))
          this.track(element);
      for (const block of this.blocks.values())
        if (this.visible.has(block.element))
          this.enqueue(block);
    }
    track(element) {
      const prior = this.blocks.get(element);
      if (prior)
        return prior;
      const nodes = sourceNodes(element);
      const block = { element, nodes, source: normalizedText(nodes), result: { kind: "idle" }, output: null, revision: 0 };
      this.blocks.set(element, block);
      this.intersections.observe(element);
      return block;
    }
    enqueue(block) {
      if (sitePolicy(location.hostname, this.settings) === "blocked" || !block.source || block.result.kind !== "idle" || this.mode === "original")
        return;
      this.pending.add(block);
      void this.flush();
    }
    async translateLong(texts, current = () => true) {
      const maxChunkCharacters = 6e3;
      const maxRequestCharacters = 6e4;
      const parts = texts.map((text) => splitText(text, maxChunkCharacters));
      const all = parts.flat();
      const translated = [];
      const batchSize = Math.min(this.settings.batchSize, Math.floor(maxRequestCharacters / maxChunkCharacters));
      for (let start = 0; start < all.length; start += batchSize) {
        if (!current()) throw new Error("\u7FFB\u8B6F\u5DF2\u505C\u6B62\u3002");
        const batch = all.slice(start, start + batchSize);
        const results = await this.translate(batch);
        if (results.length !== batch.length)
          throw new Error("\u7FFB\u8B6F\u7D50\u679C\u6578\u91CF\u4E0D\u7B26\uFF0C\u8ACB\u91CD\u8A66\u3002");
        translated.push(...results);
      }
      let offset = 0;
      return parts.map((part) => {
        const value = translated.slice(offset, offset + part.length).join(" ");
        offset += part.length;
        return value;
      });
    }
    async flush() {
      if (this.flushing)
        return;
      this.flushing = true;
      try {
        while (this.pending.size) {
          const batch = Array.from(this.pending).slice(0, this.settings.batchSize);
          const epoch = this.epoch;
          const requests = batch.map((block) => ({ block, revision: block.revision }));
          for (const block of batch) {
            this.pending.delete(block);
            block.result = { kind: "pending" };
          }
          try {
            const texts = await this.translateLong(batch.map((block) => block.source), () => epoch === this.epoch && !this.stopped);
            requests.forEach(({ block, revision }, index) => {
              const text = texts[index];
              if (text === void 0 || epoch !== this.epoch || revision !== block.revision || !block.element.isConnected || changed(block.nodes))
                return;
              block.result = { kind: "ready", text: text.trim() === block.source.trim() ? "" : text };
              this.render(block);
            });
          } catch (error) {
            for (const { block, revision } of requests)
              if (epoch === this.epoch && revision === block.revision) {
                block.result = { kind: "error" };
                this.renderError(block);
              }
            if (epoch === this.epoch)
              this.panel.show(error instanceof Error ? error.message : "\u7FFB\u8B6F\u5931\u6557\uFF0C\u8ACB\u6AA2\u67E5\u670D\u52D9\u8A2D\u5B9A\u3002");
          }
        }
      } finally {
        this.flushing = false;
      }
    }
    makeOutput(block) {
      const output = document.createElement("span");
      output.setAttribute(OWN_ATTRIBUTE, "result");
      output.lang = this.settings.target;
      output.dir = translationDirection(this.settings.target);
      applyTranslationStyle(output, this.settings.style);
      if (compactTranslation(block.element, block.source)) {
        Object.assign(output.style, { display: "inline", margin: "0", marginInlineStart: "0.5em", lineHeight: "inherit", whiteSpace: "inherit", overflowWrap: "normal" });
        const label = [...block.nodes].reverse().find((node) => new RegExp("\\p{L}", "u").test(node.original))?.node.parentElement;
        (label && block.element.contains(label) ? label : block.element).append(output);
      } else {
        block.element.append(output);
      }
      block.output = output;
      return output;
    }
    render(block) {
      block.output?.remove();
      block.output = null;
      restoreText(block.nodes);
      if (block.result.kind !== "ready" || !block.result.text)
        return;
      if (this.mode === "translated")
        replaceText(block.nodes, block.result.text);
      else if (this.mode !== "original")
        this.makeOutput(block).textContent = block.result.text;
    }
    renderError(block) {
      if (this.mode === "original")
        return;
      block.output?.remove();
      const output = this.makeOutput(block);
      const retry = document.createElement("button");
      retry.type = "button";
      retry.textContent = "\u7FFB\u8B6F\u5931\u6557\uFF0C\u9EDE\u6B64\u91CD\u8A66";
      retry.style.cssText = "font:inherit;color:inherit;background:transparent;border:0;cursor:pointer;text-decoration:underline";
      retry.onclick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        output.remove();
        block.output = null;
        block.result = { kind: "idle" };
        this.enqueue(block);
      };
      output.append(retry);
    }
    setMode(mode, explicit = true) {
      this.explicitPage = explicit;
      this.epoch++;
      this.panel.close();
      this.lookup.close();
      this.pending.clear();
      this.mode = sitePolicy(location.hostname, this.settings) === "blocked" || !explicit && this.mediaPage() ? "original" : mode;
      for (const block of this.blocks.values()) {
        if (block.result.kind === "pending" || block.result.kind === "error")
          block.result = { kind: "idle" };
        this.render(block);
      }
      if (this.mode !== "original") this.scan();
    }
    getMode() {
      return this.mode;
    }
    status() {
      return { mode: this.mode, paragraphs: this.blocks.size, translated: Array.from(this.blocks.values()).filter((block) => block.result.kind === "ready").length };
    }
    reset(settings, mode = this.mode, explicit = this.explicitPage) {
      const restartMedia = this.settings.source !== settings.source || this.settings.target !== settings.target || this.settings.provider !== settings.provider || this.settings.subtitles !== settings.subtitles || this.settings.images !== settings.images || JSON.stringify(this.settings.blockSites) !== JSON.stringify(settings.blockSites);
      this.epoch++;
      this.pending.clear();
      for (const block of this.blocks.values())
        this.discard(block);
      this.settings = settings;
      if (restartMedia) {
        this.subtitles.stop();
        this.images.stop();
      }
      this.syncSubtitles();
      this.setMode(mode, explicit);
    }
    async selection(text) {
      if (this.stopped || sitePolicy(location.hostname, this.settings) === "blocked")
        return;
      const selected = (text ?? window.getSelection()?.toString() ?? "").trim();
      if (!selected)
        return;
      if (selected.length > 12e3) {
        this.panel.show("\u9078\u53D6\u5167\u5BB9\u8D85\u904E 12,000 \u5B57\u5143\uFF0C\u8ACB\u5206\u6BB5\u7FFB\u8B6F\u3002");
        return;
      }
      this.lookup.close();
      const epoch = this.epoch;
      await this.panel.translate(selected, (texts) => this.translateLong(texts, () => epoch === this.epoch && !this.stopped));
    }
    keyDown = (event) => {
      if (event.key === "Escape") this.panel.close();
    };
    dispose() {
      this.lookup.dispose();
      this.stopped = true;
      this.epoch++;
      this.pending.clear();
      this.mutations.disconnect();
      this.intersections.disconnect();
      if (this.scanTimer !== null)
        clearTimeout(this.scanTimer);
      clearInterval(this.navigationTimer);
      for (const block of this.blocks.values())
        this.discard(block);
      this.subtitles.stop();
      this.images.stop();
      this.panel.close();
      this.themeStyles.remove();
      document.removeEventListener("keydown", this.keyDown, true);
    }
  };

  // src/content/content.ts
  if (!globalThis.__localTranslateContentInstalled) {
    let getController2 = function() {
      if (document.contentType === "application/pdf" || document.querySelector('embed[type="application/pdf"],object[type="application/pdf"]')) return Promise.reject(new Error("PDF \u8ACB\u4F7F\u7528\u6587\u4EF6\u5DE5\u4F5C\u5340\u3002"));
      ready ??= rpc({ kind: "settings.public" }).then((data) => new PageTranslator(publicSchema.parse(data), translate)).catch((error) => {
        ready = void 0;
        throw error;
      });
      return ready;
    };
    getController = getController2;
    globalThis.__localTranslateContentInstalled = true;
    const publicSchema = settingsSchema.omit({ providers: true });
    let ready;
    void getController2().catch(() => void 0);
    chrome.runtime.onMessage.addListener((message, sender, reply) => {
      if (sender.id !== chrome.runtime.id)
        return;
      const request = contentMessageSchema.safeParse(message);
      if (!request.success)
        return;
      const action = request.data;
      void getController2().then(async (controller) => {
        if (action.kind === "settings.updated") {
          controller.reset(action.settings, action.restore || action.settings.mode === "original" ? "original" : controller.getMode());
        } else if (action.kind === "page.selection")
          await controller.selection(action.text);
        else {
          const settings = publicSchema.parse(await rpc({ kind: "settings.public" }));
          controller.reset(settings, action.kind === "page.mode" ? action.mode : controller.getMode() === "original" ? "bilingual" : "original", true);
        }
        reply({ ok: true, data: controller.status() });
      }).catch(() => reply({ ok: false, error: "\u7121\u6CD5\u7FFB\u8B6F\u6B64\u9801\u9762\uFF0C\u8ACB\u91CD\u65B0\u8F09\u5165\u9801\u9762\u4E26\u6AA2\u67E5\u8A2D\u5B9A\u3002" }));
      return true;
    });
  }
  var getController;
})();
//# sourceMappingURL=content.js.map
